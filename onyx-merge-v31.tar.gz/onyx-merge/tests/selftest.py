#!/usr/bin/env python3
"""Selbsttest von Onyx Merge – ohne einen echten Anbieter anzufragen.

Startet zwei nachgebaute Anbieter und eine Test-Instanz des Mergers mit eigenem, leerem Datenordner auf freien Ports,
prüft die wichtigsten Abläufe (Abgleich, Anmeldung in der App, Listen, Weiterleitung der Streams, Verwaltung,
Konflikt-Schutz beim Speichern, Sicherung) und räumt danach alles wieder weg. Die echte Installation bleibt unberührt.

Aufruf: python3 tests/selftest.py [PAKET-ORDNER]
"""
import json, os, shutil, socket, subprocess, sys, tempfile, time, urllib.error, urllib.request

PKG = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
ok_count, fails, procs = 0, [], []


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def http(url, body=None, host=None, redirect=True):
    req = urllib.request.Request(url, data=None if body is None else json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json", **({"Host": host} if host else {})})
    opener = urllib.request.build_opener(*([] if redirect else [NoRedirect()]))
    try:
        with opener.open(req, timeout=20) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def check(name, cond, detail=""):
    global ok_count
    if cond:
        ok_count += 1
        print(f"  OK      {name}")
    else:
        fails.append(name)
        print(f"  FEHLER  {name} {detail}")


def main():
    tmp = tempfile.mkdtemp(prefix="onyx-selftest-")
    try:
        pa, pb, pc, pd = free_port(), free_port(), free_port(), free_port()
        for port, name in ((pa, "A"), (pb, "B")):
            procs.append(subprocess.Popen([sys.executable, os.path.join(PKG, "tests", "mock_provider.py"), str(port), name],
                                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        for f in ("onyx_merge.py", "admin.html", "speedtest.html", "me.html"):
            shutil.copy(os.path.join(PKG, f), tmp)
        shutil.copytree(os.path.join(PKG, "ui"), os.path.join(tmp, "ui"))
        os.makedirs(os.path.join(tmp, "data"))
        cfg = {"listen": f"127.0.0.1:{pc}", "admin_listen": f"127.0.0.1:{pd}", "sync_pause": 0, "upstream_min_interval": 0,
               "domains": {"A": ["a.selftest"], "B": ["b.selftest"]}, "fallback": True,
               "providers": {"A": {"name": "Test 1", "url": f"http://127.0.0.1:{pa}", "kinds": ["live", "vod", "series"], "sync_user": "s", "sync_pass": "s", "epg": True},
                             "B": {"name": "Test 2", "url": f"http://127.0.0.1:{pb}", "kinds": ["live"], "sync_user": "s", "sync_pass": "s", "epg": True}}}
        json.dump(cfg, open(os.path.join(tmp, "data", "config.json"), "w"))
        log = open(os.path.join(tmp, "merger.log"), "w")
        procs.append(subprocess.Popen([sys.executable, os.path.join(tmp, "onyx_merge.py")], env=dict(os.environ, ONYX_MERGE_HOME=tmp),
                                      stdout=log, stderr=subprocess.STDOUT))
        A, C = f"http://127.0.0.1:{pd}", f"http://127.0.0.1:{pc}"
        for _ in range(60):
            try:
                if http(A + "/api/version")[0] == 200:
                    break
            except Exception:
                pass
            time.sleep(0.5)
        st, body, _ = http(A + "/api/version")
        check("Merger startet, Verwaltung antwortet", st == 200, body[:200])
        if st != 200:
            return
        for k in ("A", "B"):
            http(A + "/api/sync", {"key": k, "force": True})
            for _ in range(60):
                s = json.loads(http(A + "/api/state")[1])
                if (s["providers"][k]["status"] or {}).get("last_ok") and not s.get("sync_running"):
                    break
                time.sleep(0.5)
            check(f"Abgleich Anbieter {k}", (s["providers"][k]["status"] or {}).get("last_ok"), s["providers"][k]["status"])
        u = {"username": "selftest", "password": "pw-12345", "enabled": True, "A": {"user": "la", "pass": "pa"}, "B": {"user": "lb", "pass": "pb"}}
        st, body, _ = http(A + "/api/users", {"users": [u], "base": {}})
        check("Kunde anlegen", st == 200, body[:200])
        q = "username=selftest&password=pw-12345"
        st, body, _ = http(f"{C}/player_api.php?{q}", host="a.selftest")
        check("Anmeldung wie in der IPTV-App", st == 200 and json.loads(body).get("user_info", {}).get("auth") == 1, body[:200])
        st, body, _ = http(f"{C}/player_api.php?{q}&password=falsch".replace("password=pw-12345&", ""), host="a.selftest")
        check("Falsches Passwort wird abgelehnt", b'"auth":1' not in body.replace(b" ", b""))
        cats = json.loads(http(f"{C}/player_api.php?{q}&action=get_live_categories", host="a.selftest")[1])
        check("Live-Kategorien", len(cats) >= 2, len(cats))
        live = json.loads(http(f"{C}/player_api.php?{q}&action=get_live_streams", host="a.selftest")[1])
        check("Live-Sender aus beiden Anbietern", len(live) >= 20, len(live))
        st = http(A + "/api/separators", {"enabled": True})[0]
        live_d = json.loads(http(f"{C}/player_api.php?{q}&action=get_live_streams", host="a.selftest")[1])
        dr = json.loads(http(A + "/api/draft")[1])
        check("Entwurf: Kunden sehen Änderungen erst nach Speichern", dr.get("dirty") and len(live_d) == len(live), (dr, len(live_d)))
        http(A + "/api/publish", {})
        live2 = json.loads(http(f"{C}/player_api.php?{q}&action=get_live_streams", host="a.selftest")[1])
        check("Trennzeilen ausblenden", st == 200 and any("###" in x["name"] for x in live) and not any("###" in x["name"] for x in live2)
              and len(live2) == len(live) - 2, (st, len(live), len(live2)))
        st = http(A + "/api/hide_all", {"kinds": ["live"]})[0]
        http(A + "/api/publish", {})
        cats0 = json.loads(http(f"{C}/player_api.php?{q}&action=get_live_categories", host="a.selftest")[1])
        allc = json.loads(http(A + "/api/categories?kind=live")[1])
        first = next(c for c in allc if c["pkey"] != "C")
        http(A + "/api/categories", {"kind": "live", "items": [{"vid": first["vid"], "show": True}]})
        http(A + "/api/publish", {})
        cats1 = json.loads(http(f"{C}/player_api.php?{q}&action=get_live_categories", host="a.selftest")[1])
        check("Auswählen: alles aus, dann eine an", st == 200 and len(cats0) == 0 and len(cats1) == 1 and "cc" in first, (st, len(cats0), len(cats1)))
        http(A + "/api/categories", {"kind": "live", "items": [{"vid": c["vid"], "show": True} for c in allc]})
        st_d = http(A + "/api/discard", {})[0]
        cats2 = json.loads(http(f"{C}/player_api.php?{q}&action=get_live_categories", host="a.selftest")[1])
        dr2 = json.loads(http(A + "/api/draft")[1])
        check("Entwurf verwerfen", st_d == 200 and not dr2.get("dirty") and len(cats2) == 1, (st_d, dr2, len(cats2)))
        http(A + "/api/categories", {"kind": "live", "items": [{"vid": c["vid"], "show": True} for c in allc]})
        http(A + "/api/publish", {})
        cat1 = next(c for c in json.loads(http(A + "/api/categories?kind=live")[1]) if c["pkey"] == "A")
        st = http(A + "/api/sort_cat", {"kind": "live", "cat": cat1["vid"], "mode": "az"})[0]
        names = [x["name"] for x in json.loads(http(A + f"/api/channels?kind=live&cat={cat1['vid']}")[1])]
        st2 = http(A + "/api/sort_cat", {"kind": "live", "cat": cat1["vid"], "mode": "provider"})[0]
        cats_l = [c for c in json.loads(http(A + "/api/categories?kind=live")[1]) if c["pkey"] == "A"]
        src, dst = cats_l[0]["vid"], cats_l[1]["vid"]
        mv = json.loads(http(A + f"/api/channels?kind=live&cat={src}")[1])[0]
        http(A + "/api/channels", {"kind": "live", "items": [{"vid": mv["vid"], "cat": dst, "order": None}]})
        after = json.loads(http(A + f"/api/channels?kind=live&cat={dst}")[1])
        check("Verschieben sortiert automatisch", any(x["vid"] == mv["vid"] for x in after), [x["name"] for x in after][:5])
        http(A + "/api/channels", {"kind": "live", "items": [{"vid": mv["vid"], "cat": "", "order": None}]})
        tm_cat = next(c for c in json.loads(http(A + "/api/categories?kind=live")[1]) if c["pkey"] == "A")
        tm_ch = json.loads(http(A + f"/api/channels?kind=live&cat={tm_cat['vid']}")[1])
        st_t = http(A + "/api/testmark", {"kind": "live", "vids": [tm_ch[0]["vid"]], "state": "bad", "hide": False})[0]
        tm_after = next(c for c in json.loads(http(A + "/api/categories?kind=live")[1]) if c["vid"] == tm_cat["vid"])
        tm_ch2 = json.loads(http(A + f"/api/channels?kind=live&cat={tm_cat['vid']}")[1])
        check("Sender-Test: „läuft nicht“ wird gemerkt", st_t == 200 and tm_after.get("t_bad") == 1 and tm_ch2[0].get("test") == "bad", (st_t, tm_after.get("t_bad")))
        http(A + "/api/testmark", {"kind": "live", "vids": [tm_ch[0]["vid"]], "state": None})
        check("Kategorie mit einem Klick sortieren", st == 200 and st2 == 200 and len(names) > 2, (st, st2, names[:4]))
        vod = json.loads(http(f"{C}/player_api.php?{q}&action=get_vod_streams", host="a.selftest")[1])
        check("Filme", len(vod) >= 1, len(vod))
        sid = live[0]["stream_id"] if live else 0
        st, _, hd = http(f"{C}/live/selftest/pw-12345/{sid}.ts", host="a.selftest", redirect=False)
        check("Stream wird direkt zum Anbieter weitergeleitet (302)", st == 302 and "127.0.0.1" in (hd.get("Location") or ""), st)
        st, _, hd = http(f"{C}/live/fremd99/fpw99/{sid}.ts", host="a.selftest", redirect=False)
        pt = json.loads(http(A + "/api/passthru")[1])
        check("Durchgereicht: Umschalten wird gemerkt", st == 302 and "fremd99" in json.dumps(pt), (st, str(pt)[:200]))
        http(f"{C}/wp-admin/scanner/test.php", host="a.selftest", redirect=False)
        check("Durchgereicht: Abrufe von Scannern werden nicht gemerkt", "wp-admin" not in http(A + "/api/passthru")[1].decode())
        st, body, _ = http(A + "/api/bexp_check", {"username": "selftest"})
        want = time.strftime("%Y-%m-%d", time.localtime(time.time() + 10 * 86400))
        bx = json.loads(body) if st == 200 else {}
        check("Zusatz-Laufzeit wird aus der Line gelesen", st == 200 and bx.get("auth") and bx.get("exp") in (want, time.strftime("%Y-%m-%d", time.localtime(time.time() + 9 * 86400)), time.strftime("%Y-%m-%d", time.localtime(time.time() + 11 * 86400))), body[:200])
        check("Zusatz-Laufzeit in der Verwaltung", "lb" in json.loads(http(A + "/api/bexp")[1]).get("lines", {}))
        st, body, _ = http(f"{C}/xmltv.php?{q}", host="a.selftest")
        check("Programm (EPG) für die App", st == 200 and b"<tv" in body, st)
        us = json.loads(http(A + "/api/users")[1])
        st, body, _ = http(f"{C}/me/{us[0].get('_token', '')}", host="a.selftest")
        check("Kundenseite „Mein Zugang“", st == 200 and b"selftest" in body and b"pw-12345" not in body, st)
        st = http(f"{C}/me/falsch", host="a.selftest")[0]
        check("Kundenseite mit falschem Link wird abgelehnt", st == 404, st)
        stale = dict(us[0], note="Gerät 1", _o=us[0]["username"])
        good = dict(us[0], note="Gerät 2", _o=us[0]["username"])
        st1 = http(A + "/api/users", {"users": [good], "base": {us[0]["username"]: us[0]["_v"]}})[0]
        st2 = http(A + "/api/users", {"users": [stale], "base": {us[0]["username"]: us[0]["_v"]}})[0]
        check("Zwei Geräte: zweites Speichern wird als Konflikt erkannt", st1 == 200 and st2 == 409, (st1, st2))
        for path in ("/", "/api/overview", "/api/ops", "/api/categories?kind=live", "/api/clean_summary?kind=live",
                     "/api/notify", "/api/offsite", "/api/passthru", "/api/journal"):
            check(f"Verwaltung {path}", http(A + path)[0] == 200)
        u2 = dict(json.loads(http(A + "/api/users")[1])[0])
        http(A + "/api/users", {"users": [], "base": {u2["username"]: u2["_v"]}})
        tr = json.loads(http(A + "/api/trash")[1])
        st = http(A + "/api/trash_restore", {"username": u2["username"]})[0]
        check("Papierkorb: löschen und wiederherstellen", any(x["username"] == u2["username"] for x in tr) and st == 200
              and any(x["username"] == u2["username"] for x in json.loads(http(A + "/api/users")[1])), (len(tr), st))
        st, body, _ = http(A + "/api/ipcheck", {"key": "A"})
        ipc = json.loads(body) if st == 200 else {}
        check("Server-IP beim Anbieter prüfen", st == 200 and ipc.get("verdict") == "free", body[:200])
        check("Server-Last wird gemessen", "health" in json.loads(http(A + "/api/ops")[1]))
        st, body, _ = http(A + "/api/backup", {})
        check("Sicherung anlegen", st == 200, body[:200])
        import threading
        res = []
        ths = [threading.Thread(target=lambda h=h: res.append(http(f"{C}/player_api.php?{q}&action=get_vod_streams", host=h)[1]))
               for h in ("a.selftest", "b.selftest", "fremd.example") * 3]
        [t.start() for t in ths]; [t.join() for t in ths]
        check("Gleichzeitige Abrufe über drei Domains: identische Liste", len(res) == 9 and len(set(res)) == 1 and res[0].startswith(b"["), len(set(res)))
        x1 = http(f"{C}/xmltv.php?{q}", host="a.selftest")[1]
        x2 = http(f"{C}/xmltv.php?{q}", host="b.selftest")[1]
        check("Programm (EPG) wird zwischengespeichert", x1 == x2 and b"<programme" in x1)
        r = subprocess.run([sys.executable, os.path.join(PKG, "tests", "unit_core.py"), PKG], capture_output=True, text=True, timeout=300)
        check("Bausteine: Zwischenspeicher, sicheres Speichern, Datenbank, Abgleich-Sperre", r.returncode == 0,
              "\n" + "\n".join(l for l in r.stdout.splitlines() if "FEHLER" in l) + r.stderr[-400:])
        logtxt = open(os.path.join(tmp, "merger.log")).read()
        check("Keine Programmfehler im Protokoll", "Traceback" not in logtxt, logtxt[-600:])
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(5)
            except Exception:
                p.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"\n{ok_count} bestanden, {len(fails)} fehlgeschlagen")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        fails.append(str(e))
        print(f"  FEHLER  Selbsttest abgebrochen: {e}")
    sys.exit(1 if fails else 0)
