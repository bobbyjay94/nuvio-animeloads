"""Nachgebauter Xtream-Anbieter für den Selbsttest. Aufruf: python3 mock_provider.py PORT NAME"""
import json, sys, time, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

PORT, NAME = int(sys.argv[1]), sys.argv[2]


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        if u.path == "/player_api.php":
            a = q.get("action")
            data = {"get_live_categories": [{"category_id": "1", "category_name": f"DE | {NAME} SPORT"}, {"category_id": "2", "category_name": f"TR | {NAME} ULUSAL"}],
                    "get_live_streams": [{"num": i, "name": f"DE | Sender {i} HD", "stream_id": 100 + i, "stream_icon": "", "epg_channel_id": f"ch{i}.{NAME}",
                                          "category_id": "1" if i % 2 else "2"} for i in range(1, 11)] + [{"num": 99, "name": f"### DE {NAME} SPORT ###", "stream_id": 199, "category_id": "1"}],
                    "get_vod_categories": [{"category_id": "10", "category_name": f"DE | {NAME} FILME"}],
                    "get_vod_streams": [{"name": "Film X", "stream_id": 5000, "category_id": "10", "container_extension": "mkv"}],
                    "get_series_categories": [{"category_id": "20", "category_name": f"DE | {NAME} SERIEN"}],
                    "get_series": [{"name": "Serie Y", "series_id": 700, "category_id": "20"}],
                    }.get(a, {"user_info": {"auth": 1, "status": "Active", "exp_date": str(int(time.time()) + 10 * 86400)}})
            return self.out(json.dumps(data).encode())
        if u.path == "/xmltv.php":
            t = lambda x: time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(x))
            now = int(time.time())
            progs = "".join(f'<programme start="{t(now - 1800)}" stop="{t(now + 1800)}" channel="ch{i}.{NAME}"><title>Show {i}</title></programme>' for i in range(1, 6))
            return self.out(f'<?xml version="1.0"?><tv>{progs}</tv>'.encode(), "application/xml")
        self.send_response(404)
        self.end_headers()

    def out(self, b, ct="application/json"):
        self.send_response(200)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
