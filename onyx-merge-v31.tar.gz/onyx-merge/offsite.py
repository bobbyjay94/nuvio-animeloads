#!/usr/bin/env python3
"""Onyx Merge: Sicherungen auf die Storage Box kopieren (läuft als root, über systemd).

Der Merger selbst läuft als normaler Benutzer und darf auf der eingebundenen Storage Box oft nicht schreiben.
Deshalb erledigt das dieses kleine Hilfsprogramm. Es liest nur die Einstellungen des Mergers und schreibt
sein Ergebnis nach data/offsite.status.json zurück.

Mit Passwort wird jede Sicherung vor dem Hochladen mit openssl (AES-256, PBKDF2) verschlüsselt.
Entschlüsseln (auf jedem Linux/Mac/WSL):
  openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -in DATEI.tar.gz.enc -out DATEI.tar.gz
"""
import json, os, pwd, re, shutil, subprocess, sys, time

HOME = os.environ.get("ONYX_MERGE_HOME", "/opt/onyx-merge")
DATA = os.path.join(HOME, "data")
BK = os.path.join(DATA, "backups")
STATUS = os.path.join(DATA, "offsite.status.json")


def write_status(st):
    st["t"] = int(time.time())
    tmp = STATUS + ".tmp"
    with open(tmp, "w") as f:
        json.dump(st, f, ensure_ascii=False)
    os.replace(tmp, STATUS)
    try:
        u = pwd.getpwuid(os.stat(DATA).st_uid)
        os.chown(STATUS, u.pw_uid, u.pw_gid)
        os.chmod(STATUS, 0o600)
    except Exception:
        pass


def mount_root(path):
    p = os.path.abspath(path)
    while p not in ("/", ""):
        if os.path.ismount(p):
            return p
        p = os.path.dirname(p)
    return None


def main():
    try:
        cfg = json.load(open(os.path.join(DATA, "config.json"))).get("offsite") or {}
    except Exception as e:
        return write_status({"ok": False, "error": f"Einstellungen nicht lesbar: {e}"})
    if not cfg.get("enabled"):
        return write_status({"ok": True, "skipped": True, "error": ""})
    target = cfg.get("dir") or ""
    if not re.fullmatch(r"/mnt/[A-Za-z0-9._/-]+", target) or ".." in target:
        return write_status({"ok": False, "error": "Ungültiger Zielordner (muss unter /mnt/ liegen)."})
    mr = mount_root(target)
    if not mr or mr == "/":
        return write_status({"ok": False, "error": f"Die Storage Box ist nicht eingebunden ({target} liegt auf keinem eingebundenen Laufwerk)."})
    try:
        os.makedirs(target, exist_ok=True)
    except Exception as e:
        return write_status({"ok": False, "error": f"Ordner auf der Storage Box nicht anlegbar: {e}"})
    files = sorted((f for f in os.listdir(BK) if f.endswith(".tar.gz")), key=lambda f: os.path.getmtime(os.path.join(BK, f))) if os.path.isdir(BK) else []
    if not files:
        return write_status({"ok": False, "error": "Noch keine Sicherung vorhanden."})
    newest = files[-1]
    pw = cfg.get("pass") or ""
    dest_name = newest + (".enc" if pw else "")
    dest = os.path.join(target, dest_name)
    try:
        if not os.path.exists(dest):
            tmp = dest + ".part"
            if pw:
                env = dict(os.environ, OMPASS=pw)
                r = subprocess.run(["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-iter", "200000", "-salt",
                                    "-in", os.path.join(BK, newest), "-out", tmp, "-pass", "env:OMPASS"],
                                   capture_output=True, text=True, env=env, timeout=600)
                if r.returncode:
                    raise RuntimeError("openssl: " + (r.stderr.strip() or "Fehler"))
            else:
                shutil.copyfile(os.path.join(BK, newest), tmp)
            os.replace(tmp, dest)
        keep = max(3, min(365, int(cfg.get("keep") or 30)))
        mine = sorted(f for f in os.listdir(target) if re.match(r"(nachts|hand|vor-wiederherstellen)-.*\.tar\.gz(\.enc)?$", f))
        for f in mine[:-keep]:
            try:
                os.remove(os.path.join(target, f))
            except OSError:
                pass
        mine = sorted(f for f in os.listdir(target) if re.match(r"(nachts|hand|vor-wiederherstellen)-.*\.tar\.gz(\.enc)?$", f))
        write_status({"ok": True, "error": "", "last_file": dest_name, "count": len(mine), "encrypted": bool(pw),
                      "size": os.path.getsize(dest)})
    except Exception as e:
        write_status({"ok": False, "error": str(e)})


if __name__ == "__main__":
    main()
