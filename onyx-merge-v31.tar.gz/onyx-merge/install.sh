#!/bin/bash
# Onyx Merge installieren oder aktualisieren (ausführen mit: sudo bash install.sh)
# Für spätere Updates bequemer: sudo onyx-merge update onyx-merge.tar.gz  (mit Selbsttest und automatischem Rückweg)
set -e
cd "$(dirname "$0")"
echo "== Dateien nach /opt/onyx-merge"
mkdir -p /opt/onyx-merge/data /opt/onyx-merge/ui /opt/onyx-merge/tests
cp onyx_merge.py admin.html apply_domains.py speedtest.html me.html offsite.py /opt/onyx-merge/
cp ui/* /opt/onyx-merge/ui/
cp tests/* /opt/onyx-merge/tests/
chown -R ubuntu:ubuntu /opt/onyx-merge
chown root:root /opt/onyx-merge/apply_domains.py /opt/onyx-merge/offsite.py
chmod 755 /opt/onyx-merge/apply_domains.py /opt/onyx-merge/offsite.py
chmod 700 /opt/onyx-merge/data
install -m 755 onyx-merge-cli.sh /usr/local/bin/onyx-merge
echo "== Dienste einrichten"
cp onyx-merge.service onyx-merge-domains.service onyx-merge-domains.path \
   onyx-merge-offsite.service onyx-merge-offsite.path onyx-merge-offsite.timer /etc/systemd/system/
# Nginx: bei einem Startfehler nach 30 s erneut versuchen, statt liegen zu bleiben
mkdir -p /etc/systemd/system/nginx.service.d
printf "[Service]\nRestart=on-failure\nRestartSec=30\n" > /etc/systemd/system/nginx.service.d/restart.conf
systemctl daemon-reload
systemctl enable onyx-merge >/dev/null; systemctl restart onyx-merge
systemctl enable --now onyx-merge-domains.path onyx-merge-offsite.path onyx-merge-offsite.timer >/dev/null
sleep 2
systemctl is-active onyx-merge
echo "== Nginx: Domains aus der Verwaltung eintragen (Sicherung + Prüfung inklusive)"
/usr/bin/python3 /opt/onyx-merge/apply_domains.py
grep -h server_name /etc/nginx/sites-enabled/* || true
echo "== Test (ohne Anfrage an einen Anbieter)"
for i in $(seq 1 20); do  # nach dem Neustart braucht der Merger ein paar Sekunden
  CODE=$(curl -s -m 5 -o /dev/null -w "%{http_code}" http://127.0.0.1:8090/logos/x || true)
  [ "$CODE" != "000" ] && break; sleep 1
done
echo "Onyx Merge antwortet: $CODE (404 ist hier richtig – das Test-Logo gibt es nicht)"
echo "FERTIG. Verwaltung per SSH-Tunnel: http://localhost:8091  ·  Werkzeug: onyx-merge status"
