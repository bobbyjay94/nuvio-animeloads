@echo off
chcp 65001 >nul
setlocal
title Onyx Merge - Update
rem ---------------------------------------------------------------
rem  Onyx Merge: neuestes Paket aus "Downloads" hochladen und einspielen.
rem  Doppelklick genuegt. Fragt vorher nach. Speichert keine Passwoerter.
rem ---------------------------------------------------------------
set "HOST=ubuntu@51.38.64.30"
set "PORT=48221"
set "DL=%USERPROFILE%\Downloads"

set "PKG="
for /f "delims=" %%F in ('dir /b /o-d "%DL%\onyx-merge-v*.tar.gz" 2^>nul') do if not defined PKG set "PKG=%%F"
if not defined PKG (
  echo Kein Paket "onyx-merge-v...tar.gz" in "%DL%" gefunden.
  pause
  exit /b 1
)

echo.
echo   Neuestes Paket:  %PKG%
echo   Server:          %HOST%  (Port %PORT%)
echo.
echo   Hinweis: Waehrend das Update laeuft, bitte NICHT ins Fenster klicken.
echo.
choice /c JN /m "Jetzt hochladen und einspielen"
if errorlevel 2 exit /b 0

echo.
echo == 1/2 Hochladen ...
scp -P %PORT% "%DL%\%PKG%" %HOST%:~/
if errorlevel 1 (
  echo.
  echo Hochladen hat nicht geklappt. Ist das Internet da und der Server erreichbar?
  pause
  exit /b 1
)

echo.
echo == 2/2 Einspielen ...
ssh -t -p %PORT% %HOST% "sudo onyx-merge update ~/%PKG%"

echo.
echo Fertig. Im Admin einmal F5 druecken.
pause
