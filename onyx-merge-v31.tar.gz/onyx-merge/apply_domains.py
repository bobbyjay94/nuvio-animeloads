#!/usr/bin/env python3
"""Onyx Merge – Domains in Nginx eintragen (läuft als root, ausgelöst durch onyx-merge-domains.path).

Liest /opt/onyx-merge/data/domains.json und
  1. schreibt /etc/nginx/sites-available/onyx-merge mit genau diesen Domains (Port 80 und 8080),
  2. nimmt dieselben Domains aus allen anderen Nginx-Seiten heraus (die Originale werden beim
     ersten Anfassen unter /root/onyx-merge-nginx-orig/ gesichert und immer daraus neu erzeugt –
     eine Domain, die du wieder entfernst, landet also automatisch wieder beim alten Server-Block),
  3. prüft mit "nginx -t", lädt neu – oder stellt bei einem Fehler alles zurück.
Ergebnis steht in data/domains.status.json (sichtbar in der Verwaltung).
Aufruf mit --restore setzt alle anderen Seiten auf ihr Original zurück (für uninstall.sh).
"""
import json, os, re, shutil, socket, subprocess, sys, time, pwd

HOME = os.environ.get("ONYX_MERGE_HOME", "/opt/onyx-merge")
DATA = os.path.join(HOME, "data")
NGX = os.environ.get("ONYX_NGINX_DIR", "/etc/nginx")
SITE = NGX + "/sites-available/onyx-merge"
LINK = NGX + "/sites-enabled/onyx-merge"
ORIG = os.environ.get("ONYX_NGINX_ORIG", "/root/onyx-merge-nginx-orig")
DOMAIN_RE = re.compile(r"^(?=.{4,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")
PLACEHOLDER = "onyx-legacy.invalid"


def names_for(domains):
    out = []
    for d in domains:
        out.append(d)
        if d.count(".") == 1:
            out.append("www." + d)
    return out


def site_conf(names):
    sn = " ".join(names) if names else "onyx-merge.invalid"
    return f"""# Von Onyx Merge erzeugt – Domains in der Verwaltung ändern, nicht hier.
server {{
    listen 80;
    listen [::]:80;
    listen 8080;
    listen [::]:8080;
    server_name {sn};
    server_tokens off;
    access_log off;
    location / {{
        proxy_pass http://127.0.0.1:8090;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Port $server_port;
        # M14: Nginx puffert Listenabrufe für langsame Clients
        proxy_buffering on;
        proxy_buffer_size 128k;
        proxy_buffers 16 128k;
        proxy_busy_buffers_size 256k;
        proxy_temp_file_write_size 256k;
        proxy_max_temp_file_size 128m;
        proxy_read_timeout 120s;
        client_max_body_size 1m;
    }}
}}
"""


def other_sites():
    for n in sorted(os.listdir(NGX + "/sites-enabled")):
        f = os.path.realpath(os.path.join(NGX + "/sites-enabled", n))
        if f != os.path.realpath(SITE) and os.path.isfile(f):
            yield f


def orig_path(f):
    return os.path.join(ORIG, f.strip("/").replace("/", "__"))


def strip_names(text, names):
    drop = set(names)
    def fix(m):
        kept = [x for x in m.group(2).split() if x.lower() not in drop]
        return m.group(1) + " ".join(kept or [PLACEHOLDER]) + ";"
    return re.sub(r"(\bserver_name\s+)([^;]*);", fix, text)


def local_ips():
    try:
        return set(subprocess.run(["hostname", "-I"], capture_output=True, text=True).stdout.split())
    except Exception:
        return set()


def write_status(st):
    p = os.path.join(DATA, "domains.status.json")
    with open(p, "w") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    try:
        u = pwd.getpwnam("ubuntu"); os.chown(p, u.pw_uid, u.pw_gid)
    except Exception:
        pass


def main():
    os.makedirs(ORIG, mode=0o700, exist_ok=True)
    if "--restore" in sys.argv:
        for n in os.listdir(ORIG):
            target = "/" + n.replace("__", "/")
            shutil.copy2(os.path.join(ORIG, n), target)
        print("Original-Seiten wiederhergestellt.")
        return
    try:
        with open(os.path.join(DATA, "domains.json")) as f:
            domains = json.load(f).get("domains", [])
    except FileNotFoundError:
        domains = []
    domains = [d for d in domains if DOMAIN_RE.match(d)]
    names = names_for(domains)

    backup = {}
    for f in list(other_sites()) + [SITE]:
        if os.path.exists(f):
            backup[f] = open(f).read()
    had_link = os.path.islink(LINK)
    try:
        for f in other_sites():
            o = orig_path(f)
            if not os.path.exists(o):
                shutil.copy2(f, o)
            new = strip_names(open(o).read(), names)
            if new != open(f).read():
                open(f, "w").write(new)
        open(SITE, "w").write(site_conf(names))
        if not had_link:
            os.symlink(SITE, LINK)
        t = subprocess.run(["nginx", "-t"], capture_output=True, text=True)
        if t.returncode != 0:
            raise RuntimeError(t.stderr.strip().splitlines()[-1] if t.stderr.strip() else "nginx -t fehlgeschlagen")
        subprocess.run(["systemctl", "reload", "nginx"], check=True)
        ok, err = True, ""
    except Exception as e:
        for f, text in backup.items():
            open(f, "w").write(text)
        if not had_link and os.path.islink(LINK):
            os.remove(LINK)
        subprocess.run(["nginx", "-t"], capture_output=True)
        subprocess.run(["systemctl", "reload", "nginx"])
        ok, err = False, str(e)

    mine = local_ips()
    dns = {}
    for d in names:
        try:
            ips = sorted({a[4][0] for a in socket.getaddrinfo(d, 80, socket.AF_INET)})
        except Exception:
            ips = []
        dns[d] = {"ips": ips, "here": bool(set(ips) & mine)}
    write_status({"ok": ok, "error": err, "applied": int(time.time()), "names": names, "dns": dns})
    print(("OK: " if ok else "FEHLER: ") + (", ".join(names) or "(keine Domains)") + ((" – " + err) if err else ""))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
