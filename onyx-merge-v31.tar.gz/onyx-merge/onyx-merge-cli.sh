#!/bin/bash
# onyx-merge – Werkzeug für den Server. Wird nach /usr/local/bin/onyx-merge installiert.
#   sudo onyx-merge update DATEI.tar.gz   neue Version: Selbsttest, Sicherung, einspielen, prüfen – sonst automatisch zurück
#   sudo onyx-merge rollback              zurück zur vorherigen Version
#   onyx-merge status                     läuft alles? Version, Dienste, Verbindung zum Anbieter
#   sudo onyx-merge selftest              Selbsttest der installierten Version (fragt keinen Anbieter an)
#   sudo onyx-merge tailscale on|off      Verwaltung über Tailscale erreichbar machen / wieder abschalten
set -u
APP=/opt/onyx-merge
PREV=$APP/prev
CODE="onyx_merge.py admin.html apply_domains.py speedtest.html me.html offsite.py"
G=$'\e[32m'; R=$'\e[31m'; Y=$'\e[33m'; N=$'\e[0m'

admin_port() { python3 -c "import json;print(json.load(open('$APP/data/config.json')).get('admin_listen','127.0.0.1:8091').rsplit(':',1)[1])" 2>/dev/null || echo 8091; }
cur_version() { curl -s -m 5 "http://127.0.0.1:$(admin_port)/api/version" | python3 -c "import json,sys;print(json.load(sys.stdin)['version'])" 2>/dev/null; }
need_root() { [ "$(id -u)" = 0 ] || { echo "Bitte mit sudo ausführen: sudo onyx-merge $*"; exit 1; }; }
healthy() {  # wartet bis zu 40 s, bis der Merger antwortet
  for _ in $(seq 1 40); do v=$(cur_version); [ -n "$v" ] && { echo "$v"; return 0; }; sleep 1; done; return 1; }

save_prev() {
  rm -rf "$PREV"; mkdir -p "$PREV/ui"
  for f in $CODE; do [ -f "$APP/$f" ] && cp -p "$APP/$f" "$PREV/"; done
  cp -rp "$APP/ui/." "$PREV/ui/" 2>/dev/null || true
  [ -d "$APP/tests" ] && cp -rp "$APP/tests" "$PREV/" || true
}
restore_prev() {
  [ -f "$PREV/onyx_merge.py" ] || { echo "${R}Keine vorherige Version gespeichert.${N}"; return 1; }
  for f in $CODE; do [ -f "$PREV/$f" ] && cp -p "$PREV/$f" "$APP/"; done
  cp -rp "$PREV/ui/." "$APP/ui/" 2>/dev/null || true
  [ -d "$PREV/tests" ] && { rm -rf "$APP/tests"; cp -rp "$PREV/tests" "$APP/"; } || true
  chown -R ubuntu:ubuntu "$APP"; chown root:root "$APP/apply_domains.py" "$APP/offsite.py" 2>/dev/null; chmod 700 "$APP/data"
  systemctl restart onyx-merge
}

case "${1:-}" in
update)
  need_root "$@"
  F="${2:-}"; [ -f "$F" ] || { echo "Aufruf: sudo onyx-merge update onyx-merge.tar.gz"; exit 1; }
  T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
  tar xzf "$F" -C "$T" || { echo "${R}Datei lässt sich nicht entpacken.${N}"; exit 1; }
  S="$T/onyx-merge"; [ -f "$S/onyx_merge.py" ] || S="$T"
  [ -f "$S/onyx_merge.py" ] || { echo "${R}Im Paket fehlt onyx_merge.py.${N}"; exit 1; }
  OLD=$(cur_version); echo "== Installiert: ${OLD:-unbekannt}"
  echo "== Selbsttest der neuen Version (fragt keinen Anbieter an, dauert ca. 20 s)"
  chmod -R a+rX "$T"
  if ! sudo -u ubuntu python3 "$S/tests/selftest.py" "$S"; then
    echo "${R}Selbsttest fehlgeschlagen – an der laufenden Installation wurde nichts geändert.${N}"; exit 1; fi
  echo "== Sicherung der Daten"
  curl -s -m 30 -X POST -H 'Content-Type: application/json' -d '{}' "http://127.0.0.1:$(admin_port)/api/backup" >/dev/null && echo "angelegt" || echo "${Y}Sicherung über die Verwaltung nicht möglich – weiter mit der nächtlichen.${N}"
  echo "== Alte Version merken"; save_prev
  echo "== Einspielen"; (cd "$S" && bash install.sh) || true
  if NEW=$(healthy); then
    echo "${G}FERTIG: Version $NEW läuft.${N} (vorher: ${OLD:-unbekannt}) – zurück jederzeit mit: sudo onyx-merge rollback"
  else
    echo "${R}Die neue Version antwortet nicht – ich stelle die vorherige wieder her …${N}"
    restore_prev
    if V=$(healthy); then echo "${Y}Zurück auf Version $V. Bitte das Protokoll prüfen: journalctl -u onyx-merge -n 50${N}"
    else echo "${R}Auch die vorherige Version startet nicht. Protokoll: journalctl -u onyx-merge -n 50${N}"; fi
    exit 1
  fi ;;
rollback)
  need_root "$@"
  echo "== Zurück zur vorherigen Version"; restore_prev || exit 1
  if V=$(healthy); then echo "${G}Version $V läuft.${N}"; else echo "${R}Startet nicht – journalctl -u onyx-merge -n 50${N}"; exit 1; fi ;;
selftest)
  need_root "$@"
  sudo -u ubuntu python3 "$APP/tests/selftest.py" "$APP" ;;
status)
  V=$(cur_version)
  echo "Onyx Merge:   $([ -n "$V" ] && echo "${G}läuft, Version $V${N}" || echo "${R}antwortet nicht${N}")"
  for s in nginx onyx-merge cdn-failover; do printf "%-13s %s\n" "$s:" "$(systemctl is-active $s 2>/dev/null)"; done
  IP=$(getent hosts tv.business-cloud-8.ru | awk '{print $1; exit}')
  [ -n "$IP" ] && echo "Anbieter 1:   $IP über $(ip route get "$IP" 2>/dev/null | grep -o 'src [0-9.]*')"
  ip -4 addr show tailscale0 2>/dev/null | grep -q inet && echo "Tailscale:    $(ip -4 addr show tailscale0 | grep -o 'inet [0-9.]*' | cut -d' ' -f2)" ;;
tailscale)
  need_root "$@"
  case "${2:-}" in
  on)
    command -v tailscale >/dev/null || { echo "Tailscale ist noch nicht installiert. Erst: curl -fsSL https://tailscale.com/install.sh | sh  und  sudo tailscale up --hostname onyx-vps"; exit 1; }
    TSIP=$(tailscale ip -4 2>/dev/null | head -1); [ -n "$TSIP" ] || { echo "Tailscale ist installiert, aber nicht angemeldet: sudo tailscale up --hostname onyx-vps"; exit 1; }
    python3 - <<PY
import json; p="$APP/data/config.json"; c=json.load(open(p)); c["admin_remote"]="tailscale"; json.dump(c,open(p,"w"),ensure_ascii=False,indent=1)
PY
    ufw allow in on tailscale0 to any port "$(admin_port)" proto tcp >/dev/null 2>&1 || true
    systemctl restart onyx-merge; sleep 2
    echo "${G}Verwaltung jetzt erreichbar unter:  http://onyx-vps:$(admin_port)  (oder http://$TSIP:$(admin_port))${N}"
    echo "Nur Geräte in deinem Tailscale-Netz kommen dran – aus dem Internet bleibt sie gesperrt." ;;
  off)
    python3 - <<PY
import json; p="$APP/data/config.json"; c=json.load(open(p)); c["admin_remote"]="off"; json.dump(c,open(p,"w"),ensure_ascii=False,indent=1)
PY
    ufw delete allow in on tailscale0 to any port "$(admin_port)" proto tcp >/dev/null 2>&1 || true
    systemctl restart onyx-merge; echo "Verwaltung wieder nur per SSH-Tunnel erreichbar." ;;
  *) echo "Aufruf: sudo onyx-merge tailscale on|off" ;;
  esac ;;
version) V=$(cur_version); echo "${V:-läuft nicht}" ;;
*) sed -n '2,8p' "$0" | sed 's/^# \{0,1\}//' ;;
esac
