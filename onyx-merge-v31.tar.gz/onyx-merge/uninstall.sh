#!/bin/bash
# Onyx Merge entfernen und Nginx auf den Stand davor zuruecksetzen (sudo bash uninstall.sh)
systemctl disable --now onyx-merge-domains.path onyx-merge-offsite.path onyx-merge-offsite.timer 2>/dev/null
[ -f /opt/onyx-merge/apply_domains.py ] && /usr/bin/python3 /opt/onyx-merge/apply_domains.py --restore
rm -f /etc/nginx/sites-enabled/onyx-merge /etc/nginx/sites-available/onyx-merge
nginx -t && systemctl reload nginx
systemctl disable --now onyx-merge 2>/dev/null
rm -f /etc/systemd/system/onyx-merge.service /etc/systemd/system/onyx-merge-domains.* /etc/systemd/system/onyx-merge-offsite.* /usr/local/bin/onyx-merge; systemctl daemon-reload
echo "Entfernt. Daten liegen noch unter /opt/onyx-merge (bei Bedarf: sudo rm -rf /opt/onyx-merge)"
