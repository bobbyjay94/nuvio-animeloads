#!/usr/bin/env python3
"""
Onyx Merge – ein Xtream-Login, eine kuratierte Liste aus zwei Anbietern.

Grundsätze (damit der Anbieter den Server nicht sperrt):
  * Kataloge werden EINMAL pro Nacht pro Anbieter mit EINEM Zugang geladen (langsam, mit Pausen).
  * Anmeldungen der Benutzer prüft dieser Dienst selbst – der Anbieter wird dabei nicht gefragt.
  * Streams laufen nie über den Server: der Player wird mit dem EIGENEN Anbieter-Zugang des
    Benutzers direkt zum Anbieter weitergeleitet (HTTP 302).
  * Film-/Serien-Details werden erst beim ersten Anklicken geholt und 24 h gespeichert;
    alle Anfragen an einen Anbieter laufen durch eine Bremse (höchstens eine alle paar Sekunden).

Nur Python-Standardbibliothek. Daten liegen in $ONYX_MERGE_HOME/data (Standard /opt/onyx-merge/data).
"""
from __future__ import annotations

import base64
import collections
import gc
import gzip
import hashlib
import http.client
import ipaddress
import hmac
import json, sys
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(line_buffering=True)
if hasattr(sys.stderr, "reconfigure"): sys.stderr.reconfigure(line_buffering=True)
import logging
import os
import random
import re
import secrets
import shutil
import socket
import subprocess
import sqlite3
import tarfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from zoneinfo import ZoneInfo

HOME = os.environ.get("ONYX_MERGE_HOME", "/opt/onyx-merge")
DATA = os.path.join(HOME, "data")
CACHE = os.path.join(DATA, "cache")
TPL_DIR = os.path.join(DATA, "templates")
LOGO_DIR = os.path.join(DATA, "logos")
os.makedirs(LOGO_DIR, exist_ok=True)
os.makedirs(CACHE, exist_ok=True)
os.makedirs(TPL_DIR, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("onyx-merge")

# Virtuelle Nummern: Anbieter A behält seine Nummern, B wird verschoben (keine Überschneidungen).
STREAM_OFFSET = {"A": 0, "B": 1_000_000_000}
CAT_OFFSET = {"A": 0, "B": 1_000_000}
KINDS = ("live", "vod", "series")
UA = "okhttp/4.12.0"
VERSION = "2026.11.05.25"
CHANGES = [
    ("2026.11.05.25", [
        "Editor: IST-Zustand der Kategorien als Paket/Kunden-Vorlage speichern – per Klick aus dem Editor-Aktionsmenü",
        "Pakete: Neue Pakete können sofort aus aktuell aktiven/sichtbaren Kategorien generiert werden",
        "API: Neuer Endpunkt /api/package_from_state zum Erfassen sichtbarer Kategorien für Live, VOD und Serien",
    ]),
    ("2026.11.05.24", [
        "Editor: Intelligenter Logo-Matcher (Paket F) – findet fehlende Logos automatisch bei Varianten/Sendern gleichen Namens",
        "Sicherheit: 100% lokale Zuordnung im Server-RAM – keine externen Anfragen, null Belastung der Provider-IPs",
        "Editor UI: Logo-Button in der Senderleiste (⚡ Logo-Matcher) mit Live-Vorschau und sicherer Rückgängig-Funktion (Undo)",
        "API: /api/match_logos mit flexibler Vorschau und Übernahme für einzelne Sender, Kategorien oder den gesamten Bereich",
    ]),
    ("2026.11.05.23", [
        "Editor: Intelligenter Name-Cleaner für ausgewählte oder alle Einträge – entfernt Länderkürzel (DE |, [DE]), Deko, Emojis, Werbewörter (VIP) und Klammerreste",
        "Editor: Qualitäts-Tag-Vereinheitlichung – erkennt 4K, UHD, FHD, 1080p, HD, 720p, SD und bringt sie in eine saubere, einheitliche Schreibweise am Namensende",
        "Editor: Smart Auto-Sort – neue Sortiermodi 'A–Z (bereinigt)' (ignoriert DE |, Deko und VIP) sowie 'Nach Qualität (4K → FHD → HD)' für beste Auflösung zuerst",
        "API: /api/clean_names mit Live-Vorschau und sicherer Rückgängig-Funktion (Undo über Journal)",
    ]),
    ("2026.11.05.22", [
        "Editor: Fusions-Badges (🔀 +X) an Hauptkategorien und Hinweise (→ in Hauptkategorie) an Quellkategorien",
        "Editor: Detail-Leiste über der Senderliste zeigt fusionierte Kategorien mit 1-Klick-Trennen",
        "API: /api/unfuse_cat trennt zuvor fusionierte Kategorien sauber und blendet sie wieder eigenständig ein",
    ]),
    ("2026.11.05.21", [
        "Editor: Mehrfachauswahl und Massen-Umbenennen jetzt nahtlos für Live-TV, Filme und Serien verfügbar",
        "Editor: Neue Fusionieren-Funktion führt ab 2 markierten Kategorien alle Inhalte in die zuerst gewählte Kategorie zusammen und blendet die übrigen automatisch aus",
        "Verwaltung: Neues kompaktes Update-Fenster mit Versionen-Akkordeon (auf Klick aufklappbar) und fest erreichbarem Schließen-Button – optimal für Smartphones und Desktop",
    ]),  # „Was ist neu“ im Admin – neueste zuerst
    ("2026.11.05.20", ["1-Klick-IP-Wechsel bei Sperre (I12): Erkennt Onyx Merge eine Anbietersperre oder Probleme mit der Server-IP, kannst du unter Betrieb mit einem Klick auf deine Reserve-IP oder Haupt-IP wechseln",
                       "Sichere Bestätigung: Der Wechsel erfolgt erst nach deiner Freigabe; die Verbindung zum Anbieter wird sofort getestet und das Ergebnis angezeigt",
                       "Automatische IP-Erkennung: Alle auf dem Server verfügbaren IPv4-Adressen (Haupt-IP, Failover-IPs) werden automatisch erkannt und zur Auswahl angeboten",
                       "Reserve-IP-Verwaltung: Unter Betrieb können zusätzliche Reserve-IPs für Notfälle hinterlegt werden",
                       "Telegram-Benachrichtigung mit Handlungshinweis: Bei Sperrverdacht weist dich die Nachricht direkt auf den vorbereiteten 1-Klick-Wechsel hin"]),
    ("2026.11.05.19", ["Abgleich-Schutz (I3): Ist der Katalog eines Anbieters plötzlich unvollständig oder leer, wird der Abgleich abgebrochen und die funktionierende Senderliste bleibt geschützt",
                       "Nächtliche Wartung (I4): Datenbanken (EPG, Statistik, Diagnose) werden jede Nacht automatisch bereinigt und verdichtet (VACUUM); alte Verläufe werden aufgeräumt",
                       "Speicher-Wächter (I6): Nähert sich der Arbeitsspeicher der Obergrenze, leert Onyx Merge automatisch Zwischenspeicher, um Lastspitzen abzufedern",
                       "Schlankeres EPG (I9): Das Programm wird nur noch für Sender gespeichert, die du auch sichtbar geschaltet hast – das spart Speicherplatz und beschleunigt EPG-Abrufe",
                       "Wochenbericht (I10): Jeden Sonntag um 10:00 Uhr fasst Onyx Merge aktive Kunden, Server-Last und Anbieter-Status in einer Telegram-Nachricht zusammen",
                       "Abgelehnte Logins auswerten (I11): Bei abgelehnten Anmeldungen (falsche Domain, abgelaufen, falsches Passwort) gibt es direkt eine fertige Hilfenachricht für den Kunden"]),
    ("2026.11.05.18", ["Dienst-Schutz: Nginx und Jellyfin behalten bei hoher Last immer Vorrang (Nice=5); Arbeitsspeicher des Mergers ist fest begrenzt (max. 3 GB)",
                       "Automatischer Wächter (Watchdog): Bleibt der Dienst länger als 2 Minuten hängen, startet systemd ihn selbstständig neu",
                       "Nginx-Pufferung: Große Senderlisten, Filme und EPG werden von Nginx im RAM gepuffert – der Merger ist nach wenigen Millisekunden wieder frei für den nächsten Kunden",
                       "Sichere Einstellungen: Nginx-Konfiguration wird vor jedem Neuladen automatisch geprüft (nginx -t) mit Rollback bei Fehlern"]),
    ("2026.11.05.17", ["Schutz vor Überlastung: Feste Zeitgrenzen (60 s für Apps, 120 s Admin) und maximal 64 gleichzeitige Anfragen verhindern blockierte Server-Threads",
                       "Speicher-Grenze: Der Zwischenspeicher für Listen räumt sich bei 300 MB automatisch selbst auf (LRU)",
                       "Katalog deutlich schneller speichern: Kompakte Speicherung halbiert die Schreibzeit und schont die Festplatte",
                       "Betrieb: Neue Fehlerübersicht mit den letzten 50 Meldungen sowie genaue Antwortzeiten (p50/p95) nach Endpunkt direkt im Admin"]),
    ("2026.11.05.16", ["Schneller und stabiler im Hintergrund: Fragen mehrere Apps gleichzeitig dieselbe Liste an, wird sie nur einmal gebaut – auch über verschiedene Domains",
                       "Live-Kategorien („Heute live“) werden in unter einer Sekunde statt in bis zu 40 Sekunden berechnet",
                       "Programm (EPG) für die Apps wird zwischengespeichert und komprimiert ausgeliefert",
                       "Sicheres Speichern: keine Fehlermeldungen mehr bei gleichzeitigem Speichern, Sicherheitskopie wichtiger Dateien, beschädigte Dateien werden beiseitegelegt und gemeldet statt überschrieben",
                       "Datenbanken bleiben lesbar, während das Programm eingespielt wird",
                       "Nie zwei Abgleiche gleichzeitig"]),
    ("2026.11.05.15", ["IP-Sperre: Sieht der Merger im normalen Verkehr einen Verdacht, prüft er selbst einmal nach (1 Anmeldung, höchstens stündlich) und meldet sich per Telegram",
                       "Kopfzeile: „Nicht gespeichert / Speichern“ passt auch auf kleinere Bildschirme"]),
    ("2026.11.05.14", ["Sender-Test: ✓ läuft / ✕ läuft nicht – in der Liste oder im Test-Player (Tasten L und N), danach startet der nächste ungetestete Sender; Filter „noch nicht getestet“ und Fortschritt je Kategorie",
                       "Betrieb: Server-Last (Prozessor, Arbeitsspeicher, Antwortzeit an die Apps) mit Telegram-Warnung",
                       "Betrieb: „Server-IP beim Anbieter“ – zeigt, ob der Anbieter deinen Server annimmt; mit „Jetzt prüfen“ (1 Anmeldung) und Gegenprobe von deinem PC; Telegram bei Verdacht",
                       "Übersicht: die wichtigsten Zahlen oben als Kacheln; Technik-Hinweise zusammengefasst",
                       "Übernehmen aus „Durchgereicht“: gleich mit Paketen, Zusatz-Line und Handynummer",
                       "Kunden: Rundnachricht per WhatsApp an alle oder markierte Kunden (Vorlagen: Störung, Wartung, neue Adresse …)",
                       "Kundenseite „Mein Zugang“: Knopf „Verlängern anfragen“ (wenn deine WhatsApp-Nummer eingetragen ist)",
                       "Länder: Kategorien ohne Länderkürzel werden über ihre Sender einem Land zugeordnet",
                       "Editor: große Kategorien laufen flüssig (es werden nur sichtbare Zeilen gezeichnet)",
                       "Erinnerung, wenn Änderungen an der Senderliste über 2 Stunden ungespeichert sind",
                       "Optik: Einstellungen in Reitern, Kundenliste aufgeräumt („+ Zusatz“), bessere Handy-Ansicht, hilfreichere leere Seiten"]),
    ("2026.11.05.13", ["Editor: mehrere Kategorien mit Strg-/Shift-Klick markieren – gemeinsam umbenennen, ein- oder ausblenden"]),
    ("2026.11.05.12", ["Editor: Kategorie-Liste deutlich größer – Knöpfe kompakt in einer Zeile (weitere unter „⋯“), engere Zeilen, Liste am rechten Rand breiter ziehbar"]),
    ("2026.11.05.11", ["Senderliste mit „Speichern“: Änderungen sind erst ein Entwurf – deine Kunden sehen sie, wenn du oben auf „Speichern“ drückst (oder Strg+S). „Verwerfen“ nimmt alles seit dem letzten Speichern zurück.",
                       "Der nächtliche Abgleich geht wie bisher direkt raus – außer du hast gerade ungespeicherte Änderungen, dann wartet er auf dein Speichern"]),
    ("2026.11.05.10", ["Varianten zusammen: „3840P“, „2160P“ und „8K“ zählen als 4K – „beIN SPORTS 1 4K 3840P“ steht bei beIN SPORTS 1"]),
    ("2026.11.05.9", ["Varianten zusammen: Kapitälchen („ʜᴅ“) und einzelne hochgestellte Zeichen werden erkannt – alle beIN SPORTS 1 stehen zusammen"]),
    ("2026.11.05.8", ["Varianten zusammen: Ball-Zeichen mit Emoji-Zusatz erkannt; eigene Namen zählen, wenn sie zu einem anderen Sender der Kategorie passen"]),
    ("2026.11.05.7", ["Verschobene Sender landen automatisch bei ihren Varianten – deine übrige Reihenfolge bleibt",
                      "Editor: markierte Sender „Ganz oben“, „Ganz unten“ oder Zeile für Zeile (auch Alt+↑/↓, Alt+Pos1/Ende)",
                      "„Verschieben nach …“ mit Suche statt langer Liste – zuletzt benutzte Ziele stehen oben",
                      "Varianten-Erkennung: Ball als O („SP⚽RTS“ = SPORTS), Vorsätze wie „GOLD:“ zählen nicht mehr"]),
    ("2026.11.05.6", ["Verschobene Sender werden in der Ziel-Kategorie automatisch zu ihren Varianten sortiert"]),
    ("2026.11.05.5", ["Sortieren ordnet nach dem Original-Namen des Anbieters zu – selbst umbenannte Sender bleiben bei ihren Varianten"]),
    ("2026.11.05.4", ["Sortieren-Menü öffnet sich rechtsbündig, wenn der Knopf am rechten Rand sitzt"]),
    ("2026.11.05.3", ["Editor: „Sortieren“ – Varianten eines Senders mit einem Klick untereinander (4K, FHD, HD, SD, Backup zuletzt), A–Z oder wie beim Anbieter"]),
    ("2026.11.05.2", ["Editor: Suche mit einem Klick auf × (oder Esc) löschen – nimmt auch „in allen Kategorien“ wieder raus"]),
    ("2026.11.05.1", ["Admin deutlich schneller: Ein Klick baut nur noch den betroffenen Bereich neu (Live, Filme oder Serien) – statt über 3 s jetzt unter 0,5 s",
                      "Logo von einem anderen Sender übernehmen: im Logo-Fenster suchen oder eine Variante desselben Senders anklicken"]),
    ("2026.11.04.12", ["Aufräumen ohne „Varianten“: Sender blendest du nur noch selbst aus, nachdem du sie getestet hast"]),
    ("2026.11.04.11", ["Aufräumen → Auswählen: alles ausblenden und dann nur anhaken, was Kunden sehen sollen – nach Ländern sortiert, mit Suche"]),
    ("2026.11.04.10", ["Aufräumen: Trennzeilen der Anbieter („###DE SPORT###“) mit einem Schalter in allen Kategorien ausblenden – auch neue"]),
    ("2026.11.04.9", ["Zusatz-Laufzeit: Das Ablaufdatum der Lines bei Anbieter 2 wird jeden Morgen ausgelesen – mit Erinnerung, Telegram und „Im Panel verlängern“",
                      "„Durchgereicht“ räumt sich selbst auf: abgelehnte Zugänge nach 1 Tag, nie bestätigte nach 3 Tagen",
                      "Abrufe von Scannern landen nicht mehr unter „Durchgereicht“",
                      "Kundenliste: Anzeige „nur …“ bei Kunden ohne Zusatz-Sender korrigiert"]),
    ("2026.11.04.8", ["„Durchgereicht“ merkt sich jetzt auch das Umschalten – Kunden erscheinen, sobald sie einen Sender starten, nicht erst beim nächsten App-Start"]),
    ("2026.11.04.7", ["Überall stehen jetzt deine eigenen Anbieter-Namen statt „Anbieter 1/2“"]),
    ("2026.11.04.6", ["Test-Player im Admin mit Puffer – Streams laufen ruhiger und bleiben seltener hängen"]),
    ("2026.11.04.5", ["Sender testen geht jetzt auch mit dem Sync-Zugang – ganz ohne Kunden-Login"]),
    ("2026.11.04.4", ["Kundenseite „Mein Zugang“: eigener Link pro Kunde mit Gültigkeit, Anleitung und Verbindungstest (ohne Passwort)",
                      "Erinnerungsliste bei den Kunden: wer bald abläuft – mit fertiger WhatsApp-Nachricht; optional Handynummer pro Kunde",
                      "Papierkorb: gelöschte Kunden 30 Tage lang wiederherstellbar",
                      "Hilfe-Knopf „?“ oben – erklärt die jeweilige Seite"]),
    ("2026.11.04.3", ["Feste Absender-IP je Anbieter: Der Merger fragt einen Anbieter immer von dieser IP an – auch wenn der Anbieter umzieht",
                      "Logo-Abruf mit unbekanntem Namen antwortet sofort (Installations-Test hing)"]),
    ("2026.11.04.2", ["Kunden werden geräteübergreifend sicher gespeichert – Handy und PC überschreiben sich nicht mehr",
                      "Benachrichtigungen per Telegram (Nginx-Ausfall, falsche IP, Notstopp, Abgleich, Credits, Ablauf, Sicherung)",
                      "Nächtliche Sicherung zusätzlich verschlüsselt auf die Hetzner Storage Box",
                      "Update mit einem Befehl inkl. Selbsttest und automatischem Rückweg: sudo onyx-merge update DATEI",
                      "Verwaltung optional über Tailscale erreichbar (ohne SSH-Tunnel)",
                      "Einstellungen werden beim Start geprüft"]),
    ("2026.11.04.1", ["Neue Navigation, Aufräumen- und Betrieb-Seite, Durchgereicht, Neuer Kunde, Schnellsuche (Strg+K)"]),
]

DEFAULT_CONFIG = {
    "listen": "127.0.0.1:8090",
    "admin_listen": "127.0.0.1:8091",
    "timezone": "Europe/Berlin",
    "sync_time": "04:17",
    "upstream_min_interval": 3.0,
    "sync_pause": 20,
    "new_categories_visible": True,
    "public_host": "",
    # Anfragen-Wächter: höchstens so viele Anfragen pro Stunde vom VPS an einen Anbieter
    "guard_limit_own": 120,         # Abgleich, EPG, Film-/Serien-Details
    "guard_limit_passthrough": 300,  # durchgereichte Panel-Kunden (darüber: direkte Weiterleitung statt Durchreichen)
    "guard_pause_min": 60,          # Notstopp-Dauer bei Sperr-Anzeichen
    "domains": {"A": ["alternativip.com"], "B": []},  # allgemeine Domains je Anbieter
    "sync_days": {"live": 1, "vod": 3, "series": 3},   # wie oft (Tage) die Listen je Art abgeglichen werden
    "detail_days": {"vod": 14, "series": 1},           # wie lange Film-/Serien-Infos zwischengespeichert bleiben
    "epg_ext": {"mode": "off", "url": ""},             # Programm aus fremder Quelle: off | fill (ergänzen) | only (statt Anbieter)
    "egress_ip": "",                                   # (alt, wird nach "egress" übernommen)
    "egress": {"A": "", "B": ""},                      # feste Absender-IP je Anbieter (z. B. Failover-IP), leer = wie das System routet
    "reserve_ips": [],                                 # bekannte Reserve-IPs (z. B. Failover-IPs) für 1-Klick-Wechsel
    "notify": {"enabled": False, "token": "", "chat_id": "", "chat_name": "", "events": {}},  # Telegram
    "offsite": {"enabled": False, "dir": "/mnt/storagebox/onyx-merge-backups", "pass": "", "keep": 30},
    "admin_remote": "off",                             # "tailscale": Verwaltung auch über Tailscale erreichbar
    "fallback": True,
    "providers": {
        "A": {"name": "Anbieter 1", "url": "http://tv.business-cloud-8.ru", "kinds": ["live", "vod", "series"],
              "sync_user": "", "sync_pass": "", "epg": True},
        "B": {"name": "Anbieter 2", "url": "http://line.liondnscloud.ru:80", "kinds": ["live"],
              "sync_user": "", "sync_pass": "", "epg": True},
    },
}


# ---------------------------------------------------------------- Dateien
def _path(name: str) -> str:
    return os.path.join(DATA, name)


BAK_FILES = ("config.json", "users.json", "curation.json", "curation_pub.json", "passthru.json", "trash.json", "tests.json", "guard.json")
load_problems: list = []  # kaputte Dateien beim Lesen – werden nach dem Start gemeldet


def load_json(name: str, default):
    p = _path(name)
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except Exception as e:  # kaputte Datei: beiseitelegen (nie stillschweigend überschreiben) und melden
        bad = f"{p}.corrupt-{time.strftime('%Y%m%d-%H%M%S')}"
        try:
            os.replace(p, bad)
        except OSError:
            bad = p
        msg = f"Datei {name} war beschädigt ({e}) und wurde als {os.path.basename(bad)} beiseitegelegt."
        if os.path.exists(p + ".bak"):
            try:
                with open(p + ".bak", encoding="utf-8") as f:
                    v = json.load(f)
                log.error("%s Letzte gute Fassung (.bak) wird verwendet.", msg)
                load_problems.append(msg + " Die letzte gute Fassung wurde wiederhergestellt.")
                return v
            except Exception:
                pass
        log.error(msg)
        load_problems.append(msg)
        return default


_file_locks: dict = {}
_file_locks_guard = threading.Lock()


def save_json(name: str, value) -> None:
    """Sicher speichern: eigene Zwischendatei je Vorgang, erst vollständig auf die Platte, dann austauschen.
    Zwei gleichzeitige Speichervorgänge derselben Datei laufen nacheinander."""
    with _file_locks_guard:
        fl = _file_locks.setdefault(name, threading.Lock())
    p = _path(name)
    with fl:
        tmp = f"{p}.{os.getpid()}-{threading.get_ident()}.tmp"
        try:
            for attempt in range(2):
                try:
                    is_cat = name.startswith("catalog_")
                    with open(tmp, "w", encoding="utf-8") as f:
                        if attempt:
                            with lock:  # wurde während des Schreibens geändert -> diesmal festhalten
                                if is_cat:
                                    json.dump(value, f, ensure_ascii=False, separators=(',', ':'))
                                else:
                                    json.dump(value, f, ensure_ascii=False, indent=1)
                        else:
                            if is_cat:
                                json.dump(value, f, ensure_ascii=False, separators=(',', ':'))
                            else:
                                json.dump(value, f, ensure_ascii=False, indent=1)
                        f.flush()
                        os.fsync(f.fileno())
                    break
                except RuntimeError:
                    if attempt:
                        raise
            try:
                os.chmod(tmp, 0o600)
            except OSError:
                pass
            if name in BAK_FILES and os.path.exists(p):
                try:
                    shutil.copyfile(p, p + ".bak")
                    os.chmod(p + ".bak", 0o600)
                except OSError:
                    pass
            os.replace(tmp, p)
        finally:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
        try:
            fd = os.open(DATA, os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        except OSError:
            pass


DOMAIN_RE = re.compile(r"^(?=.{4,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")
lock = threading.RLock()
config = load_json("config.json", None)
if config is None:
    config = json.loads(json.dumps(DEFAULT_CONFIG))
    save_json("config.json", config)
for k, v in DEFAULT_CONFIG.items():
    config.setdefault(k, v)
config_warnings: list = []


def validate_config() -> None:
    """Prüft die Einstellungen beim Start. Kaputte Werte werden auf den Standard gesetzt und in der Übersicht gemeldet,
    statt dass der Server mit seltsamen Werten weiterläuft oder gar nicht startet."""
    def fix(key, why):
        config[key] = json.loads(json.dumps(DEFAULT_CONFIG[key]))
        config_warnings.append(f"Einstellung „{key}“ war ungültig ({why}) und wurde auf den Standard zurückgesetzt.")
    for key in ("listen", "admin_listen"):
        v = config.get(key)
        if not isinstance(v, str) or not re.fullmatch(r"[0-9.]+:\d{2,5}", v):
            fix(key, repr(v))
    for key in ("guard_limit_own", "guard_limit_passthrough", "guard_pause_min", "sync_pause", "upstream_min_interval"):
        v = config.get(key)
        if not isinstance(v, (int, float)) or v < 0:
            fix(key, repr(v))
    if not isinstance(config.get("sync_time"), str) or not re.fullmatch(r"\d{1,2}:\d{2}", config["sync_time"]):
        fix("sync_time", repr(config.get("sync_time")))
    if not isinstance(config.get("providers"), dict) or not config["providers"]:
        fix("providers", "fehlt")
    for k, p in config["providers"].items():
        if not isinstance(p, dict) or not re.fullmatch(r"https?://\S+", str(p.get("url") or "")):
            config_warnings.append(f"Anbieter {k}: Server-Adresse fehlt oder ist ungültig – bitte unter Einstellungen prüfen.")
        elif not isinstance(p.get("kinds"), list):
            p["kinds"] = list(DEFAULT_CONFIG["providers"].get(k, {}).get("kinds", ["live"]))
    for key in ("sync_days", "detail_days", "domains", "epg_ext", "notify", "offsite"):
        if not isinstance(config.get(key), dict):
            fix(key, "kein gültiger Eintrag")
    if not isinstance(config.get("egress"), dict):
        config["egress"] = {"A": str(config.get("egress_ip") or ""), "B": ""}
    if not isinstance(config.get("reserve_ips"), list):
        config["reserve_ips"] = []
    if config.get("admin_remote") not in ("off", "tailscale"):
        fix("admin_remote", repr(config.get("admin_remote")))
    for w in config_warnings:
        log.warning(w)
    if config_warnings:
        save_json("config.json", config)


validate_config()
if not config.get("instance_id"):  # Kennung, damit der Domain-Test sicher DIESEN Server erkennt
    config["instance_id"] = secrets.token_hex(8)
    save_json("config.json", config)
users: list = load_json("users.json", [])


def norm_domain(d) -> str:
    d = str(d or "").strip().lower().removeprefix("http://").removeprefix("https://").split("/")[0].split(":")[0]
    return d.removeprefix("www.") if d.count(".") > 1 and d.startswith("www.") else d


def gen_domains(pk: str) -> list:
    d = config.get("domains") or {}
    if isinstance(d, list):  # alter Stand: eine Liste -> Anbieter 1
        d = config["domains"] = {"A": d, "B": []}
    return list(d.get(pk) or [])


def all_domains() -> list:
    """Allgemeine Domains + alle Benutzer-Domains – genau diese Liste trägt der Helfer in Nginx ein."""
    out = gen_domains("A") + [d for d in gen_domains("B") if d not in gen_domains("A")]
    for u in users:
        for d in u.get("domains") or []:
            if d not in out:
                out.append(d)
    return out


def write_domains_file():
    save_json("domains.json", {"domains": all_domains(), "changed": int(time.time())})
    os.chmod(_path("domains.json"), 0o644)


if not os.path.exists(_path("domains.json")):
    write_domains_file()
curation: dict = load_json("curation.json", {k: {} for k in KINDS})
for k in KINDS:
    curation.setdefault(k, {})
status: dict = load_json("status.json", {})


def tz() -> ZoneInfo:
    try:
        return ZoneInfo(config.get("timezone") or "Europe/Berlin")
    except Exception:
        return ZoneInfo("UTC")


# ---------------------------------------------------------------- Anfragen an Anbieter (mit Bremse)
_last_call: dict = {}
_call_lock: dict = {}
upstream_count = {"A": 0, "B": 0}


# ---------------------------------------------------------------- Anfragen-Wächter
# Schützt die VPS-IP: Obergrenze pro Stunde und Notstopp, sobald ein Anbieter nach Sperre aussieht.
class GuardBlocked(RuntimeError):
    pass


_guard_lock = threading.Lock()
guard: dict = load_json("guard.json", {})
HARD_SIGNS = (511, 429)          # sofortiger Notstopp
SOFT_SIGNS = (403, 502, 503, 520, 521, 522)  # Notstopp beim zweiten Mal innerhalb von 10 Minuten


def _g(pkey: str) -> dict:
    g = guard.setdefault(pkey, {})
    g.setdefault("hours", {})      # "YYYYmmddHH" -> {"own": n, "pass": n, "redirected": n}
    g.setdefault("log", [])        # letzte Ereignisse
    g.setdefault("soft", [])       # Zeitpunkte weicher Warnzeichen
    return g


def _hour_key(t=None) -> str:
    return time.strftime("%Y%m%d%H", time.localtime(t or time.time()))


def guard_save() -> None:
    try:
        save_json("guard.json", guard)
    except Exception as e:
        log.warning("guard.json: %s", e)


def guard_paused(pkey: str) -> float:
    """Sekunden, die der Notstopp noch läuft (0 = keiner)."""
    return max(0.0, float(_g(pkey).get("paused_until", 0)) - time.time())


def guard_pass_paused(pkey: str) -> float:
    """Nur das Weiterreichen ist pausiert (Kunden gehen dann direkt zum Anbieter)."""
    return max(guard_paused(pkey), float(_g(pkey).get("pass_paused_until", 0)) - time.time())


def guard_used(pkey: str, kind: str) -> int:
    """Anfragen der letzten 60 Minuten (aktuelle + anteilig vorige Stunde)."""
    g = _g(pkey)
    now = time.time()
    cur = g["hours"].get(_hour_key(now), {}).get(kind, 0)
    prev = g["hours"].get(_hour_key(now - 3600), {}).get(kind, 0)
    frac = 1 - (now % 3600) / 3600
    return int(cur + prev * frac)


def guard_allow(pkey: str, kind: str, what: str) -> bool:
    """kind 'own' (Onyx selbst) oder 'pass' (Panel-Kunden). Zählt die Anfrage, wenn sie erlaubt ist."""
    with _guard_lock:
        g = _g(pkey)
        if guard_paused(pkey) or (kind == "pass" and guard_pass_paused(pkey)):
            return False
        limit = int(config.get("guard_limit_own" if kind == "own" else "guard_limit_passthrough", 120))
        if guard_used(pkey, kind) >= limit:
            if not g.get("limit_logged") or time.time() - g["limit_logged"] > 3600:
                g["limit_logged"] = time.time()
                guard_event(pkey, "limit", f"Obergrenze {limit}/Stunde erreicht ({'Onyx' if kind == 'own' else 'Weiterreichen'})")
            return False
        h = g["hours"].setdefault(_hour_key(), {})
        h[kind] = h.get(kind, 0) + 1
        for k in sorted(g["hours"])[:-48]:
            g["hours"].pop(k, None)
        return True


def guard_count_redirect(pkey: str) -> None:
    with _guard_lock:
        h = _g(pkey)["hours"].setdefault(_hour_key(), {})
        h["redirected"] = h.get("redirected", 0) + 1


def guard_event(pkey: str, typ: str, text: str) -> None:
    g = _g(pkey)
    g["log"] = (g["log"] + [{"t": int(time.time()), "type": typ, "text": text}])[-40:]
    log.warning("Wächter %s: %s", pkey, text)
    guard_save()
    if typ == "pause":
        try:
            nm = (config["providers"].get(pkey) or {}).get("name") or pkey
            notify("guard", f"🛑 Notstopp bei {nm}: {text}\nDer Server fragt dort vorerst nichts an. Abspielen läuft normal weiter.", key=f"guard-{pkey}", cooldown=3600)
        except Exception:
            pass


# ---------------------------------------------------------------- Ist die Server-IP beim Anbieter gesperrt?
# Wird aus dem laufenden Verkehr abgelesen (Abgleich, Weiterreichen) – ohne eigene Anfragen. „Jetzt prüfen“ kostet 1 Anfrage.
ipwatch: dict = load_json("ipwatch.json", {})
tests: dict = load_json("tests.json", {})  # „kind:vid“ -> {"s": "ok"|"bad", "t": Zeit} – deine Sender-Tests (nur Admin)


def ip_mark(pkey: str, ok: bool, sign: str = "") -> None:
    w = ipwatch.setdefault(pkey, {})
    now = int(time.time())
    if ok:
        w["last_ok"] = now
    else:
        w["last_fail"], w["fail_sign"] = now, sign
    if not ok or now - w.get("_saved", 0) > 300:
        w["_saved"] = now
        try:
            save_json("ipwatch.json", ipwatch)
        except Exception:
            pass



def server_ips() -> list[str]:
    """Findet alle IPv4-Adressen auf diesem Server (Haupt-IP und Failover-IPs) + konfigurierte Reserve-IPs."""
    ips: set[str] = set()
    try:
        r = subprocess.run(["ip", "-4", "-o", "addr", "show"], capture_output=True, text=True, timeout=5).stdout
        for line in r.splitlines():
            m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)", line)
            if m:
                ip = m.group(1)
                if not ip.startswith("127."):
                    ips.add(ip)
    except Exception:
        pass
    for ip in config.get("reserve_ips") or []:
        ip = str(ip or "").strip()
        if ip and re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", ip) and not ip.startswith("127."):
            ips.add(ip)
    for ip in (config.get("egress") or {}).values():
        ip = str(ip or "").strip()
        if ip and re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", ip) and not ip.startswith("127."):
            ips.add(ip)
    return sorted(ips)


def test_bindable_ip(ip: str) -> tuple[bool, str]:
    """Prüft, ob eine Absender-IP auf diesem Server gebunden werden kann."""
    if not ip:
        return True, "Haupt-IP (Standard-Routing)"
    try:
        t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        t.bind((ip, 0))
        t.close()
        return True, "IP liegt auf dem Server und ist sofort bindbar."
    except OSError as e:
        return False, f"IP kann nicht gebunden werden ({e}). Liegt sie auf dem Server (ip addr)?"


def available_egress_ips(pkey: str) -> list[dict]:
    """Liefert alle wählbaren Absender-IPs für diesen Anbieter inklusive Status."""
    current = egress_for(pkey)
    all_ips = server_ips()
    out = [{
        "ip": "",
        "label": "Haupt-IP (Standard-Routing)",
        "current": (current == ""),
        "bindable": True
    }]
    for ip in all_ips:
        bindable, _ = test_bindable_ip(ip)
        out.append({
            "ip": ip,
            "label": ip,
            "current": (current == ip),
            "bindable": bindable
        })
    return out

def ip_status(pkey: str) -> dict:
    w = ipwatch.get(pkey, {})
    now = int(time.time())
    ok, fail, chk = w.get("last_ok", 0), w.get("last_fail", 0), w.get("check") or {}
    if chk and chk.get("t", 0) >= max(ok, fail) - 5:
        verdict = chk["verdict"]
    elif ok and ok >= fail and now - ok < 6 * 3600:
        verdict = "free"
    elif fail and fail > ok:
        verdict = "suspect"
    else:
        verdict = "unknown"
    return {"verdict": verdict, "last_ok": ok, "last_fail": fail, "fail_sign": w.get("fail_sign", ""), "check": chk,
            "egress": egress_for(pkey) or "", "host": urllib.parse.urlsplit(provider_url(pkey)).hostname or "",
            "available_ips": available_egress_ips(pkey),
            "reserve_ips": config.get("reserve_ips") or []}


def ip_check(pkey: str) -> dict:
    """Eine einzige Anmeldung mit dem Sync-Zugang – von der festen Absender-IP aus."""
    sc = sync_creds(pkey)
    t0 = time.time()
    res = {"t": int(t0), "egress": egress_for(pkey) or ""}
    if not sc["username"]:
        res.update(verdict="unknown", text="Kein Sync-Zugang eingetragen – ohne ihn kann ich nicht prüfen.")
    elif not guard_allow(pkey, "own", "IP-Prüfung"):
        res.update(verdict="unknown", text="Der Anfragen-Wächter pausiert gerade – Prüfung ausgelassen.")
    else:
        url = f"{provider_url(pkey)}/player_api.php?" + urllib.parse.urlencode({"username": sc["username"], "password": sc["password"]})
        try:
            with provider_open(pkey, urllib.request.Request(url, headers={"User-Agent": UA}), 15) as r:
                body = r.read(65536)
            if body[:2] == b"\x1f\x8b":
                body = gzip.decompress(body)
            ui = (json.loads(body.decode("utf-8", "replace") or "{}") or {}).get("user_info") or {}
            if str(ui.get("auth", "0")) in ("1", "True", "true"):
                res.update(verdict="free", text="Frei – der Anbieter hat deinen Server ganz normal angenommen.")
            else:
                res.update(verdict="free", text="Server erreicht den Anbieter. Nur der Sync-Zugang wurde abgelehnt (abgelaufen oder Passwort falsch) – das ist keine IP-Sperre.")
        except urllib.error.HTTPError as e:
            res.update(verdict="suspect", code=e.code,
                       text=f"Der Anbieter lehnt den Server ab (HTTP {e.code}). Das kann eine Sperre sein – oder am Zugang liegen. Mach die Gegenprobe von deinem PC.")
        except Exception as e:
            res.update(verdict="suspect", text=f"Keine Verbindung vom Server zum Anbieter ({type(e).__name__}). Entweder ist die IP gesperrt oder der Anbieter gerade gestört – Gegenprobe von deinem PC zeigt, was davon.")
    res["ms"] = int((time.time() - t0) * 1000)
    prev = (ipwatch.get(pkey, {}).get("check") or {}).get("verdict")
    ipwatch.setdefault(pkey, {})["check"] = res
    ip_mark(pkey, res["verdict"] == "free", "" if res["verdict"] == "free" else res.get("text", ""))
    if res["verdict"] == "suspect" and prev != "suspect":
        notify("block", f"🚫 {pname(pkey)}: Verdacht auf Sperre deiner Server-IP {res['egress'] or 'Haupt-IP'} – {res['text']}\n\n💡 Tipp: Im Admin unter Betrieb steht der 1-Klick-Wechsel auf deine Reserve-IP bereit.", key=f"block-{pkey}-{res['t'] // 3600}", cooldown=0)
    elif res["verdict"] == "free" and prev == "suspect":
        notify("block", f"✅ {pname(pkey)}: Deine Server-IP wird wieder angenommen.", key=f"unblock-{pkey}-{res['t']}", cooldown=0)
    return res


def guard_report(pkey: str, what: str, status: int | None = None, error: str = "", scope: str = "own") -> None:
    """Nach jeder fehlgeschlagenen Anfrage aufrufen.
    scope 'own' (eigener Sync-Zugang, Zugangsdaten sicher richtig): Sperr-Anzeichen -> kompletter Notstopp.
    scope 'pass' (Panel-Kunde, Passwort evtl. falsch – der Anbieter antwortet dann auch mit 511):
    nur das Weiterreichen pausieren; Kunden gehen solange direkt zum Anbieter, der VPS fragt nichts."""
    # Bei Kunden-Zugängen (scope pass) heißt ein HTTP-Fehler oft nur „Passwort falsch“ – zählt nicht als Sperr-Zeichen
    if (status is None or ((status in HARD_SIGNS or status in SOFT_SIGNS) and scope != "pass")):
        ip_mark(pkey, False, f"HTTP {status} bei {what}" if status else f"{error or 'Verbindungsfehler'} bei {what}")
    with _guard_lock:
        g = _g(pkey)
        now = time.time()
        sign = f"HTTP {status}" if status else (error or "Verbindungsfehler")
        if scope == "pass":
            if status is not None and status not in HARD_SIGNS and status not in SOFT_SIGNS:
                return
            g["pass_paused_until"] = now + int(config.get("guard_pause_min", 60)) * 60
            guard_event(pkey, "passpause", f"Weiterreichen {config.get('guard_pause_min', 60)} Minuten pausiert "
                                           f"({sign}) – Kunden gehen solange direkt zum Anbieter")
            return
        hard = status in HARD_SIGNS
        if not hard:
            if status is not None and status not in SOFT_SIGNS:
                return  # normale Fehler (404 usw.) sind kein Sperr-Zeichen
            g["soft"] = [t for t in g["soft"] if now - t < 600] + [now]
            if len(g["soft"]) < 2:
                guard_event(pkey, "warn", f"Warnzeichen bei {what}: {sign}")
                return
        g["paused_until"] = now + int(config.get("guard_pause_min", 60)) * 60
        g["pause_reason"] = f"{sign} bei {what}"
        g["soft"] = []
        guard_event(pkey, "pause", f"Notstopp für {config.get('guard_pause_min', 60)} Minuten: {sign} bei {what}")


def guard_resume(pkey: str) -> None:
    with _guard_lock:
        g = _g(pkey)
        g["paused_until"] = 0
        g["pass_paused_until"] = 0
        g["soft"] = []
        guard_event(pkey, "resume", "Pause von Hand aufgehoben")


def guard_state() -> dict:
    out = {}
    for pkey in config["providers"]:
        g = _g(pkey)
        now = time.time()
        hours = []
        for i in range(23, -1, -1):
            t = now - i * 3600
            h = g["hours"].get(_hour_key(t), {})
            hours.append({"h": time.strftime("%H", time.localtime(t)), "own": h.get("own", 0),
                          "pass": h.get("pass", 0), "redirected": h.get("redirected", 0)})
        out[pkey] = {"paused_for": int(guard_paused(pkey)), "paused_until": int(g.get("paused_until", 0)),
                     "pass_paused_for": int(guard_pass_paused(pkey)), "pass_paused_until": int(g.get("pass_paused_until", 0)),
                     "pause_reason": g.get("pause_reason", ""), "used_own": guard_used(pkey, "own"),
                     "used_pass": guard_used(pkey, "pass"), "hours": hours, "log": g["log"][-12:][::-1]}
    return out


def _http_status(e) -> int | None:
    return getattr(e, "code", None) if isinstance(e, urllib.error.HTTPError) else None


def _throttle(pkey: str) -> None:
    lk = _call_lock.setdefault(pkey, threading.Lock())
    with lk:
        wait = _last_call.get(pkey, 0) + float(config.get("upstream_min_interval", 3.0)) - time.time()
        if wait > 0:
            time.sleep(wait)
        _last_call[pkey] = time.time()


def provider_url(pkey: str) -> str:
    return config["providers"][pkey]["url"].rstrip("/")


def upstream_get(pkey: str, path: str, params: dict, timeout: int = 120, raw: bool = False):
    what = params.get("action") or path
    if not guard_allow(pkey, "own", what):
        left = guard_paused(pkey)
        raise GuardBlocked(f"Anfragen-Wächter: {'Notstopp noch %d min' % (left // 60 + 1) if left else 'Stundengrenze erreicht'}")
    _throttle(pkey)
    url = f"{provider_url(pkey)}/{path}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Encoding": "gzip"})
    upstream_count[pkey] = upstream_count.get(pkey, 0) + 1
    try:
        r = provider_open(pkey, req, timeout)
    except Exception as e:
        guard_report(pkey, what, _http_status(e), type(e).__name__)
        raise
    with r:
        body = r.read()
        if r.headers.get("Content-Encoding") == "gzip" or body[:2] == b"\x1f\x8b":
            body = gzip.decompress(body)
    ip_mark(pkey, True)
    if raw:
        return body
    return json.loads(body.decode("utf-8", "replace") or "null")


def pname(pkey: str) -> str:
    """Name des Anbieters, wie in den Einstellungen vergeben."""
    return (config["providers"].get(pkey) or {}).get("name") or f"Anbieter {'1' if pkey == 'A' else '2'}"


def sync_creds(pkey: str) -> dict:
    p = config["providers"][pkey]
    return {"username": p.get("sync_user", ""), "password": p.get("sync_pass", "")}


# ---------------------------------------------------------------- Katalog
LIVE_KEYS = ("num", "name", "stream_id", "stream_icon", "epg_channel_id", "category_id", "tv_archive",
             "tv_archive_duration", "added", "custom_sid", "stream_type")
VOD_KEYS = ("num", "name", "stream_id", "stream_icon", "rating", "rating_5based", "added", "category_id",
            "container_extension", "stream_type", "tmdb", "year")
SERIES_KEYS = ("num", "name", "series_id", "cover", "plot", "cast", "director", "genre", "releaseDate",
               "release_date", "last_modified", "rating", "rating_5based", "backdrop_path", "youtube_trailer",
               "episode_run_time", "category_id", "tmdb", "year")
ACTIONS = {
    "live": ("get_live_categories", "get_live_streams", LIVE_KEYS),
    "vod": ("get_vod_categories", "get_vod_streams", VOD_KEYS),
    "series": ("get_series_categories", "get_series", SERIES_KEYS),
}
catalog: dict = {}  # pkey -> {kind: {"categories": [...], "items": [...]}}


def load_catalogs() -> None:
    for pkey in config["providers"]:
        catalog[pkey] = load_json(f"catalog_{pkey}.json", {})


def slim(item: dict, keys) -> dict:
    return {k: item[k] for k in keys if k in item and item[k] not in (None, "")}


# ---------------------------------------------------------------- Neu seit dem letzten Abgleich
changes: dict = load_json("changes.json", {})
for _k in ("live", "vod", "series"):
    changes.setdefault("new", {}).setdefault(_k, {})
    changes.setdefault("newcats", {}).setdefault(_k, {})
changes.setdefault("gone", [])
changes.setdefault("runs", [])


def record_changes(pkey: str, old: dict, new: dict) -> None:
    """Vergleicht alten und neuen Katalog (ohne zusätzliche Anfrage) und merkt sich, was neu ist."""
    now = int(time.time())
    run = {"t": now, "pkey": pkey, "kinds": {}}
    for kind, data in new.items():
        before = old.get(kind) or {}
        if not before.get("items"):
            continue  # allererster Abgleich: alles wäre „neu“ – nichts markieren
        idk = "series_id" if kind == "series" else "stream_id"
        old_ids = {str(i.get(idk)) for i in before.get("items", [])}
        new_ids = {str(i.get(idk)) for i in data.get("items", [])}
        old_c = {str(c["category_id"]) for c in before.get("categories", [])}
        added = [i for i in data.get("items", []) if str(i.get(idk)) not in old_ids]
        removed = [i for i in before.get("items", []) if str(i.get(idk)) not in new_ids]
        cats_added = [c for c in data.get("categories", []) if str(c["category_id"]) not in old_c]
        for i in added:
            try:
                changes["new"][kind][str(stream_vid(pkey, i[idk]))] = now
            except (KeyError, TypeError, ValueError):
                pass
        for c in cats_added:
            changes["newcats"][kind][cat_vid(pkey, c["category_id"])] = now
        changes["gone"] = (changes["gone"] + [{"t": now, "kind": kind, "pkey": pkey, "name": i.get("name", "")}
                                              for i in removed])[-500:]
        alive = {str(stream_vid(pkey, x)) for x in new_ids if str(x).isdigit()}
        for v in [v for v in changes["new"][kind] if split_vid(kind, int(v))[0] == pkey and v not in alive]:
            changes["new"][kind].pop(v, None)  # wieder verschwunden
        run["kinds"][kind] = {"added": len(added), "removed": len(removed), "cats_added": len(cats_added)}
    if any(sum(v.values()) for v in run["kinds"].values()):
        changes["runs"] = (changes["runs"] + [run])[-30:]
    save_json("changes.json", changes)


def changes_seen(kind: str, vids=None, cats=None, everything=False) -> None:
    with lock:
        if everything:
            changes["new"][kind] = {}
            changes["newcats"][kind] = {}
        for v in vids or []:
            changes["new"][kind].pop(str(v), None)
        for c in cats or []:
            changes["newcats"][kind].pop(str(c), None)
        save_json("changes.json", changes)


def kind_due(pkey: str, kind: str, force: bool = False) -> bool:
    if force or not (catalog.get(pkey) or {}).get(kind):
        return True
    days = float((config.get("sync_days") or {}).get(kind, 1) or 1)
    last = status.get(pkey, {}).get("kind_ok", {}).get(kind, 0)
    return time.time() - last >= days * 86400 - 3 * 3600  # 3 Std. Spielraum, damit „jede Nacht“ nicht wegen Jitter ausfällt


def sync_provider(pkey: str, force: bool = False) -> dict:
    p = config["providers"][pkey]
    creds = sync_creds(pkey)
    if not creds["username"]:
        raise RuntimeError("Kein Sync-Zugang eingetragen")
    new: dict = {}
    pause = int(config.get("sync_pause", 20))
    first = True
    done_kinds = []
    for kind in p.get("kinds", []):
        if not kind_due(pkey, kind, force):  # diesmal nicht dran: alte Liste behalten, spart die größten Abrufe
            new[kind] = (catalog.get(pkey) or {}).get(kind) or {}
            continue
        done_kinds.append(kind)
        cat_action, item_action, keys = ACTIONS[kind]
        for action in (cat_action, item_action):
            if not first:
                time.sleep(pause)
            first = False
            data = upstream_get(pkey, "player_api.php", {**creds, "action": action}, timeout=300)
            if not isinstance(data, list):
                raise RuntimeError(f"{action}: unerwartete Antwort ({str(data)[:120]})")
            if action == cat_action:
                new.setdefault(kind, {})["categories"] = [
                    {"category_id": str(c.get("category_id")), "category_name": c.get("category_name") or ""}
                    for c in data if c.get("category_id") is not None]
            else:
                new.setdefault(kind, {})["items"] = [slim(i, keys) for i in data]
    # I3: Plausibilitätsprüfung
    old_cat = catalog.get(pkey) or {}
    for k_done in done_kinds:
        old_items = len((old_cat.get(k_done) or {}).get("items", []))
        new_items = len(new.get(k_done, {}).get("items", []))
        if old_items > 50 and new_items < int(old_items * 0.3):
            msg = f"Plausibilität fehlgeschlagen für {pkey} ({k_done}): Anbieter liefert nur {new_items} Einträge (vorher {old_items}). Abgleich abgebrochen – bestehender Stand bleibt geschützt."
            log.error(msg)
            try:
                notify("sync_error", f"⚠️ {msg}")
            except Exception:
                pass
            raise RuntimeError(msg)
    record_changes(pkey, catalog.get(pkey) or {}, new)
    ko = status.setdefault(pkey, {}).setdefault("kind_ok", {})
    for kind in done_kinds:
        ko[kind] = int(time.time())
    save_json(f"catalog_{pkey}.json", new)
    with lock:
        catalog[pkey] = new
    return {k: {"categories": len(v.get("categories", [])), "items": len(v.get("items", []))} for k, v in new.items()}


# ---------------------------------------------------------------- EPG (SQLite)
EPG_DB = _path("epg.sqlite")


_db_ready: set = set()


def db_open(path: str, setup=None, **kw) -> sqlite3.Connection:
    """SQLite im WAL-Modus: Lesen (Apps, Admin) geht weiter, während das Programm eingespielt wird.
    Tabellen werden nur beim ersten Öffnen angelegt."""
    c = sqlite3.connect(path, timeout=30, **kw)
    if path not in _db_ready:
        try:
            c.execute("PRAGMA journal_mode=WAL")
        except sqlite3.Error as e:
            log.warning("WAL für %s: %s", os.path.basename(path), e)
        if setup:
            setup(c)
            c.commit()
        _db_ready.add(path)
    c.execute("PRAGMA synchronous=NORMAL")
    return c


def epg_conn() -> sqlite3.Connection:
    return db_open(EPG_DB, lambda c: c.execute(
        "CREATE TABLE IF NOT EXISTS prog(channel TEXT, start INTEGER, stop INTEGER, title TEXT, descr TEXT,"
        " PRIMARY KEY(channel, start))"))


def parse_xmltv_time(s: str) -> int | None:
    if not s:
        return None
    m = re.match(r"(\d{14})\s*([+-]\d{4})?", s.strip())
    if not m:
        return None
    dt = datetime.strptime(m.group(1), "%Y%m%d%H%M%S")
    off = m.group(2) or "+0000"
    sign = 1 if off[0] == "+" else -1
    delta = timedelta(hours=int(off[1:3]), minutes=int(off[3:5])) * sign
    return int((dt - delta).replace(tzinfo=timezone.utc).timestamp())


def sync_epg(pkey: str) -> int:
    creds = sync_creds(pkey)
    tmp = _path(f"epg_{pkey}.xml.tmp")
    if not guard_allow(pkey, "own", "EPG"):
        raise GuardBlocked("Anfragen-Wächter: EPG übersprungen")
    _throttle(pkey)
    url = f"{provider_url(pkey)}/xmltv.php?{urllib.parse.urlencode(creds)}"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    upstream_count[pkey] = upstream_count.get(pkey, 0) + 1
    try:
        resp = provider_open(pkey, req, 600)
    except Exception as e:
        guard_report(pkey, "EPG", _http_status(e), type(e).__name__)
        raise
    with resp as r, open(tmp, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
    rows = import_xmltv(tmp)
    os.remove(tmp)
    return rows


def import_xmltv(path: str, names: dict | None = None) -> int:
    """Liest eine XMLTV-Datei (auch .gz) Stück für Stück in die Programm-Datenbank.
    names: wenn angegeben, werden dort Kanal-ID -> Anzeigenamen gesammelt."""
    with open(path, "rb") as f:
        gz = f.read(2) == b"\x1f\x8b"
    now = int(time.time())
    lo, hi = now - 6 * 3600, now + 4 * 86400
    rows, batch = 0, []
    # I9: Nur EPG für sichtbare/genutzte Kanäle speichern
    wanted: set = set()
    try:
        wanted = set(view.get("epg_index", {}).values()) | set(epg_alias.values()) - {"", None}
    except Exception:
        pass
    con = epg_conn()
    con.execute("DELETE FROM prog WHERE stop < ?", (now - 6 * 3600,))
    src = gzip.open(path, "rb") if gz else open(path, "rb")
    try:
        for _, el in ET.iterparse(src, events=("end",)):
            if el.tag == "programme":
                ch = el.get("channel") or ""
                if wanted and ch not in wanted:
                    el.clear()
                    continue
                st, sp = parse_xmltv_time(el.get("start", "")), parse_xmltv_time(el.get("stop", ""))
                if st and sp and ch and sp >= lo and st <= hi:
                    batch.append((ch, st, sp, el.findtext("title") or "", el.findtext("desc") or ""))
                    if len(batch) >= 5000:
                        con.executemany("INSERT OR REPLACE INTO prog VALUES(?,?,?,?,?)", batch)
                        rows += len(batch)
                        batch.clear()
                el.clear()
            elif el.tag == "channel":
                cid = el.get("id") or ""
                if names is not None and cid:
                    names[cid] = [d.text or "" for d in el.findall("display-name")]
                el.clear()
    finally:
        src.close()
    if batch:
        con.executemany("INSERT OR REPLACE INTO prog VALUES(?,?,?,?,?)", batch)
        rows += len(batch)
    con.commit()
    con.close()
    return rows


def prune_epg_unwanted() -> int:
    """I9: Löscht EPG-Einträge für Kanäle, die in keiner sichtbaren Kategorie mehr vorkommen."""
    wanted = set(view.get("epg_index", {}).values()) | set(epg_alias.values()) - {"", None}
    if not wanted:
        return 0
    deleted = 0
    try:
        con = epg_conn()
        all_ch = [r[0] for r in con.execute("SELECT DISTINCT channel FROM prog").fetchall()]
        to_delete = [ch for ch in all_ch if ch not in wanted]
        if to_delete:
            con.executemany("DELETE FROM prog WHERE channel = ?", [(ch,) for ch in to_delete])
            con.commit()
            deleted = len(to_delete)
        con.close()
    except Exception as e:
        log.warning("prune_epg_unwanted: %s", e)
    return deleted


# ---------------------------------------------------------------- Programm aus fremder Quelle
# Eine frei verfügbare XMLTV-Datei (z. B. von iptv-org) – belastet keinen Anbieter.
epg_ext_state: dict = load_json("epg_ext.json", {})
epg_alias: dict = load_json("epg_alias.json", {})  # Sender-Nummer -> Kanal-ID der fremden Quelle


def epg_ext_url_ok(url: str) -> str:
    sp = urllib.parse.urlsplit(url or "")
    if sp.scheme not in ("http", "https") or not sp.hostname:
        return "Bitte eine http(s)-Adresse angeben."
    prov_hosts = {urllib.parse.urlsplit(provider_url(k)).hostname for k in config["providers"]}
    if sp.hostname in prov_hosts:
        return "Das ist die Adresse eines Anbieters – dafür gibt es den normalen Abgleich (mit Wächter)."
    return ""


def sync_epg_ext() -> int:
    cfg = config.get("epg_ext") or {}
    url = cfg.get("url") or ""
    err = epg_ext_url_ok(url)
    if err:
        raise RuntimeError(err)
    tmp = _path("epg_ext.xml.tmp")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Onyx Merge EPG)", "Accept-Encoding": "gzip"})
    size = 0
    with urllib.request.urlopen(req, timeout=600) as r, open(tmp, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            size += len(chunk)
            if size > 400 << 20:
                raise RuntimeError("Datei größer als 400 MB – bitte eine kleinere Quelle (z. B. nur ein Land) nehmen.")
            f.write(chunk)
    names: dict = {}
    rows = import_xmltv(tmp, names)
    now = int(time.time())
    con = epg_conn()
    have = {r[0] for r in con.execute("SELECT DISTINCT channel FROM prog WHERE stop > ?", (now,))}
    con.close()
    os.remove(tmp)
    # Zuordnung: Sender ohne Programm bekommen den Kanal der fremden Quelle mit demselben Namen (Land bevorzugt)
    by_name: dict = {}
    for cid, dn in names.items():
        if cid not in have:
            continue
        for n in dn + [cid.split(".")[0]]:
            b = base_name(n)
            if b:
                by_name.setdefault(b, []).append(cid)
    alias, matched, missing = {}, 0, 0
    only = cfg.get("mode") == "only"
    for pkey in config["providers"]:
        for it in (catalog.get(pkey, {}).get("live") or {}).get("items", []):
            ep = it.get("epg_channel_id") or ""
            if ep and ep in have and not only:
                continue
            b = base_name(it.get("name", ""))
            cands = by_name.get(b) or []
            if not cands:
                missing += 1
                continue
            cc = (country_of(it.get("name", "")) or "").lower()
            best = next((c for c in cands if cc and (c.lower().endswith("." + cc) or f".{cc}@" in c.lower())), cands[0])
            try:
                alias[str(stream_vid(pkey, it["stream_id"]))] = best
                matched += 1
            except (KeyError, TypeError, ValueError):
                pass
    epg_alias.clear()
    epg_alias.update(alias)
    save_json("epg_alias.json", epg_alias)
    epg_ext_state.update({"ok": now, "rows": rows, "channels": len(names), "matched": matched, "missing": missing, "error": ""})
    save_json("epg_ext.json", epg_ext_state)
    return rows


# ---------------------------------------------------------------- Zusammengeführte Ansicht
def cat_vid(pkey: str, cid) -> str:
    try:
        return str(int(cid) + CAT_OFFSET[pkey])
    except (TypeError, ValueError):
        return f"{pkey}{cid}"


def stream_vid(pkey: str, sid) -> int:
    return int(sid) + STREAM_OFFSET[pkey]


def split_vid(kind: str, vid: int):
    if kind == "live" and vid >= STREAM_OFFSET["B"]:
        return "B", vid - STREAM_OFFSET["B"]
    return "A", vid


view: dict = {}        # Entwurf (Admin): kind -> {"cats": [...], "items": {cat_vid: [items]}}
pub: dict = {}         # Veröffentlicht (was die Apps der Kunden bekommen) – wird erst mit „Speichern“ zum Entwurf
_tl = threading.local()  # Admin-Anfragen sehen den Entwurf, alles andere den veröffentlichten Stand
draft_state = {"pub_hash": "", "cur_hash": "", "published": 0, "catalog_pending": False}


def V() -> dict:
    return view if getattr(_tl, "draft", False) else pub


def cur_hash() -> str:
    return hashlib.sha1(json.dumps(curation, sort_keys=True, ensure_ascii=False, default=list).encode()).hexdigest()


def draft_dirty() -> bool:
    return draft_state["cur_hash"] != draft_state["pub_hash"]



# ---------------------------------------------------------------- M11 & M12: Fehler- und Latenzmessung
ERR_AREAS = ("client", "sync", "epg", "save", "livecat", "admin", "other")
err_counts = {a: 0 for a in ERR_AREAS}
err_recent = collections.deque(maxlen=50)
_err_lock = threading.Lock()
_err_notify_window = collections.deque(maxlen=100)

def track_error(area: str, msg: str, exc: Exception = None) -> None:
    if area not in err_counts:
        area = "other"
    now = int(time.time())
    tb_str = ""
    if exc is not None:
        import traceback
        tb_str = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))[-1000:]
    with _err_lock:
        err_counts[area] += 1
        err_recent.appendleft({
            "t": now,
            "area": area,
            "msg": str(msg)[:300],
            "trace": tb_str
        })
        _err_notify_window.append((now, area))
        recent_in_window = sum(1 for t, a in _err_notify_window if now - t < 300 and a == area)
        if recent_in_window >= 5:
            _err_notify_window.clear()
            notify("error", f"⚠️ Fehlerhäufung im Bereich '{area}': {recent_in_window} Fehler in den letzten 5 Minuten. Details unter Betrieb.", cooldown=3600)

_ENDPOINTS = ("auth", "live", "vod", "series", "epg", "m3u", "stream", "other")
endpoint_latencies = {ep: collections.deque(maxlen=500) for ep in _ENDPOINTS}
_ep_lock = threading.Lock()

def classify_endpoint(p: str) -> str:
    path = p.lower()
    if "player_api.php" in path:
        if "action=get_live" in path:
            return "live"
        if "action=get_vod" in path:
            return "vod"
        if "action=get_series" in path:
            return "series"
        if "action=" in path:
            return "other"
        return "auth"
    if "xmltv.php" in path or "epg" in path:
        return "epg"
    if "get.php" in path or path.endswith((".m3u", ".m3u8")):
        return "m3u"
    if path.startswith(("/live/", "/movie/", "/series/")):
        return "stream"
    return "other"

def record_endpoint_latency(ep: str, dt_ms: float, path: str = "") -> None:
    if ep not in endpoint_latencies:
        ep = "other"
    with _ep_lock:
        endpoint_latencies[ep].append(round(dt_ms, 1))
    if dt_ms > 1000.0 and ep != "stream":
        log.warning("Langsame Anfrage (%s): %.2f s [%s]", ep, dt_ms / 1000.0, path.split("?")[0])

def endpoint_stats() -> dict:
    out = {}
    with _ep_lock:
        for ep, dq in endpoint_latencies.items():
            if not dq:
                continue
            ls = sorted(dq)
            n = len(ls)
            out[ep] = {
                "count": n,
                "avg": round(sum(ls) / n, 1),
                "p50": round(ls[n // 2], 1),
                "p95": round(ls[min(n - 1, int(n * 0.95))], 1)
            }
    return out


# ---------------------------------------------------------------- M10: systemd Watchdog-Herzschlag
def _start_watchdog_thread():
    sock_path = os.environ.get(NOTIFY_SOCKET)
    if not sock_path:
        return
    def _loop():
        import socket
        while True:
            try:
                target = "\x00" + sock_path[1:] if sock_path.startswith("@") else sock_path
                sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
                sock.sendto(b"WATCHDOG=1", target)
                sock.close()
            except Exception:
                pass
            time.sleep(30)
    threading.Thread(target=_loop, daemon=True, name="systemd-watchdog").start()

# ---------------------------------------------------------------- Server-Last (nur eigener Server, keine Anfrage nach außen)
health: dict = {"resp": collections.deque(maxlen=3000), "hist": collections.deque(maxlen=288), "now": {}, "hot": 0}


def _read_cpu():
    with open("/proc/stat") as f:
        v = [int(x) for x in f.readline().split()[1:]]
    return sum(v), v[3] + (v[4] if len(v) > 4 else 0)


def health_sample(prev):
    tot, idle = _read_cpu()
    cpu = 0.0 if not prev else max(0.0, min(100.0, 100.0 * (1 - (idle - prev[1]) / max(1, tot - prev[0]))))
    mem = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                mem[k] = int(v.split()[0]) * 1024
    except OSError:
        pass
    rss = 0
    try:
        with open("/proc/self/status") as f:
            rss = next((int(l.split()[1]) * 1024 for l in f if l.startswith("VmRSS:")), 0)
    except OSError:
        pass
    now = int(time.time())
    rs = sorted(ms for t, ms in list(health["resp"]) if now - t < 3600)
    q = lambda p: round(rs[min(len(rs) - 1, int(len(rs) * p))], 1) if rs else None
    out = {"t": now, "cpu": round(cpu, 1), "load": round(os.getloadavg()[0], 2), "cores": os.cpu_count() or 1,
           "mem_total": mem.get("MemTotal", 0), "mem_avail": mem.get("MemAvailable", 0), "rss": rss,
           "resp_n": len(rs), "resp_p50": q(.5), "resp_p95": q(.95)}
    return (tot, idle), out


def health_scheduler() -> None:
    prev, first = health_sample(None)
    health["now"] = first
    n = 0
    while True:
        time.sleep(30)
        try:
            prev, h = health_sample(prev)
            health["now"] = h
            n += 1
            if n % 10 == 0:  # alle 5 Minuten ein Punkt für den Verlauf (24 h)
                health["hist"].append({k: h[k] for k in ("t", "cpu", "mem_avail", "mem_total", "resp_p95")})
            # I6: Speicher-Wächter – Cache bei RAM-Knappheit leeren
            rss = h.get("rss", 0)
            avail = h.get("mem_avail", 0)
            if rss > 2_000_000_000 or (h.get("mem_total", 0) and avail < 400_000_000):
                freed = len(resp_cache)
                resp_cache.clear()
                try:
                    _lc_memo.clear()
                except Exception:
                    pass
                gc.collect()
                log.warning("Speicher-Wächter aktiv: RSS %.0f MB (frei: %.0f MB). %d Cache-Einträge geleert.",
                            rss / (1 << 20), avail / (1 << 20), freed)
            mem_low = h["mem_total"] and h["mem_avail"] / h["mem_total"] < 0.08
            health["hot"] = health["hot"] + 1 if (h["cpu"] > 90 or mem_low) else 0
            if health["hot"] >= 6:  # 3 Minuten am Stück
                notify("load", f"🔥 Der VPS ist ausgelastet: Prozessor {h['cpu']:.0f} %, freier Arbeitsspeicher "
                               f"{h['mem_avail'] / (1 << 20):.0f} MB. Apps können langsamer laden.", cooldown=6 * 3600)
                health["hot"] = 0
            for pk in config["providers"]:
                w = ipwatch.get(pk, {})
                if w.get("last_fail", 0) > w.get("last_ok", 0) and time.time() - (w.get("check") or {}).get("t", 0) > 2 * 3600 \
                        and time.time() - w.get("last_fail", 0) < 3600:
                    ip_check(pk)
            # Verdacht auf IP-Sperre aus dem normalen Verkehr? Dann einmal selbst nachprüfen (1 Anmeldung, höchstens 1× pro Stunde)
            for pk in config["providers"]:
                st = ip_status(pk)
                last_auto = health.setdefault("ipauto", {}).get(pk, 0)
                if st["verdict"] == "suspect" and not (st.get("check") or {}).get("t", 0) >= st["last_fail"] \
                        and time.time() - last_auto > 3600 and config["providers"][pk].get("sync_user"):
                    health["ipauto"][pk] = time.time()
                    log.info("IP-Verdacht bei %s – prüfe einmal nach", pk)
                    ip_check(pk)
            ds = draft_state.get("dirty_since") or 0
            if ds and draft_dirty() and time.time() - ds > 2 * 3600:
                notify("draft", "📝 Du hast Änderungen an der Senderliste seit über 2 Stunden nicht gespeichert – "
                                "deine Kunden sehen noch den alten Stand. Admin → oben „Speichern“.", cooldown=12 * 3600)
        except Exception as e:
            log.warning("Server-Last: %s", e)


def publish(reason: str = "") -> None:
    """Entwurf veröffentlichen: Ab jetzt bekommen die Apps genau diesen Stand."""
    with lock:
        pub.clear()
        pub.update(view)
        save_json("curation_pub.json", curation)
        draft_state.update({"pub_hash": draft_state["cur_hash"] or cur_hash(), "published": int(time.time()),
                            "catalog_pending": False, "dirty_since": 0})
        resp_cache.clear()
    if reason:
        log.info("Senderliste veröffentlicht (%s)", reason)
    if _post_timer[0]:
        _post_timer[0].cancel()
    _post_timer[0] = threading.Timer(3, _after_build)
    _post_timer[0].daemon = True
    _post_timer[0].start()


def discard_draft() -> None:
    """Entwurf verwerfen: zurück auf den zuletzt gespeicherten Stand."""
    snap = load_json("curation_pub.json", None)
    if not isinstance(snap, dict):
        return
    with lock:
        curation.clear()
        curation.update(snap)
    build_view()
class RespCache(collections.OrderedDict):
    """M8: Fertige Antworten mit Obergrenze (300 MB, LRU). Selten genutzte Listen fallen zuerst heraus,
    damit der Arbeitsspeicher auch bei riesigem Katalog stabil bleibt."""
    gen = 0
    max_bytes = 300 * 1024 * 1024  # 300 MB

    def __init__(self, *args, max_bytes: int = 300 * 1024 * 1024, **kwargs):
        super().__init__(*args, **kwargs)
        self.max_bytes = max_bytes
        self.total_bytes = 0
        self._lock = threading.Lock()

    def get(self, key, default=None):
        with self._lock:
            val = super().get(key, default)
            if val is not default and key in self:
                self.move_to_end(key)
            return val

    def set(self, key, val):
        with self._lock:
            if key in self:
                old = super().__getitem__(key)
                self.total_bytes -= len(old) if isinstance(old, (bytes, bytearray, str)) else 0
            sz = len(val) if isinstance(val, (bytes, bytearray, str)) else 0
            self.total_bytes += sz
            super().__setitem__(key, val)
            self.move_to_end(key)
            while self.total_bytes > self.max_bytes and len(self) > 1:
                old_key, old_val = self.popitem(last=False)
                self.total_bytes -= len(old_val) if isinstance(old_val, (bytes, bytearray, str)) else 0

    def __setitem__(self, key, val):
        self.set(key, val)

    def clear(self):
        with self._lock:
            self.gen += 1
            self.total_bytes = 0
            super().clear()

    def pop(self, key, *default):
        with self._lock:
            if key in self:
                self.gen += 1
                val = super().pop(key)
                self.total_bytes -= len(val) if isinstance(val, (bytes, bytearray, str)) else 0
                return val
            if default:
                return default[0]
            raise KeyError(key)

    def pop_quiet(self, key):
        with self._lock:
            if key in self:
                val = super().pop(key)
                self.total_bytes -= len(val) if isinstance(val, (bytes, bytearray, str)) else 0
                return val
            return None


resp_cache = RespCache()  # (kind, what, pset, pkgs, cat, base) -> bytes
_inflight: dict = {}
_inflight_lock = threading.Lock()


def cache_once(key, build):
    """Dieselbe Antwort wird nur einmal gebaut, auch wenn viele Apps gleichzeitig danach fragen –
    die anderen warten kurz und bekommen dasselbe Ergebnis."""
    while True:
        hit = resp_cache.get(key)
        if hit is not None:
            return hit
        with _inflight_lock:
            ev = _inflight.get(key)
            mine = ev is None
            if mine:
                ev = _inflight[key] = threading.Event()
        if not mine:
            ev.wait(180)
            continue
        try:
            gen = resp_cache.gen
            val = build()
            if resp_cache.gen == gen:
                resp_cache.set(key, val)
            return val
        finally:
            with _inflight_lock:
                _inflight.pop(key, None)
            ev.set()
CUSTOM_BASE = 9_000_000  # eigene Kategorien: 9000001, 9000002, …


def compile_rules(kind: str) -> list:
    """Umbenennungs-Regeln (curation["rules"]): gelten automatisch für alle (auch neue) Einträge."""
    out = []
    for r in curation.get("rules", []):
        if not r.get("enabled", True) or r.get("kind", "all") not in ("all", kind) or not r.get("find"):
            continue
        try:
            pat = r["find"] if r.get("regex") else re.escape(r["find"])
            out.append((re.compile(pat, 0 if r.get("case") else re.IGNORECASE), r.get("replace", "")))
        except re.error:
            continue
    return out


def clean_edges(s: str) -> str:
    """Reste wie „| ARD“ oder „ARD -“ entfernen – aber „|DE| ARD“ (Kürzel in Strichen) unangetastet lassen."""
    s = re.sub(r"\s{2,}", " ", s).strip()
    s = re.sub(r"^[-|:–]+\s+", "", s)
    s = re.sub(r"\s+[-|:–]+$", "", s)
    return s.strip()


def apply_rules(name: str, rules: list) -> str:
    for rx, rep in rules:
        name = rx.sub(rep, name)
    return clean_edges(name) or name


def pattern_regex(words: list):
    """Kürzel wie „TR“ oder „DE“ als ganzes Wort (so passt „DE“ nicht in „NEDERLAND“).
    Mit „re:“ davor wird ein eigenes Muster (Regex) verwendet."""
    parts = []
    for w in words:
        w = str(w).strip()
        if not w:
            continue
        if w.lower().startswith("re:"):
            parts.append(f"(?:{w[3:]})")
        else:
            parts.append(r"(?<![A-Za-zÄÖÜäöüßÇçĞğİıŞş])" + re.escape(w) + r"(?![A-Za-zÄÖÜäöüßÇçĞğİıŞş])")
    if not parts:
        return None
    try:
        return re.compile("|".join(parts), re.IGNORECASE)
    except re.error:
        return None


# Trennzeilen der Anbieter („###DE SPORT###“, „===== TR =====“): keine echten Sender, nur Überschriften in der Liste
SEP_RX = re.compile(r"#{2,}|={3,}|\*{3,}|-{4,}|_{4,}|~{3,}|[★☆•●▬━─■◆]{3,}")


def is_separator(name: str) -> bool:
    return bool(SEP_RX.search(name or ""))


def compute_packages(v: dict) -> dict:
    out = {}
    for pk in curation.get("packages", []):
        rx = pattern_regex(pk.get("patterns", []))
        inc, exc = set(pk.get("include", [])), set(pk.get("exclude", []))
        members = set()
        for kind in KINDS:
            if kind not in pk.get("kinds", list(KINDS)):
                continue
            for c in v.get(kind, {}).get("cats", []):
                key = f"{kind}:{c['vid']}"
                if key in exc:
                    continue
                if key in inc or (rx and (rx.search(c["orig"]) or rx.search(c["name"]))):
                    members.add(key)
            for cc in curation.get("custom", {}).get(kind, []):
                key = f"{kind}:{cc['vid']}"
                if key not in exc and any(f"{kind}:{s}" in members for s in cc.get("sources") or []):
                    members.add(key)
        out[pk["id"]] = members
    return out


def item_key(kind: str, it: dict) -> int:
    return it["series_id"] if kind == "series" else it["stream_id"]


_post_timer = [None]
_summary_cache: dict = {}
view_gen = [0]


def _after_build() -> None:
    compute_livecats()
    warm_cache()


def build_view(kinds=None) -> None:
    """Baut aus Katalogen + Kuratierung die Listen, die Benutzer sehen.
    kinds: nur diese Bereiche neu bauen (z. B. ("live",) nach einem Klick im Live-Editor) – der Rest bleibt, wie er ist.

    Kuratierung (curation.json):
      curation[kind][cat_vid]          -> {show, name, order}      Kategorien
      curation["custom"][kind]         -> [{vid, name}]            eigene Kategorien
      curation["channels"]["kind:id"]  -> {cat, hide, name, order} einzelne Sender/Titel
    """
    with lock:
        new = {}
        chan = curation.setdefault("channels", {})
        custom = curation.setdefault("custom", {})
        part_build = bool(kinds) and all(k in view for k in KINDS)
        todo = [k for k in KINDS if not part_build or k in kinds]
        for kind in KINDS:
            if kind not in todo:
                new[kind] = view[kind]
                continue
            cats, items = [], {}
            cur = curation.setdefault(kind, {})
            auto = 0
            for cc in custom.setdefault(kind, []):
                st = cur.setdefault(cc["vid"], {"show": True, "name": "", "order": -1000 + auto})
                auto += 1
                cats.append({"vid": cc["vid"], "pkey": "C", "orig": cc["name"], "name": st.get("name") or cc["name"],
                             "show": st.get("show", True), "order": st.get("order", 0)})
            for pkey in ("A", "B"):
                p = config["providers"].get(pkey)
                if not p or kind not in p.get("kinds", []):
                    continue
                part = catalog.get(pkey, {}).get(kind) or {}
                for c in part.get("categories", []):
                    vid = cat_vid(pkey, c["category_id"])
                    st = cur.get(vid)
                    if st is None:
                        st = {"show": bool(config.get("new_categories_visible", True)), "name": "",
                              "order": 100000 + auto}
                        cur[vid] = st
                    auto += 1
                    cats.append({"vid": vid, "pkey": pkey, "orig": c["category_name"],
                                 "name": st.get("name") or c["category_name"], "show": st.get("show", True),
                                 "order": st.get("order", 100000 + auto)})
            valid = {c["vid"] for c in cats}
            # Zusammengefasste Kategorien: alles aus den Quell-Kategorien landet dort – auch Sender, die später neu dazukommen
            src_map = {s: cc["vid"] for cc in custom.get(kind, []) for s in cc.get("sources") or []}
            for t_vid, s_list in curation.get("cat_sources", {}).get(kind, {}).items():
                for s in s_list:
                    src_map[s] = t_vid
            rules = compile_rules(kind)
            idx = 0
            for pkey in ("A", "B"):
                p = config["providers"].get(pkey)
                if not p or kind not in p.get("kinds", []):
                    continue
                id_key = "series_id" if kind == "series" else "stream_id"
                for it in (catalog.get(pkey, {}).get(kind) or {}).get("items", []):
                    vc = cat_vid(pkey, it.get("category_id"))
                    home = vc
                    vc = src_map.get(vc, vc)
                    try:
                        sid = stream_vid(pkey, it[id_key])
                    except (KeyError, TypeError, ValueError):
                        continue
                    idx += 1
                    o = dict(it)
                    o[id_key] = sid
                    o["_p"], o["_orig"], o["_home"] = pkey, it.get("name", ""), home
                    o["_order"] = 10_000_000 + idx
                    if o.get("name"):
                        o["name"] = fix_ball(o["name"])
                    if rules and o.get("name"):
                        o["name"] = apply_rules(o["name"], rules)
                    o["_auto"] = o.get("name", "")
                    if kind == "live" and str(sid) in epg_alias:
                        o["epg_channel_id"] = epg_alias[str(sid)]
                    ov = chan.get(f"{kind}:{sid}")
                    if ov:
                        if ov.get("cat") in valid:
                            vc = ov["cat"]
                        if ov.get("name"):
                            o["name"] = ov["name"]
                        if ov.get("hide"):
                            o["_hide"] = True
                        if ov.get("icon"):
                            o["_icon"] = ov["icon"]
                        if ov.get("epg") and kind == "live":
                            o["epg_channel_id"] = ov["epg"]
                        if ov.get("order") is not None:
                            o["_order"] = int(ov["order"])
                    if not o.get("_hide") and curation.get("hide_separators") and is_separator(o["_orig"]) \
                            and not (ov and ov.get("hide") is False):
                        o["_hide"] = True
                        o["_sep"] = True
                    o["category_id"] = vc
                    o["category_ids"] = [int(vc)] if vc.isdigit() else []
                    items.setdefault(vc, []).append(o)
            for lst in items.values():
                lst.sort(key=lambda o: o["_order"])
            for c in cats:
                c["provs"] = sorted({o["_p"] for o in items.get(c["vid"], []) if not o.get("_hide")})
            cats.sort(key=lambda c: (c["order"], c["pkey"], c["orig"].lower()))
            new[kind] = {"cats": cats, "items": items}
        new["packages"] = compute_packages(new)
        # Feste Sendernummern: Kategorie mit Startnummer -> Start, Start+1, … (für alle Benutzer gleich, bleibt nach Abgleich)
        numbering = curation.get("numbering") or {}
        if numbering:
            nums, used_max = {}, 0
            for c in new["live"]["cats"]:
                st = numbering.get(c["vid"])
                if st and c["show"]:
                    n = int(st)
                    for it in new["live"]["items"].get(c["vid"], []):
                        if not it.get("_hide"):
                            nums[it["stream_id"]] = n
                            used_max = max(used_max, n)
                            n += 1
            n = used_max + 1
            for c in new["live"]["cats"]:
                if not numbering.get(c["vid"]) and c["show"]:
                    for it in new["live"]["items"].get(c["vid"], []):
                        if not it.get("_hide") and it["stream_id"] not in nums:
                            nums[it["stream_id"]] = n
                            n += 1
            new["nums"] = nums
        old_names = view.get("names") or {}
        new["names"] = {key: n for key, n in old_names.items() if key[0] not in todo} if part_build else {}
        new["names"].update({(k, it["stream_id"]): it.get("name", "") for k in ("live", "vod") if k in todo
                             for lst in new[k]["items"].values() for it in lst})
        new["epg_index"] = view.get("epg_index", {}) if part_build and "live" not in todo else \
            {it["stream_id"]: it.get("epg_channel_id") or "" for lst in new["live"]["items"].values() for it in lst}
        view.clear()
        view.update(new)
        view_gen[0] += 1
    # Der Katalog hat Hunderttausende Einträge. Sie gelten für die Speicherbereinigung als „alt“ –
    # sonst durchsucht Python sie bei jedem Klick erneut (bis zu 1 s Pause).
    gc.freeze()
    save_json("curation.json", curation)
    draft_state["cur_hash"] = cur_hash()
    if draft_dirty() and not draft_state.get("dirty_since"):
        draft_state["dirty_since"] = int(time.time())
    elif not draft_dirty():
        draft_state["dirty_since"] = 0
    if not config.get("draft_mode", True) or not pub:
        publish()


def user_providers(u: dict) -> tuple:
    """Anbieter, deren Inhalte der Benutzer sieht: die mit eingetragener Line –
    bei „Nur Anbieter 1“ (sources = "A") nur Anbieter 1."""
    has = tuple(k for k in ("A", "B") if (u.get(k) or {}).get("user"))
    return tuple(k for k in has if k in (u.get("sources") or "AB"))


def user_packages(u: dict) -> tuple:
    known = V().get("packages", {})
    return tuple(sorted(p for p in (u.get("packages") or []) if p in known))


def allowed_keys(pkgs: tuple):
    """Kategorien, die die Pakete eines Benutzers erlauben (None = kein Paket = alles)."""
    if not pkgs:
        return None
    out = set()
    for p in pkgs:
        out |= V().get("packages", {}).get(p, set())
    return out


def visible_cats(kind: str, pset: tuple, pkgs: tuple = ()) -> list:
    # Eine Kategorie erscheint, wenn sie an ist, Einträge von einem Anbieter des Benutzers enthält
    # und (falls er Pakete hat) in einem seiner Pakete liegt.
    allow = allowed_keys(pkgs)
    return [c for c in V().get(kind, {}).get("cats", []) if c["show"] and set(c["provs"]) & set(pset)
            and (allow is None or f"{kind}:{c['vid']}" in allow)]


def list_categories(kind: str, pset: tuple, pkgs: tuple = ()) -> list:
    out = [{"category_id": c["vid"], "category_name": c["name"], "parent_id": 0} for c in visible_cats(kind, pset, pkgs)]
    if kind == "live" and live_state["cats"]:
        vis = {o["stream_id"]: o for o in list_items("live", pset, None, pkgs, rel=True, with_live=False)}
        lc = livecat_items(pset, pkgs, vis)
        out = [{"category_id": v, "category_name": name, "parent_id": 0} for v, (name, _) in lc.items()] + out
    return out


BASE_MARK = "@@ONYX_BASE@@"  # Platzhalter für die Adresse eigener Logos – wird je Domain eingesetzt


def public_base(host: str = "") -> str:
    if host == BASE_MARK:
        return BASE_MARK
    bare = (host or "").split(":")[0].lower()
    if bare and norm_domain(bare) in all_domains():
        h = bare  # Logos über dieselbe Domain ausliefern, über die sich der Benutzer angemeldet hat
    else:
        h = config.get("public_host") or bare or "localhost"
    return h if h.startswith("http") else f"http://{h}"


def list_for(key: tuple):
    """Liste für (Art, was, Anbieter, Pakete, Kategorie, Domain) -> (Cache-Schlüssel, Inhalt).
    Gebaut wird nur einmal pro Stand, egal über welche Domain gefragt wird. Nur wenn eigene Logos drin sind,
    wird deren Adresse je Domain eingesetzt (reine Textersetzung, kein Neubau)."""
    kind, what, pset, pkgs, cat, host = key
    base = (kind, what, pset, pkgs, cat, "")

    def build():
        data = list_categories(kind, pset, pkgs) if what == "cats" else list_items(kind, pset, cat, pkgs, BASE_MARK)
        return dumps_list(data)
    body = cache_once(base, build)
    mark = BASE_MARK.encode()
    if mark not in body:
        return base, body
    pb = public_base(host)
    k2 = (kind, what, pset, pkgs, cat, pb)
    return k2, cache_once(k2, lambda: body.replace(mark, pb.encode()))


_list_enc = json.JSONEncoder(ensure_ascii=False, separators=(",", ":")).encode


def dumps_list(data) -> bytes:
    """Große Listen stückweise in Text umwandeln: Ein einziger Aufruf für 180 000 Filme hält den ganzen Server
    eine Sekunde lang an (auch Anmeldungen), in Stücken kommen andere Anfragen zwischendurch dran."""
    if not isinstance(data, list) or len(data) < 4000:
        return _list_enc(data).encode("utf-8")
    parts = [_list_enc(data[i:i + 2000])[1:-1] for i in range(0, len(data), 2000)]
    return ("[" + ",".join(p for p in parts if p) + "]").encode("utf-8")


def cached_list(key: tuple) -> bytes:
    return list_for(key)[1]


def cached_gz(key, body: bytes) -> bytes:
    return cache_once(key + ("gz",), lambda: gzip.compress(body, 5))


def warm_cache() -> None:
    """Nach jedem neuen Stand die großen Listen für die vorhandenen Benutzer vorbereiten – dann lädt die App sofort."""
    combos = []
    for u in list(users):
        pset, pkgs = user_providers(u), user_packages(u)
        if not pset:
            continue
        doms = (u.get("domains") or []) + [d for pk in pset for d in gen_domains(pk)]
        c = (pset, pkgs, doms[0] if doms else "")  # Domain zählt nur noch bei eigenen Logos
        if c not in combos:
            combos.append(c)
    t0, n = time.time(), 0
    for pset, pkgs, host in combos[:20]:
        for kind in KINDS:
            if kind != "live" and "A" not in pset:
                continue
            for what in ("cats", "items"):
                try:
                    k, body = list_for((kind, what, pset, pkgs, None, host))
                    if len(body) > 1024:
                        cached_gz(k, body)
                    n += 1
                except Exception as e:
                    log.warning("Vorbereiten %s: %s", kind, e)
    if n:
        log.info("Listen vorbereitet: %d in %.1f s", n, time.time() - t0)


def list_items(kind: str, pset: tuple, cat: str | None, pkgs: tuple = (), host: str = "", rel: bool = False,
               with_live: bool = True) -> list:
    if kind == "live" and with_live and live_state["cats"] and (cat is None or is_livecat(cat)):
        base = list_items("live", pset, None, pkgs, host, rel, with_live=False)
        lc = livecat_items(pset, pkgs, {o["stream_id"]: o for o in base})
        extra = [o for _, (_, lst) in lc.items() for o in lst]
        for n, o in enumerate(extra, 1):  # eigene Nummern ab 90000 – die normalen Sendernummern bleiben gleich
            o["num"] = 90000 + n
        if cat:
            return [o for o in extra if o["category_id"] == cat]
        return extra + base
    out, num = [], 0
    icon_key = "cover" if kind == "series" else "stream_icon"
    items = V().get(kind, {}).get("items", {})
    for c in visible_cats(kind, pset, pkgs):
        if cat and c["vid"] != cat:
            continue
        for it in items.get(c["vid"], []):
            if it.get("_hide") or it["_p"] not in pset:
                continue
            num += 1
            o = {k: v for k, v in it.items() if not k.startswith("_")}
            if it.get("_icon"):
                o[icon_key] = public_base(host) + it["_icon"] if it["_icon"].startswith("/") and not rel else it["_icon"]
            o["num"] = V()["nums"].get(it["stream_id"], num) if kind == "live" and V().get("nums") else num
            out.append(o)
    return out


# ---------------------------------------------------------------- Live-Kategorien (aus dem Programm)
# Beispiel: „Heute live: Fußball“ – sammelt alle Sender, auf denen heute laut EPG ein passendes Spiel läuft.
# Alles kommt aus dem gespeicherten Programm, es gibt keine einzige zusätzliche Anfrage beim Anbieter.
LIVECAT_BASE = 8_000_000          # Kategorie-IDs der Live-Kategorien
DYN_BASE = 1_900_000_000          # Sender-IDs der Einträge darin (werden auf den echten Sender umgeleitet)
EXCLUDE_DEFAULT = ["Highlights", "Zusammenfassung", "Zusammenfassungen", "Magazin", "Analyse", "Studio", "Talk",
                   "Wiederholung", "Re-Live", "Relive", "Classics", "Klassiker", "Doku", "Dokumentation", "News",
                   "Nachrichten", "Rückblick", "Best of", "Tor des Monats",
                   "Özet", "Özetler", "Tekrar", "Stüdyo", "Haber", "Haberler", "Belgesel", "Program", "Yorum", "Analiz"]
LIVECAT_PRESETS = {
    "fussball": {"name": "Heute live: Fußball", "words": [
        "Bundesliga", "2. Bundesliga", "3. Liga", "DFB-Pokal", "Champions League", "Europa League", "Conference League",
        "Premier League", "FA Cup", "LaLiga", "La Liga", "Serie A", "Ligue 1", "Eredivisie", "Süper Lig", "Super Lig",
        "Nations League", "EM-Qualifikation", "WM-Qualifikation", "Länderspiel", "Supercup", "Fußball", "Football",
        "Futbol", "TFF 1. Lig", "Türkiye Kupası", "Süper Kupa", "Şampiyonlar Ligi", "Avrupa Ligi", "Konferans Ligi"],
        "exclude": EXCLUDE_DEFAULT},
    "kaempfe": {"name": "Heute live: Kämpfe", "words": [
        "UFC", "Boxen", "Boxing", "Boxkampf", "Box-Gala", "MMA", "Kickboxen", "Kickboxing", "Glory", "PFL", "Bellator",
        "Oktagon", "ONE Championship", "Muay Thai", "Fight Night", "WWE", "AEW", "Wrestling", "Boks", "Kick Boks", "Kickboks"],
        "exclude": EXCLUDE_DEFAULT},
}
live_state: dict = {"cats": [], "computed": 0, "sig": ""}
dyn_map: dict = load_json("dynmap.json", {"next": 1, "ids": {}})   # "realvid:start" -> dyn-Nummer
dyn_rev: dict = {DYN_BASE + int(n): k for k, n in dyn_map.get("ids", {}).items()}
_dyn_lock = threading.Lock()


def is_livecat(cat) -> bool:
    return str(cat).isdigit() and LIVECAT_BASE < int(cat) < LIVECAT_BASE + 1_000_000


def livecats_cfg() -> list:
    return curation.setdefault("livecats", [])


def dyn_id(real: int, start: int) -> int:
    key = f"{real}:{start}"
    with _dyn_lock:
        n = dyn_map["ids"].get(key)
        if n is None:
            n = dyn_map["next"]
            dyn_map["next"] = n + 1 if n < 200_000_000 else 1
            dyn_map["ids"][key] = n
            dyn_rev[DYN_BASE + n] = key
        return DYN_BASE + n


def dyn_real(vid: int):
    """Echter Sender hinter einem Eintrag einer Live-Kategorie (oder None)."""
    if vid < DYN_BASE:
        return vid
    key = dyn_rev.get(vid)
    return int(key.split(":")[0]) if key else None


def dyn_cleanup() -> None:
    cutoff = time.time() - 2 * 86400
    with _dyn_lock:
        for k in [k for k in dyn_map["ids"] if int(k.split(":")[1]) < cutoff]:
            dyn_rev.pop(DYN_BASE + dyn_map["ids"].pop(k), None)
        save_json("dynmap.json", dyn_map)


def live_channel_index() -> dict:
    """EPG-Kanal -> Sender in deiner Reihenfolge (nur sichtbare Kategorien, nicht ausgeblendet)."""
    idx = {}
    pos = 0
    for c in V().get("live", {}).get("cats", []):
        if not c["show"]:
            continue
        for it in V()["live"]["items"].get(c["vid"], []):
            ch = it.get("epg_channel_id")
            if not ch or it.get("_hide"):
                continue
            pos += 1
            idx.setdefault(ch, []).append({"vid": it["stream_id"], "name": it.get("name", ""), "p": it["_p"],
                                           "cat": c["vid"], "pos": pos})
    return idx


_lc_memo: dict = {}  # (Wörter, Ausschlüsse, Beschreibung) -> {Text: Treffer?}


def match_events(lc: dict, idx: dict, now=None) -> list:
    rx = pattern_regex(lc.get("words", []))
    if not rx or not idx:
        return []
    ex = pattern_regex(lc.get("exclude", []))
    now = int(now or time.time())
    hi = now + int(lc.get("hours", 18)) * 3600
    con = epg_conn()
    rows = con.execute("SELECT channel, start, stop, title, descr FROM prog WHERE stop > ? AND start < ?", (now, hi)).fetchall()
    con.close()
    # Treffer je Text merken: Das EPG ändert sich nur einmal am Tag, geprüft wird aber alle 5 Minuten
    mkey = (tuple(lc.get("words", [])), tuple(lc.get("exclude", [])), bool(lc.get("desc")))
    hits = _lc_memo.setdefault(mkey, {})
    if len(hits) > 300_000:
        hits.clear()
    events, seen = {}, {}
    for ch, st, sp, title, descr in rows:
        cands = idx.get(ch)
        if not cands:
            continue
        text = title + ("\n" + descr if lc.get("desc") else "")
        ok = hits.get(text)
        if ok is None:
            ok = hits[text] = bool(rx.search(text)) and not (ex and ex.search(title))
        if not ok:
            continue
        key = (re.sub(r"\W+", " ", title).strip().lower(), st)
        e = events.get(key)
        if e is None:
            e = events[key] = {"title": title.strip(), "start": st, "stop": sp, "cands": []}
            seen[key] = set()
        got = seen[key]
        for s in cands:  # Menge statt Liste: jeder Sender nur einmal, ohne die ganze Liste zu durchsuchen
            if s["vid"] not in got:
                got.add(s["vid"])
                e["cands"].append(s)
    out = sorted(events.values(), key=lambda e: (e["start"], e["title"].lower()))
    for e in out:
        e["cands"].sort(key=lambda s: s["pos"])
    return out


def compute_livecats() -> None:
    try:
        idx = live_channel_index()
        cats = []
        for n, lc in enumerate(livecats_cfg()):
            if not lc.get("enabled", True):
                continue
            cats.append({"vid": str(LIVECAT_BASE + int(lc.get("num") or n + 1)), "id": lc.get("id"), "name": lc.get("name") or "Live",
                         "max": max(1, int(lc.get("max_per_event", 2))), "events": match_events(lc, idx)})
        now = int(time.time())
        before = dyn_map["next"]
        for c in cats:  # IDs vorab vergeben und speichern, damit sie einen Neustart überstehen (die vorderen reichen)
            for e in c["events"]:
                for s in e["cands"][:12]:
                    dyn_id(s["vid"], e["start"])
        if dyn_map["next"] != before:
            with _dyn_lock:
                save_json("dynmap.json", dyn_map)
        sig = json.dumps([[c["vid"], c["name"], [(e["title"], e["start"], e["start"] <= now, [s["vid"] for s in e["cands"]])
                                                 for e in c["events"]]] for c in cats])
        with lock:
            changed = sig != live_state["sig"]
            live_state.update({"cats": cats, "computed": now, "sig": sig})
            if changed:  # nur Listen, die Live-Kategorien enthalten – nicht jede einzelne Live-Kategorie
                for k in [k for k in list(resp_cache) if isinstance(k, tuple) and len(k) >= 5 and k[0] == "live"
                          and (k[1] == "cats" or k[4] is None or is_livecat(k[4]))]:
                    resp_cache.pop(k, None)
    except Exception as e:
        log.error("Live-Kategorien: %s", e)


def livecat_scheduler() -> None:
    n = 0
    while True:
        compute_livecats()
        n += 1
        if n % 288 == 0:
            dyn_cleanup()
        time.sleep(300)


def live_entry_name(e: dict, chan: str, now: int) -> str:
    z = tz()
    t = datetime.fromtimestamp(e["start"], z).strftime("%H:%M")
    if e["start"] <= now:
        t = "LIVE"
    elif datetime.fromtimestamp(e["start"], z).date() != datetime.fromtimestamp(now, z).date():
        t = "Morgen " + t
    return f"{t} | {e['title']} | {chan}"


def livecat_items(pset: tuple, pkgs: tuple, user_vis: dict) -> dict:
    """Live-Kategorie-vid -> Einträge für diesen Benutzer. user_vis: echte vid -> sichtbarer Eintrag."""
    out = {}
    now = int(time.time())
    for c in live_state["cats"]:
        lst = []
        for e in c["events"]:
            if e["stop"] <= now:
                continue
            picked = [s for s in e["cands"] if s["vid"] in user_vis][:c["max"]]
            for s in picked:
                base = user_vis[s["vid"]]
                o = dict(base)
                o["stream_id"] = dyn_id(s["vid"], e["start"])
                o["name"] = live_entry_name(e, base.get("name", ""), now)
                o["category_id"] = c["vid"]
                o["category_ids"] = [int(c["vid"])]
                o.pop("custom_sid", None)
                lst.append(o)
        if lst:
            out[c["vid"]] = (c["name"], lst)
    return out


# ---------------------------------------------------------------- Aufrufe zählen (anonym, nur Summen pro Sender/Tag)
STATS_DB = _path("stats.sqlite")
_plays_mem: dict = {}
_plays_seen: dict = {}
_stats_cache: dict = {}


def _stats_setup(c) -> None:
    c.execute("CREATE TABLE IF NOT EXISTS plays(day TEXT, kind TEXT, vid INTEGER, n INTEGER, PRIMARY KEY(day, kind, vid))")
    c.execute("CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT)")
    c.execute("INSERT OR IGNORE INTO meta VALUES('since', ?)", (str(int(time.time())),))


def stats_conn() -> sqlite3.Connection:
    return db_open(STATS_DB, _stats_setup)


def count_play(user: str, kind: str, vid: int) -> None:
    """Neuverbindungen desselben Benutzers zum selben Sender innerhalb von 10 Minuten zählen nicht doppelt."""
    now = time.time()
    k = (user, kind, vid)
    if now - _plays_seen.get(k, 0) < 600:
        _plays_seen[k] = now
        return
    _plays_seen[k] = now
    day = datetime.now(tz()).strftime("%Y-%m-%d")
    with lock:
        _plays_mem[(day, kind, vid)] = _plays_mem.get((day, kind, vid), 0) + 1
    if len(_plays_seen) > 20000:
        for kk in [kk for kk, t in _plays_seen.items() if now - t > 600]:
            _plays_seen.pop(kk, None)


def stats_flush() -> None:
    with lock:
        batch = list(_plays_mem.items())
        _plays_mem.clear()
    if not batch:
        return
    con = stats_conn()
    con.executemany("INSERT INTO plays VALUES(?,?,?,?) ON CONFLICT(day,kind,vid) DO UPDATE SET n = n + excluded.n",
                    [(d, k, v, n) for (d, k, v), n in batch])
    cutoff = (datetime.now(tz()) - timedelta(days=90)).strftime("%Y-%m-%d")
    con.execute("DELETE FROM plays WHERE day < ?", (cutoff,))
    con.commit()
    con.close()
    _stats_cache.clear()


def stats_scheduler() -> None:
    while True:
        time.sleep(60)
        try:
            stats_flush()
        except Exception as e:
            log.error("Statistik: %s", e)


def plays_30d(kind: str) -> dict:
    hit = _stats_cache.get(kind)
    if hit and time.time() - hit[0] < 60:
        return hit[1]
    cutoff = (datetime.now(tz()) - timedelta(days=30)).strftime("%Y-%m-%d")
    con = stats_conn()
    data = {vid: n for vid, n in con.execute("SELECT vid, SUM(n) FROM plays WHERE kind=? AND day>=? GROUP BY vid", (kind, cutoff))}
    con.close()
    with lock:
        for (d, k, v), n in _plays_mem.items():
            if k == kind:
                data[v] = data.get(v, 0) + n
    _stats_cache[kind] = (time.time(), data)
    return data


def stats_since() -> int:
    con = stats_conn()
    v = con.execute("SELECT v FROM meta WHERE k='since'").fetchone()
    con.close()
    return int(v[0]) if v else int(time.time())




# ---------------------------------------------------------------- Diagnose
# Onyx Merge sieht keine Streams (die laufen direkt Gerät -> Anbieter), aber jeden START eines Senders.
# Aus dem Muster der Starts lässt sich viel ablesen: Neustart desselben Senders kurz danach = Abbruch,
# zwei Geräte abwechselnd auf einer Line = Verbindungslimit usw. Alles bleibt 7 Tage, dann wird es gelöscht.
DIAG_DB = _path("diag.sqlite")
DIAG_DAYS = 7
RESTART_WIN = 600      # derselbe Sender innerhalb von 10 Min. erneut gestartet = Abbruch/Hänger
FAIL_WIN = 45          # ... innerhalb von 45 Sek. = startet gar nicht richtig
_diag_lock = threading.Lock()
_diag_con = None
_isp_cache: dict = load_json("isp_cache.json", {})
_isp_busy: set = set()


def diag_conn() -> sqlite3.Connection:
    global _diag_con
    if _diag_con is None:
        c = db_open(DIAG_DB, check_same_thread=False)
        c.execute("CREATE TABLE IF NOT EXISTS starts(t INTEGER, user TEXT, kind TEXT, vid INTEGER, name TEXT, pkey TEXT,"
                  " line TEXT, ip TEXT, ua TEXT, host TEXT, gone INTEGER)")
        c.execute("CREATE INDEX IF NOT EXISTS starts_t ON starts(t)")
        c.execute("CREATE TABLE IF NOT EXISTS refused(t INTEGER, user TEXT, why TEXT, host TEXT, ip TEXT, ua TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS speed(t INTEGER, user TEXT, down REAL, ping REAL, jitter REAL, ip TEXT, ua TEXT)")
        _diag_con = c
    return _diag_con


def diag_exec(sql: str, args=()) -> None:
    try:
        with _diag_lock:
            c = diag_conn()
            c.execute(sql, args)
            c.commit()
    except Exception as e:
        log.warning("Diagnose: %s", e)


def diag_query(sql: str, args=()) -> list:
    with _diag_lock:
        return diag_conn().execute(sql, args).fetchall()


def diag_cleanup() -> None:
    cut = int(time.time()) - DIAG_DAYS * 86400
    for t in ("starts", "refused", "speed"):
        diag_exec(f"DELETE FROM {t} WHERE t < ?", (cut,))
    for ip in [ip for ip, v in _isp_cache.items() if v.get("t", 0) < cut]:
        _isp_cache.pop(ip, None)
    save_json("isp_cache.json", _isp_cache)


FIRE_TV = {"AFTMM": "Fire TV Stick 4K", "AFTKA": "Fire TV Stick 4K Max", "AFTKM": "Fire TV Stick 4K (2. Gen.)",
           "AFTSSS": "Fire TV Stick (3. Gen.)", "AFTSS": "Fire TV Stick Lite", "AFTT": "Fire TV Stick (2. Gen.)",
           "AFTN": "Fire TV (3. Gen.)", "AFTR": "Fire TV Cube", "AFTMA": "Fire TV Stick 4K Max (2. Gen.)"}


def parse_ua(ua: str) -> tuple:
    """User-Agent -> (Gerät, App). Nur eine Einschätzung – Apps schreiben dort, was sie wollen."""
    u = ua or ""
    dev = "unbekanntes Gerät"
    m = re.search(r"\b(AFT[A-Z0-9]+)\b", u)
    if m:
        dev = FIRE_TV.get(m.group(1), f"Fire TV ({m.group(1)})")
    elif re.search(r"iPhone", u):
        dev = "iPhone"
    elif re.search(r"iPad", u):
        dev = "iPad"
    elif re.search(r"Tizen", u):
        dev = "Samsung-Fernseher"
    elif re.search(r"Web0S|webOS", u, re.I):
        dev = "LG-Fernseher"
    elif re.search(r"Windows NT", u):
        dev = "Windows-PC"
    elif re.search(r"Macintosh|Mac OS X", u):
        dev = "Mac"
    elif re.search(r"Android", u):
        mm = re.search(r"Android [\d.]+; (?:[a-z]{2}[-_][A-Z]{2}; )?([^;)]+?)(?: Build|\))", u)
        model = (mm.group(1).strip() if mm else "")
        tv = re.search(r"TV|BRAVIA|SHIELD|MiBOX|Chromecast|AFT", u, re.I)
        dev = ("Android-TV" if tv else "Android") + (f" · {model}" if model and len(model) < 30 else "")
    app = "unbekannte App"
    for rx, name in ((r"Smarters", "IPTV Smarters"), (r"TiviMate", "TiviMate"), (r"OTT ?Navigator", "OTT Navigator"),
                     (r"VLC|LibVLC", "VLC"), (r"Kodi", "Kodi"), (r"ExoPlayer", "App mit ExoPlayer"),
                     (r"Lavf|ffmpeg", "FFmpeg-Player"), (r"okhttp", "Android-App (okhttp)"), (r"Dalvik", "Android-App"),
                     (r"Chrome|Firefox|Safari", "Browser")):
        if re.search(rx, u, re.I):
            app = name
            break
    return dev, app


ISP_NAMES = (("t-ipconnect.de", "Telekom"), ("telekom", "Telekom"), ("kabel-deutschland", "Vodafone Kabel"),
             ("unitymedia", "Vodafone Kabel"), ("vodafone.net.tr", "Vodafone Türkei"), ("vodafone", "Vodafone"),
             ("telefonica", "o2"), ("o2online", "o2"), ("versatel", "1&1 Versatel"), ("1und1", "1&1"),
             ("ewe-ip", "EWE"), ("netcologne", "NetCologne"), ("m-online", "M-net"), ("pyur", "PŸUR"),
             ("tele-columbus", "PŸUR"), ("htp", "htp"), ("wilhelm-tel", "wilhelm.tel"), ("deutsche-glasfaser", "Deutsche Glasfaser"),
             ("ttnet", "Türk Telekom"), ("superonline", "Turkcell Superonline"), ("turk.net", "TurkNet"),
             ("starlink", "Starlink"), ("a1.net", "A1"), ("magenta", "Magenta"), ("upc", "UPC"), ("swisscom", "Swisscom"),
             ("sunrise", "Sunrise"), ("salt.ch", "Salt"))


def _private(ip: str) -> bool:
    return bool(re.match(r"^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1$|fc|fd)", ip or ""))


def isp_of(ip: str) -> str:
    """Internetanbieter aus dem Rückwärts-DNS der IP (fragt einen DNS-Server, keinen IPTV-Anbieter)."""
    if not ip:
        return ""
    if _private(ip):
        return "lokales Netz"
    hit = _isp_cache.get(ip)
    if hit:
        return hit["isp"]
    if ip not in _isp_busy and len(_isp_busy) < 8:
        _isp_busy.add(ip)

        def look():
            name = ""
            try:
                host = socket.gethostbyaddr(ip)[0].lower()
                name = next((n for k, n in ISP_NAMES if k in host), "") or ".".join(host.split(".")[-2:])
                if re.search(r"mobil|mobile|lte|5g", host):
                    name += " (Mobilfunk)"
            except Exception:
                name = "unbekannt"
            _isp_cache[ip] = {"isp": name, "t": int(time.time())}
            _isp_busy.discard(ip)
        threading.Thread(target=look, daemon=True).start()
    return ""


def item_name(kind: str, vid: int):
    """Name eines Senders/Films aus der aktuellen Liste – None, wenn es ihn nicht (mehr) gibt."""
    return V().get("names", {}).get((kind, vid))


def log_start(u: dict, kind: str, vid: int, pkey: str, ip: str, ua: str, host: str) -> None:
    k = "live" if kind in ("live", "timeshift") else ("vod" if kind == "movie" else "series")
    name = item_name(k, vid) if k != "series" else f"Serienfolge {vid}"
    gone = 1 if (k != "series" and name is None and V().get("names")) else 0
    diag_exec("INSERT INTO starts VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              (int(time.time()), u["username"], k, vid, name or f"#{vid}", pkey, (u.get(pkey) or {}).get("user", ""),
               ip, (ua or "")[:300], norm_domain(host), gone))
    isp_of(ip)


def log_refused(user: str, why: str, host: str, ip: str, ua: str) -> None:
    diag_exec("INSERT INTO refused VALUES(?,?,?,?,?,?)", (int(time.time()), user, why, norm_domain(host), ip, (ua or "")[:300]))


def classify(rows: list, now: int) -> list:
    """rows: Starts eines Benutzers, nach Zeit sortiert. Ergänzt je Start: Dauer-Schätzung und Ergebnis."""
    out = []
    for i, r in enumerate(rows):
        t, vid = r["t"], r["vid"]
        nxt = rows[i + 1] if i + 1 < len(rows) else None
        prev = rows[i - 1] if i else None
        res = dict(r)
        res["restart"] = bool(prev and prev["vid"] == vid and t - prev["t"] <= RESTART_WIN)
        if nxt:
            gap = nxt["t"] - t
            res["dur"] = gap
            if nxt["vid"] == vid and gap <= FAIL_WIN:
                res["result"] = "fail"           # startete nicht richtig
            elif nxt["vid"] == vid and gap <= RESTART_WIN:
                res["result"] = "drop"           # brach nach kurzer Zeit ab
            elif gap < 90:
                res["result"] = "zap"            # schnell weitergeschaltet
            else:
                res["result"] = "ok"
        else:
            res["dur"] = now - t
            res["result"] = "running" if now - t < 6 * 3600 else "ok"
        out.append(res)
    return out


def load_starts(since: int) -> dict:
    rows = diag_query("SELECT t,user,kind,vid,name,pkey,line,ip,ua,host,gone FROM starts WHERE t>=? ORDER BY t", (since,))
    by = {}
    for t, user, kind, vid, name, pkey, line, ip, ua, host, gone in rows:
        dev, app = parse_ua(ua)
        by.setdefault(user, []).append({"t": t, "user": user, "kind": kind, "vid": vid, "name": name, "pkey": pkey,
                                        "line": line, "ip": ip, "ua": ua, "dev": dev, "app": app, "host": host, "gone": gone})
    now = int(time.time())
    return {u: classify(lst, now) for u, lst in by.items()}


def fmt_t(t: int) -> str:
    d = datetime.fromtimestamp(t, tz())
    today = datetime.now(tz()).date()
    day = "heute" if d.date() == today else "gestern" if (today - d.date()).days == 1 else d.strftime("%d.%m.")
    return f"{day} {d.strftime('%H:%M')}"


def fmt_dur(s: int) -> str:
    return f"{s} Sek." if s < 90 else f"{round(s / 60)} Min." if s < 5400 else f"{s / 3600:.1f} Std.".replace(".", ",")


def diagnose(hours: int = 24) -> dict:
    now = int(time.time())
    since = now - hours * 3600
    week = load_starts(now - DIAG_DAYS * 86400)
    day = {u: [r for r in lst if r["t"] >= since] for u, lst in week.items()}
    day = {u: lst for u, lst in day.items() if lst}
    F = []

    def add(level, kind, title, what, meaning, todo, **extra):
        F.append({"level": level, "kind": kind, "title": title, "what": what, "meaning": meaning, "todo": todo, **extra})

    # 1) Line doppelt vergeben (schon ohne Abbruch sichtbar)
    lines = {}
    for u in users:
        for pk in ("A", "B"):
            ln = (u.get(pk) or {}).get("user")
            if ln:
                lines.setdefault((pk, ln), []).append(u["username"])
    for (pk, ln), us in lines.items():
        if len(us) > 1:
            add(2, "shared_line", f"Line „{ln}“ ist bei {len(us)} Benutzern eingetragen",
                f"{', '.join(us)} nutzen dieselbe Line bei {pname(pk)}.",
                "Eine Line erlaubt beim Anbieter meist nur eine Verbindung gleichzeitig. Schauen zwei davon zur selben Zeit, "
                "wirft der Anbieter einen raus – bei dem bricht der Stream ab.",
                "Jedem Benutzer eine eigene Line geben – oder sicherstellen, dass nie zwei gleichzeitig schauen.", users=us)

    # 2) Zwei Geräte auf einer Line (abwechselnde Neustarts von verschiedenen Geräten)
    per_line = {}
    for lst in day.values():
        for r in lst:
            if r["line"]:
                per_line.setdefault((r["pkey"], r["line"]), []).append(r)
    conflict_users = set()
    for (pk, ln), lst in per_line.items():
        lst.sort(key=lambda r: r["t"])
        hits, i = [], 0
        while i < len(lst):
            win = [x for x in lst[i:] if x["t"] - lst[i]["t"] <= 1200]
            devs = {(x["ip"], x["dev"]) for x in win}
            if len(devs) >= 2 and sum(1 for x in win if x["restart"] or x["result"] in ("drop", "fail")) >= 2:
                hits.append(win)
                i += len(win)
            else:
                i += 1
        if hits:
            devs = sorted({f"{x['dev']} ({x['ip']})" for w in hits for x in w})
            us = sorted({x["user"] for w in hits for x in w})
            conflict_users |= set(us)
            strong = len(hits) >= 2 or any(sum(1 for x in w if x["restart"] or x["result"] in ("drop", "fail")) >= 3 for w in hits)
            add(2 if strong else 1, "two_devices", f"Zwei Geräte teilen sich die Line „{ln}“",
                f"{len(hits)}× liefen innerhalb von 20 Minuten Streams von verschiedenen Geräten auf dieser Line, mit Neustarts dazwischen: "
                f"{', '.join(devs)}. Zuletzt {fmt_t(hits[-1][0]['t'])}." + (f" Betroffen: {', '.join(us)}." if len(us) > 1 else ""),
                "Startet ein zweites Gerät einen Stream, beendet der Anbieter meist den ersten – das erste Gerät verbindet sich neu, "
                "wirft dabei wieder das zweite raus usw. Für die Zuschauer sieht das aus wie ständige Abbrüche.",
                "Nur ein Gerät pro Line gleichzeitig benutzen, oder eine Line mit mehr Verbindungen bzw. eine zweite Line nehmen.",
                users=us)

    # 3) Sender gestört / startet nicht (mehrere Benutzer)
    per_ch = {}
    for lst in day.values():
        for r in lst:
            if r["result"] in ("drop", "fail") and r["kind"] == "live":
                per_ch.setdefault(r["vid"], []).append(r)
    bad_channels = set()
    for vid, lst in per_ch.items():
        us = sorted({r["user"] for r in lst})
        if len(us) >= 2 and len(lst) >= 3:
            bad_channels.add(vid)
            fails = sum(1 for r in lst if r["result"] == "fail")
            name = lst[0]["name"]
            add(2, "channel", f"„{name}“ macht Probleme",
                f"{len(lst)} Abbrüche bei {len(us)} Benutzern ({', '.join(us)}), davon {fails}× startete er gar nicht richtig. "
                f"Zuletzt {fmt_t(lst[-1]['t'])}.",
                "Wenn derselbe Sender bei mehreren Leuten abbricht, liegt es fast sicher am Sender bzw. am Anbieter – nicht an euren Anschlüssen.",
                "Im Editor eine andere Variante desselben Senders testen (z. B. HD statt FHD oder vom anderen Anbieter) und die störende ausblenden. "
                "Hält es länger an: dem Anbieter melden.", channels=[name], vids=[vid])

    # 4) Anbieter gestört (viele Benutzer und Sender in 15 Minuten)
    buckets = {}
    for lst in day.values():
        for r in lst:
            if r["result"] in ("drop", "fail"):
                buckets.setdefault((r["pkey"], r["t"] // 900), []).append(r)
    seen_b = set()
    for (pk, b), lst in sorted(buckets.items()):
        us, chs = {r["user"] for r in lst}, {r["vid"] for r in lst}
        if len(us) >= 3 and len(chs) >= 3 and (pk, b - 1) not in seen_b:
            seen_b.add((pk, b))
            add(3, "provider", f"Störung bei {pname(pk)} um {fmt_t(b * 900)}",
                f"Innerhalb von 15 Minuten Abbrüche bei {len(us)} Benutzern auf {len(chs)} verschiedenen Sendern.",
                "Wenn fast alle gleichzeitig auf verschiedenen Sendern Probleme haben, liegt eine Störung oder Überlastung beim Anbieter vor "
                "(häufig bei großen Fußballspielen). Eure Anschlüsse sind dann sehr wahrscheinlich nicht schuld.",
                "Abwarten – meist ist es nach kurzer Zeit vorbei. Passiert es oft zur gleichen Zeit, beim Anbieter nachfragen.")

    # 5) Anschluss eines Benutzers (Abbrüche auf vielen Sendern, die anderen nicht)
    for user, lst in day.items():
        if user in conflict_users:
            continue
        drops = [r for r in lst if r["result"] in ("drop", "fail") and r["vid"] not in bad_channels]
        chs = {r["vid"] for r in drops}
        if len(drops) >= 5 and len(chs) >= 3:
            isps = sorted({isp_of(r["ip"]) or "noch unbekannt" for r in drops})
            devs = sorted({r["dev"] for r in drops})
            others = [u for u, l in day.items() if u != user and len(l) >= 3]
            calm = [u for u in others if sum(1 for r in day[u] if r["result"] in ("drop", "fail")) <= 1]
            add(2, "user_conn", f"{user} hat Abbrüche auf vielen Sendern",
                f"{len(drops)} Abbrüche auf {len(chs)} verschiedenen Sendern in {hours} Stunden. Gerät: {', '.join(devs)}. "
                f"Anschluss: {', '.join(isps)}." + (f" Bei {', '.join(calm)} lief es im selben Zeitraum ruhig." if calm else ""),
                "Wenn nur eine Person auf vielen verschiedenen Sendern Abbrüche hat, liegt es fast immer an ihrem Zuhause: "
                "WLAN zu schwach, Internet zu langsam oder ausgelastet, oder das Gerät selbst (z. B. ein älterer Fire TV Stick).",
                "Geschwindigkeitstest machen lassen (Link im Benutzer-Fenster). Fire TV möglichst per LAN-Adapter oder näher am Router; "
                "Fire TV einmal neu starten; andere Downloads im Haushalt prüfen.", users=[user])

    # 6) Abends überlastet / mögliche Drosselung (7 Tage)
    for user, lst in week.items():
        drops = [r for r in lst if r["result"] in ("drop", "fail")]
        if len(drops) < 6 or user in conflict_users:
            continue
        eve = [r for r in drops if 18 <= datetime.fromtimestamp(r["t"], tz()).hour <= 23]
        days_ = {datetime.fromtimestamp(r["t"], tz()).date() for r in eve}
        if len(eve) >= 0.7 * len(drops) and len(days_) >= 2:
            isps = sorted({isp_of(r["ip"]) or "noch unbekannt" for r in eve})
            add(2, "evening", f"{user}: Abbrüche fast nur abends",
                f"{len(eve)} von {len(drops)} Abbrüchen der letzten {DIAG_DAYS} Tage lagen zwischen 18 und 24 Uhr, an {len(days_)} verschiedenen Tagen. "
                f"Anschluss: {', '.join(isps)}.",
                "Abends ist das Internet am vollsten. Treten Abbrüche fast nur dann auf – und nur bei dieser Person –, ist der Anschluss bzw. "
                "der Internetanbieter zu dieser Zeit überlastet oder bremst Streaming. Das ist das typischste Zeichen für Drosselung; "
                "beweisen lässt es sich von hier aus aber nicht.",
                "Abends einen Geschwindigkeitstest machen lassen und mit tagsüber vergleichen. Ist er abends deutlich langsamer: "
                "beim Internetanbieter beschweren oder einen VPN im Fire TV ausprobieren (umgeht gezieltes Bremsen).", users=[user])

    # 7) Sender gibt es nicht mehr
    gone = {}
    for lst in day.values():
        for r in lst:
            if r["gone"]:
                gone.setdefault(r["name"], set()).add(r["user"])
    if gone:
        add(1, "gone", "Ein Sender wurde gestartet, den es nicht mehr gibt" if len(gone) == 1 else f"{len(gone)} Sender wurden gestartet, die es nicht mehr gibt",
            "; ".join(f"{n} ({', '.join(sorted(u))})" for n, u in list(gone.items())[:6]) + ".",
            "Der Anbieter hat diese Sender beim letzten Abgleich entfernt oder neu angelegt. Die App hat noch die alte Liste – "
            "deshalb startet der Sender nicht.",
            "In der App die Liste aktualisieren lassen. Im Editor unter „Neu seit dem Abgleich“ nach dem Ersatz schauen.")

    # 8) Abgelehnte Anmeldungen
    ref = diag_query("SELECT user, why, COUNT(*), MAX(t), GROUP_CONCAT(DISTINCT host) FROM refused WHERE t>=? GROUP BY user, why", (since,))
    for user, why, n, last, hosts in ref:
        tip = {"abgelaufen": "Unter Benutzer „+1 Monat“ oder ein neues Datum setzen.",
               "deaktiviert": "Unter Benutzer wieder aktivieren, falls gewollt.",
               "falsche Domain": "Er benutzt eine Domain, die für ihn nicht freigegeben ist – Domain in seiner App ändern oder bei ihm eintragen.",
               "falsches Passwort": "Passwort in seiner App prüfen lassen (Groß-/Kleinschreibung) oder ihm die Nachricht mit den Zugangsdaten neu schicken."}.get(why, "")
        add(2 if why != "falsches Passwort" or n >= 3 else 1, "refused", f"{user}: Anmeldung abgelehnt ({why})",
            f"{n}× seit {fmt_t(since)}, zuletzt {fmt_t(last)} über {hosts}.",
            "Die App zeigt dann nur „Login fehlgeschlagen“ – der Grund ist nur hier zu sehen.", tip, users=[user])

    # 9) Geschwindigkeitstests
    for user, down, ping, t in diag_query("SELECT user, down, ping, MAX(t) FROM speed WHERE t>=? GROUP BY user", (now - DIAG_DAYS * 86400,)):
        if down < 8:
            add(2, "speed", f"{user}: Internet zu langsam für HD",
                f"Geschwindigkeitstest {fmt_t(t)}: {down:.0f} Mbit/s, Reaktionszeit {ping:.0f} ms.",
                "Für HD braucht ein Stream etwa 8 Mbit/s, für Full HD 12, für 4K 25 – dauerhaft, nicht nur kurz. Darunter ruckelt oder bricht es ab.",
                "Näher am Router testen bzw. per Kabel. Ist es dann schnell: WLAN verbessern. Ist es auch dann langsam: Anschluss/Tarif beim Internetanbieter prüfen.",
                users=[user])
    F.sort(key=lambda f: -f["level"])
    totals = {"starts": sum(len(l) for l in day.values()), "drops": sum(1 for l in day.values() for r in l if r["result"] in ("drop", "fail")),
              "users": len(day)}
    return {"findings": F, "totals": totals, "hours": hours, "since": since}


def refused_help_message(why: str, user_name: str, host: str = "") -> str:
    """I11: Erzeugt eine fertige, freundliche Nachricht für den Kunden je nach Ablehnungsgrund."""
    usr = next((u for u in users if u.get("name") == user_name), None)
    domain = host or config.get("primary_domain") or "deine Server-Adresse"
    nl = chr(10)
    if why == "falsche Domain" or "Domain" in why:
        return f"Hallo! Dein Zugang funktioniert einwandfrei, aber in deiner App ist noch eine alte Server-Adresse hinterlegt. Bitte trage als Server/Portal-URL folgende Adresse ein:{nl}http://{domain}{nl}Benutzername und Passwort bleiben gleich!"
    elif why == "abgelaufen" or "Ablauf" in why:
        exp_txt = datetime.fromtimestamp(usr.get("exp", 0), tz()).strftime("%d.%m.%Y") if usr and usr.get("exp") else "vor Kurzem"
        return f"Hallo! Dein Zugang ist am {exp_txt} abgelaufen.{nl}Wenn du deinen Zugang verlängern möchtest, sag mir einfach kurz Bescheid, dann schalte ich ihn sofort wieder frei!"
    elif why == "falsches Passwort" or "Passwort" in why:
        pw = usr.get("pass", "******") if usr else "dein Passwort"
        return f"Hallo! Bei deiner Anmeldung wurde das Passwort abgelehnt.{nl}Hier sind deine korrekten Zugangsdaten:{nl}Benutzername: {user_name}{nl}Passwort: {pw}{nl}Bitte achte genau auf Groß- und Kleinschreibung!"
    elif why == "deaktiviert":
        return "Hallo! Dein Zugang ist momentan pausiert. Bitte melde dich kurz bei mir, wenn du ihn wieder nutzen möchtest."
    else:
        return f"Hallo! Bei deiner Anmeldung gab es ein Problem ({why}). Bitte melde dich kurz bei mir, damit wir das prüfen können."


def diag_user(name: str) -> dict:
    now = int(time.time())
    lst = load_starts(now - DIAG_DAYS * 86400).get(name, [])
    devs = {}
    for r in lst:
        k = (r["dev"], r["app"], r["ip"])
        d = devs.setdefault(k, {"dev": r["dev"], "app": r["app"], "ip": r["ip"], "isp": isp_of(r["ip"]), "first": r["t"], "last": r["t"], "n": 0})
        d["last"] = r["t"]
        d["n"] += 1
    speeds = [{"t": t, "down": d, "ping": p, "jitter": j, "isp": isp_of(ip)}
              for t, d, p, j, ip in diag_query("SELECT t, down, ping, jitter, ip FROM speed WHERE user=? ORDER BY t DESC LIMIT 10", (name,))]
    refused = [{"t": t, "why": w, "host": h, "help": refused_help_message(w, name, h)} for t, w, h in
               diag_query("SELECT t, why, host FROM refused WHERE user=? ORDER BY t DESC LIMIT 20", (name,))]
    starts = [{"t": r["t"], "name": r["name"], "kind": r["kind"], "pkey": r["pkey"], "dev": r["dev"], "isp": isp_of(r["ip"]),
               "result": r["result"], "dur": r["dur"], "restart": r["restart"], "gone": r["gone"]} for r in lst[-150:]][::-1]
    drops = sum(1 for r in lst if r["result"] in ("drop", "fail"))
    return {"devices": sorted(devs.values(), key=lambda d: -d["last"]), "speeds": speeds, "refused": refused, "starts": starts,
            "drops": drops, "total": len(lst), "token": speed_token(name)}


def diag_log(hours: int = 24, limit: int = 400) -> list:
    now = int(time.time())
    out = []
    for user, lst in load_starts(now - hours * 3600).items():
        for r in lst:
            out.append({"t": r["t"], "user": user, "name": r["name"], "kind": r["kind"], "pkey": r["pkey"], "dev": r["dev"],
                        "app": r["app"], "isp": isp_of(r["ip"]), "host": r["host"], "result": r["result"], "dur": r["dur"], "gone": r["gone"]})
    out.sort(key=lambda x: -x["t"])
    return out[:limit]


def drops_by_channel(hours: int = 24) -> dict:
    out = {}
    for lst in load_starts(int(time.time()) - hours * 3600).values():
        for r in lst:
            if r["result"] in ("drop", "fail"):
                out[r["vid"]] = out.get(r["vid"], 0) + 1
    return out


def diag_scheduler() -> None:
    while True:
        try:
            diag_cleanup()
        except Exception as e:
            log.error("Diagnose aufräumen: %s", e)
        time.sleep(6 * 3600)


# Geschwindigkeitstest
def speed_token(name: str) -> str:
    if not config.get("diag_secret"):
        config["diag_secret"] = secrets.token_hex(16)
        save_json("config.json", config)
    return hmac.new(config["diag_secret"].encode(), name.encode(), "sha256").hexdigest()[:20]


def user_by_token(tok: str):
    return next((u for u in users if hmac.compare_digest(speed_token(u["username"]), tok or "")), None)


_speed_rate: dict = {}
_RAND = os.urandom(1 << 20)
SPEEDTEST_HTML = os.path.join(HOME, "speedtest.html")
ME_HTML = os.path.join(HOME, "me.html")


# ---------------------------------------------------------------- Benutzer
_fail: dict = {}


def host_ok(u: dict, host: str) -> bool:
    """Eigene Domains: Hat ein Benutzer welche, klappt sein Login nur dort.
    Und eine Domain, die einem Benutzer gehört, ist für andere Onyx-Merge-Benutzer gesperrt."""
    h = norm_domain(host)
    if not h:
        return True
    mine = u.get("domains") or []
    if mine:
        return h in mine
    if any(h in (x.get("domains") or []) for x in users):
        return False  # gehört einem anderen Benutzer
    # Keine eigene Domain: die allgemeinen Domains der Anbieter, bei denen er eine Line hat
    allowed = [d for pk in user_providers(u) for d in gen_domains(pk)]
    known = gen_domains("A") + gen_domains("B")
    return h in allowed or h not in known


def domain_provider(host: str) -> str:
    """Zu welchem Anbieter gehört diese Domain? Panel-Kunden, die nicht in Onyx Merge angelegt sind,
    werden dorthin weitergereicht. Domains aus „2 Eigene Domain“ -> Anbieter 2, alles andere -> Anbieter 1."""
    h = norm_domain(host)
    if not h:
        return "A"
    in_a = h in gen_domains("A") or any(h in ((x.get("A") or {}).get("domains") or []) for x in users)
    in_b = h in gen_domains("B") or any(h in ((x.get("B") or {}).get("domains") or []) for x in users)
    return "B" if in_b and not in_a else "A"


# ---------------------------------------------------------------- Aktivität (sieht Onyx Merge selbst, kein Anbieter nötig)
activity: dict = load_json("activity.json", {})
_act = {"saved": 0.0}


_cur_ua: dict = {}  # User-Agent der laufenden Anfrage (je Thread) – für die Diagnose


def note_activity(name: str, host: str, ip: str, refused: str = "") -> None:
    now = int(time.time())
    a = activity.setdefault(name, {})
    h = norm_domain(host) or "?"
    if refused:
        if a.get("refused", {}).get("why") != refused or now - a.get("refused", {}).get("t", 0) > 60:
            log_refused(name, refused, host, ip, _cur_ua.get(threading.get_ident(), ""))
        a["refused"] = {"t": now, "why": refused, "host": h}
    else:
        a.update({"t": now, "host": h, "ip": ip})
        a.pop("refused", None) if a.get("refused", {}).get("t", 0) < now - 60 else None
    if time.time() - _act["saved"] > 60:  # höchstens einmal pro Minute auf die Platte
        _act["saved"] = time.time()
        try:
            save_json("activity.json", activity)
        except Exception as e:
            log.warning("activity.json: %s", e)


# Zugänge, die (noch) durchgereicht werden – damit du sie in den Merger übernehmen kannst.
# Liegt wie users.json nur im Datenordner (0600). Das Passwort wird gebraucht, damit der Kunde sich nach der Übernahme
# mit genau denselben Daten anmeldet wie bisher.
passthru: dict = load_json("passthru.json", {})
_pt = {"saved": 0.0}


def pt_note(pkey: str, name: str, pw: str, host: str, ip: str, info: dict | None = None, stream: bool = False) -> None:
    if not name or len(name) > 80 or any(u.get("username") == name for u in users):
        return
    now = int(time.time())
    key = f"{pkey}:{name}"
    with lock:
        e = passthru.setdefault(key, {"provider": pkey, "user": name, "first": now, "days": {}})
        if pw:
            e["pass"] = pw
        e.update({"last": now, "host": norm_domain(host) or "", "ip": ip})
        if stream:
            e["last_stream"] = now
            e["streams"] = e.get("streams", 0) + 1
        d = datetime.now(tz()).strftime("%Y-%m-%d")
        if info is None:  # die Anmelde-Antwort zählt nicht doppelt
            e["days"][d] = e["days"].get(d, 0) + 1
        e["days"] = dict(sorted(e["days"].items())[-14:])
        if info is not None:
            e["auth"] = bool(info.get("auth"))
            e["status"] = str(info.get("status") or "")
            try:
                e["exp"] = datetime.fromtimestamp(int(info.get("exp_date")), tz()).strftime("%Y-%m-%d") if info.get("exp_date") else ""
            except (TypeError, ValueError):
                pass
            e["checked"] = now
        if len(passthru) > 2000:  # Schutz vor Müll: die ältesten fallen raus
            for k in sorted(passthru, key=lambda k: passthru[k].get("last", 0))[:200]:
                passthru.pop(k, None)
    if time.time() - _pt["saved"] > 60:
        _pt["saved"] = time.time()
        try:
            save_json("passthru.json", passthru)
        except Exception as e:
            log.warning("passthru.json: %s", e)


user_log: list = load_json("user_log.json", [])


class UserConflict(Exception):
    pass


def uhash(u: dict) -> str:
    x = {k: v for k, v in u.items() if not k.startswith("_")}
    return hashlib.sha1(json.dumps(x, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


def merge_users(raw: list, clean: list, base: dict) -> list:
    """Speichern von mehreren Geräten aus (Handy + PC): Nur was dieses Gerät wirklich geändert hat, wird übernommen.
    Hat ein anderes Gerät denselben Kunden inzwischen geändert, gibt es einen Konflikt statt stillem Überschreiben."""
    cur = {u["username"]: u for u in users}
    out, origs = [], set()
    for x in raw:
        c = clean[x["_clean_idx"]]
        v, orig = x.get("_v"), x.get("_o") or c["username"]
        if not v:                      # neu auf diesem Gerät
            out.append(c)
            continue
        origs.add(orig)
        s = cur.get(orig)
        if uhash(c) == v:              # hier unverändert -> aktuellen Stand des Servers behalten
            if s is not None:
                out.append(s)
            continue
        if s is None:
            raise UserConflict(f"„{orig}“ wurde inzwischen auf einem anderen Gerät gelöscht.")
        if uhash(s) != v:
            raise UserConflict(f"„{orig}“ wurde inzwischen auf einem anderen Gerät geändert.")
        out.append(c)
    for name, v in base.items():       # hier gelöscht
        if name not in origs and name in cur and uhash(cur[name]) != v:
            raise UserConflict(f"„{name}“ wurde inzwischen auf einem anderen Gerät geändert – Löschen abgebrochen.")
    for name, s in cur.items():        # auf einem anderen Gerät neu angelegt -> behalten
        if name not in base and name not in origs and not any(o["username"] == name for o in out):
            out.append(s)
    return out


def ulog(name: str, text: str) -> None:
    with lock:
        user_log.insert(0, {"t": int(time.time()), "user": name, "text": text})
        del user_log[3000:]
        try:
            save_json("user_log.json", user_log)
        except Exception as e:
            log.warning("user_log.json: %s", e)


def user_diff(old: list, new: list) -> None:
    """Was sich an Benutzern geändert hat – für den Verlauf im Benutzer-Fenster."""
    o = {u["username"]: u for u in old}
    nn = {u["username"]: u for u in new}
    for name, u in nn.items():
        a = o.get(name)
        if not a:
            ulog(name, "Angelegt")
            continue
        ch = []
        if a.get("enabled", True) != u.get("enabled", True):
            ch.append("aktiviert" if u.get("enabled", True) else "deaktiviert")
        if (a.get("exp") or "") != (u.get("exp") or ""):
            ch.append(f"Ablauf {a.get('exp') or 'ohne'} → {u.get('exp') or 'ohne'}")
        if a.get("password") != u.get("password"):
            ch.append("Passwort geändert")
        if sorted(a.get("packages") or []) != sorted(u.get("packages") or []):
            ch.append("Pakete geändert")
        if (a.get("sources") or "AB") != (u.get("sources") or "AB"):
            ch.append(f"Nur {pname('A')}" if u.get("sources") == "A" else f"{pname('A')} + {pname('B')}")
        for pk in ("A", "B"):
            if (a.get(pk) or {}).get("user") != (u.get(pk) or {}).get("user"):
                ch.append(f"Line {'1' if pk == 'A' else '2'}: {(u.get(pk) or {}).get('user') or 'entfernt'}")
            elif (a.get(pk) or {}).get("domains") != (u.get(pk) or {}).get("domains"):
                ch.append(f"Domains {'1' if pk == 'A' else '2'} geändert")
        if (a.get("note") or "") != (u.get("note") or ""):
            ch.append("Notiz geändert")
        if ch:
            ulog(name, ", ".join(ch))
    for name in o:
        if name not in nn:
            ulog(name, "Gelöscht")


# ---------------------------------------------------------------- Papierkorb und Erinnerungen
trash: list = load_json("trash.json", [])          # gelöschte Kunden, 30 Tage wiederherstellbar
reminders: dict = load_json("reminders.json", {})  # Kunde -> Ablaufdatum, an das schon erinnert wurde


def trash_add(gone: list) -> None:
    now = int(time.time())
    for u in gone:
        trash.insert(0, {"t": now, "user": json.loads(json.dumps(u))})
    trash[:] = [x for x in trash if now - x["t"] < 30 * 86400][:500]
    save_json("trash.json", trash)


def trash_list() -> list:
    now = time.time()
    trash[:] = [x for x in trash if now - x["t"] < 30 * 86400]
    return [{"t": x["t"], "username": x["user"]["username"], "note": x["user"].get("note", ""), "exp": x["user"].get("exp", ""),
             "days_left": 30 - int((now - x["t"]) // 86400), "taken": any(u["username"] == x["user"]["username"] for u in users)}
            for x in trash]


def passthru_list() -> list:
    now = time.time()
    known = {u.get("username") for u in users}
    out = []
    for k, e in passthru.items():
        if e.get("user") in known or now - e.get("last", 0) > 30 * 86400:
            continue
        # Aufräumen: Was der Anbieter nie bestätigt hat, verschwindet von selbst – echte Kunden melden sich
        # spätestens beim nächsten App-Start an. Abgelehnte Anmeldungen (falsche Daten, Bots) nach 1 Tag,
        # nie bestätigte nach 3 Tagen.
        if e.get("auth") is False and now - e.get("last", 0) > 86400:
            continue
        if e.get("auth") is None and now - e.get("first", 0) > 3 * 86400:
            continue
        week = sum(n for d, n in e.get("days", {}).items()
                   if d >= (datetime.now(tz()) - timedelta(days=7)).strftime("%Y-%m-%d"))
        out.append({"key": k, "provider": e["provider"], "user": e["user"], "host": e.get("host", ""), "last": e.get("last", 0),
                    "first": e.get("first", 0), "week": week, "auth": e.get("auth"), "exp": e.get("exp", ""),
                    "status": e.get("status", ""), "has_pass": bool(e.get("pass"))})
    out.sort(key=lambda x: -x["last"])
    return out


def passthru_adopt(keys: list, packages=None, extra=None) -> dict:
    """Legt für durchgereichte Zugänge Benutzer an – mit denselben Login-Daten wie bisher und dieser Line beim Anbieter."""
    done, skipped = [], []
    with lock:
        names = {u.get("username") for u in users}
        for k in keys:
            e = passthru.get(k)
            if not e or not e.get("pass") or e["user"] in names:
                skipped.append(k)
                continue
            pk = e["provider"]
            own = [e["host"]] if e.get("host") and DOMAIN_RE.match(e["host"]) and e["host"] not in gen_domains(pk) else []
            u = {"username": e["user"], "password": e["pass"], "enabled": True, "note": "aus Durchreichen übernommen",
                 "max_connections": 1, "domains": own,
                 "A": {"user": "", "pass": "", "domains": []}, "B": {"user": "", "pass": "", "domains": []},
                 "sources": "AB" if pk == "B" else "A", "packages": [str(p) for p in packages or []], "exp": e.get("exp", ""),
                 "created": int(time.time())}
            u[pk] = {"user": e["user"], "pass": e["pass"], "domains": own}
            x = (extra or {}).get(k) or {}
            if x.get("phone"):
                u["phone"] = str(x["phone"]).strip()[:40]
            if x.get("b_user") and pk == "A":
                u["B"] = {"user": str(x["b_user"]).strip(), "pass": str(x.get("b_pass") or ""), "domains": []}
                u["sources"] = "AB"
            users.append(u)
            names.add(e["user"])
            done.append(e["user"])
            ulog(e["user"], f"Aus dem Durchreichen übernommen ({pname(pk)})")
        if done:
            save_json("users.json", users)
    resp_cache.clear()
    if done:
        write_domains_file()
    return {"adopted": done, "skipped": len(skipped)}


def find_user(name: str, pw: str, ip: str, host: str = ""):
    now = time.time()
    hist = [t for t in _fail.get(ip, []) if now - t < 600]
    _fail[ip] = hist
    if len(hist) >= 20:
        return "blocked"
    if config.get("fallback", True) and name and not any(u.get("username") == name for u in users):
        return "unknown"  # nicht bei uns angelegt -> wird wie früher an den Anbieter durchgereicht
    for u in users:
        if u.get("username") == name and hmac.compare_digest(str(u.get("password", "")), str(pw or "")):
            if not u.get("enabled", True):
                note_activity(name, host, ip, "deaktiviert")
                return None
            if not host_ok(u, host):
                note_activity(name, host, ip, "falsche Domain")
                return None
            exp = u.get("exp") or ""
            if exp:
                try:
                    if datetime.strptime(exp, "%Y-%m-%d").date() < datetime.now(tz()).date():
                        note_activity(name, host, ip, "abgelaufen")
                        return None
                except ValueError:
                    pass
            note_activity(name, host, ip)
            return u
    hist.append(now)
    if any(u.get("username") == name for u in users):
        note_activity(name, host, ip, "falsches Passwort")
    return None


def exp_ts(u: dict):
    exp = u.get("exp") or ""
    try:
        d = datetime.strptime(exp, "%Y-%m-%d").replace(hour=23, minute=59, tzinfo=tz())
        return str(int(d.timestamp()))
    except ValueError:
        return None


# ---------------------------------------------------------------- Details (bei Bedarf, 24 h Zwischenspeicher)
_detail_lock = threading.Lock()


def cached_detail(action: str, key: str, vid: str):
    safe = re.sub(r"[^0-9]", "", vid)
    if not safe:
        return {}
    fn = os.path.join(CACHE, f"{action}_{safe}.json")
    try:
        days = float((config.get("detail_days") or {}).get("series" if action == "get_series_info" else "vod", 1) or 1)
        if time.time() - os.path.getmtime(fn) < days * 86400:
            with open(fn, encoding="utf-8") as f:
                return json.load(f)
    except OSError:
        pass
    with _detail_lock:
        try:
            data = upstream_get("A", "player_api.php", {**sync_creds("A"), "action": action, key: safe}, timeout=60)
        except Exception as e:
            log.warning("%s %s fehlgeschlagen: %s", action, safe, e)
            try:
                with open(fn, encoding="utf-8") as f:  # lieber alte Daten als nichts
                    return json.load(f)
            except OSError:
                return {}
    tmp = fn + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(tmp, fn)
    return data


# ---------------------------------------------------------------- EPG für Clients
def b64(s: str) -> str:
    return base64.b64encode((s or "").encode("utf-8")).decode("ascii")


def epg_for_stream(vid: int, limit: int, full: bool):
    ch = V().get("epg_index", {}).get(vid, "")
    if not ch:
        return []
    now = int(time.time())
    con = epg_conn()
    if full:
        rows = con.execute("SELECT start, stop, title, descr FROM prog WHERE channel=? AND stop>=? ORDER BY start",
                           (ch, now - 6 * 3600)).fetchall()
    else:
        rows = con.execute("SELECT start, stop, title, descr FROM prog WHERE channel=? AND stop>=? ORDER BY start"
                           " LIMIT ?", (ch, now, max(1, limit))).fetchall()
    con.close()
    out = []
    z = tz()
    for i, (st, sp, title, desc) in enumerate(rows):
        out.append({
            "id": str(st), "epg_id": "0", "title": b64(title), "lang": "", "description": b64(desc),
            "start": datetime.fromtimestamp(st, z).strftime("%Y-%m-%d %H:%M:%S"),
            "end": datetime.fromtimestamp(sp, z).strftime("%Y-%m-%d %H:%M:%S"),
            "channel_id": ch, "start_timestamp": str(st), "stop_timestamp": str(sp),
            "now_playing": 1 if st <= now < sp else 0, "has_archive": 0,
        })
    return out


def xmltv_for(pset: tuple, pkgs: tuple = ()):
    """Programm als XMLTV -> (Cache-Schlüssel, Inhalt). Eine Stunde lang gilt derselbe Stand; gebaut wird nur einmal,
    auch wenn mehrere Apps gleichzeitig laden."""
    hour = int(time.time() // 3600)
    key = ("xmltv", pset, pkgs, hour)
    for k in [k for k in list(resp_cache) if isinstance(k, tuple) and k[:3] == ("xmltv", pset, pkgs) and k[3] != hour]:
        resp_cache.pop_quiet(k)  # alte Stunde weg – zählt nicht als neuer Stand
    return key, cache_once(key, lambda: _build_xmltv(pset, pkgs))


def _xml_esc(s) -> str:
    if not s:
        return ""
    if "&" in s or "<" in s or ">" in s or '"' in s:
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    return s


def _build_xmltv(pset: tuple, pkgs: tuple) -> bytes:
    chans = {}
    for c in visible_cats("live", pset, pkgs):
        for it in V()["live"]["items"].get(c["vid"], []):
            ch = it.get("epg_channel_id")
            if ch and ch not in chans:
                chans[ch] = it.get("name", ch)
    parts = ['<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="onyx-merge">\n']
    esc = _xml_esc
    for ch, name in chans.items():
        parts.append(f'<channel id="{esc(ch)}"><display-name>{esc(name)}</display-name></channel>\n')
    con = epg_conn()
    rows: dict = {}
    for ch, st, sp, title, desc in con.execute("SELECT channel, start, stop, title, descr FROM prog ORDER BY channel, start"):
        if ch in chans:
            rows.setdefault(ch, []).append((st, sp, title, desc))
    con.close()
    tcache: dict = {}

    def fmt(t):
        v = tcache.get(t)
        if v is None:
            v = tcache[t] = time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(t))
        return v
    for ch in chans:
        ech = esc(ch)
        for st, sp, title, desc in rows.get(ch, ()):
            parts.append(f'<programme start="{fmt(st)}" stop="{fmt(sp)}" channel="{ech}"><title>{esc(title)}</title>'
                         f'<desc>{esc(desc)}</desc></programme>\n')
    parts.append("</tv>\n")
    return "".join(parts).encode("utf-8")


# ---------------------------------------------------------------- Eigene Logos
LOGO_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif", ".svg": "image/svg+xml"}


def sniff_image(b: bytes):
    if b[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if b[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return ".webp"
    if b[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    return None


def serve_logo(handler, name: str):
    name = name.split("?")[0]
    if not re.fullmatch(r"[a-z0-9_-]+\.(png|jpg|webp|gif)", name):
        handler.send_response(404)
        handler.send_header("Content-Length", "0")
        return handler.end_headers()
    fn = os.path.join(LOGO_DIR, name)
    try:
        with open(fn, "rb") as f:
            body = f.read()
    except OSError:
        handler.send_response(404)
        handler.send_header("Content-Length", "0")
        return handler.end_headers()
    handler.send_response(200)
    handler.send_header("Content-Type", LOGO_TYPES["." + name.rsplit(".", 1)[1]])
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "public, max-age=86400")
    handler.end_headers()
    if handler.command != "HEAD":
        handler.wfile.write(body)


# ---------------------------------------------------------------- HTTP für Player
class ClientHandler(BaseHTTPRequestHandler):
    server_version = "nginx"
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = 60  # M7: 60 s Zeitgrenze für Apps

    def log_message(self, fmt, *args):
        pass

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except (BrokenPipeError, ConnectionResetError, TimeoutError, socket.timeout, ConnectionAbortedError):
            self.close_connection = True

    def client_ip(self) -> str:
        return (self.headers.get("X-Real-IP") or self.client_address[0]).strip()

    def send_body(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8", cacheable=False):
        gz = "gzip" in (self.headers.get("Accept-Encoding") or "") and len(body) > 1024
        if gz:
            body = gzip.compress(body, 5)
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        if gz:
            self.send_header("Content-Encoding", "gzip")
        self.send_header("Cache-Control", "private, max-age=300" if cacheable else "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_cached(self, key, body: bytes, ctype: str = "application/json; charset=utf-8"):
        """Fertige Liste – komprimiert wird nur einmal pro Stand, nicht bei jedem Abruf."""
        if "gzip" not in (self.headers.get("Accept-Encoding") or "") or len(body) <= 1024:
            return self.send_body(200, body, ctype, cacheable=True)
        gz = cached_gz(key, body)
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(gz)))
        self.send_header("Content-Encoding", "gzip")
        self.send_header("Cache-Control", "private, max-age=300")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(gz)

    def send_json(self, obj, code=200):
        self.send_body(code, json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))

    def redirect(self, url: str, code: int = 302):
        self.send_response(code)
        self.send_header("Location", url)
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def params(self) -> dict:
        u = urllib.parse.urlsplit(self.path)
        q = dict(urllib.parse.parse_qsl(u.query, keep_blank_values=True))
        if self.command == "POST":
            body = self.body()
            if body and len(body) < 65536:
                q.update(dict(urllib.parse.parse_qsl(body.decode("utf-8", "replace"))))
        return q

    def body(self) -> bytes:
        if not hasattr(self, "_body"):
            n = int(self.headers.get("Content-Length") or 0)
            self._body = self.rfile.read(n) if 0 < n <= 1 << 20 else b""
        return self._body

    def do_HEAD(self):
        _tl.draft = False
        self.do_GET()

    def do_POST(self):
        _tl.draft = False
        self.do_GET()

    def do_GET(self):
        _tl.draft = False
        t0 = time.perf_counter()
        ep = "other"
        try:
            ep = classify_endpoint(self.path)
            self.route()
            dt_ms = (time.perf_counter() - t0) * 1000
            p = self.path
            if "player_api.php" in p or "get.php" in p or "xmltv.php" in p:
                health["resp"].append((int(time.time()), dt_ms))
            record_endpoint_latency(ep, dt_ms, self.path)
        except (BrokenPipeError, ConnectionResetError, socket.timeout, TimeoutError, ConnectionAbortedError):
            pass
        except Exception as e:
            track_error("client", f"{self.path.split('?')[0]}: {e}", exc=e)
            log.exception("Fehler bei %s: %s", self.path.split("?")[0], e)
            try:
                self.send_json({"error": "server"}, 500)
            except Exception:
                pass

    def auth(self, name, pw):
        _cur_ua[threading.get_ident()] = self.headers.get("User-Agent") or ""
        u = find_user(urllib.parse.unquote(name or ""), urllib.parse.unquote(pw or ""), self.client_ip(),
                      self.headers.get("Host") or "")
        if u == "blocked":
            self.send_json({"user_info": {"auth": 0}}, 429)
            return None
        if u == "unknown":
            self.passthrough()
            return None
        if not u:
            self.send_json({"user_info": {"auth": 0}}, 200 if self.path.startswith("/player_api") else 403)
            return None
        return u

    def route(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == "/onyx-merge-ping":  # Erreichbarkeits-Test der Domains – beantwortet Onyx Merge selbst
            body = json.dumps({"onyx": "merge", "id": config.get("instance_id"),
                               "host": norm_domain(self.headers.get("Host") or ""),
                               "port": self.headers.get("X-Forwarded-Port") or ""}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)
            return
        if path in ("/player_api.php", "/panel_api.php"):
            return self.player_api()
        if path == "/xmltv.php":
            q = self.params()
            u = self.auth(q.get("username"), q.get("password"))
            if u:
                key, body = xmltv_for(user_providers(u), user_packages(u))
                self.send_cached(key, body, "application/xml; charset=utf-8")
            return
        if path == "/get.php":
            return self.m3u()
        if path.startswith("/logos/"):
            return serve_logo(self, path[7:])
        if path.startswith("/ui/") and re.fullmatch(r"/ui/(logo\.webp|favicon\.png|urbanist\.woff2|epilogue\.woff2)", path):
            types = {".woff2": "font/woff2", ".webp": "image/webp", ".png": "image/png"}
            with open(os.path.join(HOME, "ui", path[4:]), "rb") as f:
                return self.send_body(200, f.read(), types[os.path.splitext(path)[1]], cacheable=True)
        if path.startswith("/test/"):
            return self.speedtest(path)
        if path.startswith("/me/"):
            return self.me_page(path)
        if path == "/streaming/timeshift.php":
            q = self.params()
            u = self.auth(q.get("username"), q.get("password"))
            if u:
                self.play(u, "timeshift", q.get("stream", ""), "ts", q.get("duration", ""), q.get("start", ""))
            return
        parts = [p for p in path.split("/") if p]
        if len(parts) == 4 and parts[0] in ("live", "movie", "series"):
            u = self.auth(parts[1], parts[2])
            if u:
                sid, _, ext = parts[3].partition(".")
                self.play(u, parts[0], sid, ext or "ts")
            return
        if len(parts) == 6 and parts[0] == "timeshift":
            u = self.auth(parts[1], parts[2])
            if u:
                sid, _, ext = parts[5].partition(".")
                self.play(u, "timeshift", sid, ext or "ts", parts[3], parts[4])
            return
        if len(parts) == 3:  # Kurzform /user/pass/id
            u = self.auth(parts[0], parts[1])
            if u:
                sid, _, ext = parts[2].partition(".")
                self.play(u, "live", sid, ext or "ts")
            return
        if config.get("fallback", True):
            return self.passthrough()
        self.send_body(404, b"", "text/plain")

    def passthrough(self):
        """Wie der alte Nginx: Zugänge, die nicht in Onyx Merge angelegt sind, gehen unverändert zum Anbieter 1.
        Streams per Weiterleitung (302), alles andere wird durchgereicht."""
        import http.client
        pkey = domain_provider(self.headers.get("Host") or "")
        base = urllib.parse.urlsplit(provider_url(pkey))
        path = self.path
        first = urllib.parse.urlsplit(path).path.split("/")[1:2]
        if first and first[0] in ("live", "movie", "series", "timeshift", "hls", "hlsr") or \
                len([x for x in urllib.parse.urlsplit(path).path.split("/") if x]) == 3:
            # Auch Umschalten merken (nur lokal, keine Anfrage an den Anbieter) – sonst tauchen
            # Kunden, die die App vor der Umstellung geöffnet haben, erst beim nächsten Start auf.
            parts = [x for x in urllib.parse.urlsplit(path).path.split("/") if x]
            if len(parts) == 3:
                parts = ["live"] + parts
            if (len(parts) == 4 and parts[0] in ("live", "movie", "series") and re.fullmatch(r"\d+(\.[A-Za-z0-9]{1,5})?", parts[3])) or \
                    (len(parts) == 6 and parts[0] == "timeshift"):
                try:
                    pt_note(pkey, urllib.parse.unquote(parts[1]), urllib.parse.unquote(parts[2]),
                            self.headers.get("Host") or "", self.client_ip(), stream=True)
                except Exception as e:
                    log.warning("Durchreichen merken: %s", e)
            return self.redirect(f"{base.scheme}://{base.netloc}{path}")
        direct = f"{base.scheme}://{base.netloc}{path}"
        sp = urllib.parse.urlsplit(path)
        qd = dict(urllib.parse.parse_qsl(sp.query))
        body = self.body() or None
        if body and not qd.get("username"):
            try:
                qd.update(dict(urllib.parse.parse_qsl(body.decode("utf-8", "replace"))))
            except Exception:
                pass
        login_call = sp.path.endswith("player_api.php") and not qd.get("action")
        try:
            pt_note(pkey, qd.get("username", ""), qd.get("password", ""), self.headers.get("Host") or "", self.client_ip())
        except Exception as e:
            log.warning("Durchreichen merken: %s", e)
        if not guard_allow(pkey, "pass", "Weiterreichen"):
            # Wächter: VPS fragt nicht selbst – das Gerät des Kunden holt es direkt beim Anbieter
            guard_count_redirect(pkey)
            return self.redirect(direct, 307 if self.command == "POST" else 302)
        port = base.port or 80
        hdrs = {k: v for k, v in self.headers.items() if k.lower() in (
            "user-agent", "accept", "accept-encoding", "content-type", "range", "accept-language")}
        hdrs["Host"] = base.hostname
        ip = self.client_ip()
        hdrs["X-Real-IP"] = ip
        hdrs["X-Forwarded-For"] = ip
        try:
            conn = http.client.HTTPConnection(base.hostname, port, timeout=60, source_address=bind_src(pkey))
            conn.request(self.command if self.command in ("GET", "POST", "HEAD") else "GET", path, body=body, headers=hdrs)
            r = conn.getresponse()
        except Exception as e:
            log.warning("Durchreichen fehlgeschlagen: %s", e)
            guard_report(pkey, "Weiterreichen", None, type(e).__name__, scope="pass")
            guard_count_redirect(pkey)
            return self.redirect(direct, 307 if self.command == "POST" else 302)
        if r.status in HARD_SIGNS or r.status in SOFT_SIGNS:
            guard_report(pkey, "Weiterreichen", r.status, scope="pass")
        elif r.status == 200:
            ip_mark(pkey, True)
        pre = None
        if login_call and r.status == 200 and int(r.getheader("Content-Length") or 0) < 65536:
            pre = r.read(65536)  # Anmeldung: kleine Antwort – merken, ob der Zugang gültig ist
            try:
                raw = gzip.decompress(pre) if pre[:2] == b"\x1f\x8b" else pre
                pt_note(pkey, qd.get("username", ""), qd.get("password", ""), self.headers.get("Host") or "",
                        self.client_ip(), (json.loads(raw.decode("utf-8", "replace")) or {}).get("user_info") or {})
            except Exception:
                pass
        self.send_response(r.status)
        for k, v in r.getheaders():
            if k.lower() in ("content-type", "content-length", "content-encoding", "location", "cache-control",
                             "content-range", "accept-ranges", "content-disposition"):
                self.send_header(k, v)
        if not r.getheader("Content-Length"):
            self.send_header("Connection", "close")
            self.close_connection = True
        self.end_headers()
        if pre is not None and self.command != "HEAD":
            self.wfile.write(pre)
        elif self.command != "HEAD":
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
        conn.close()

    def me_page(self, path: str):
        """„Mein Zugang“: eine Seite pro Kunde – Gültigkeit, Einrichtung in der App, Verbindungstest. Ohne Passwort."""
        u = user_by_token(path.split("/")[2] if len(path.split("/")) > 2 else "")
        if not u:
            return self.send_body(404, b"Unbekannter Link", "text/plain; charset=utf-8")
        host = (self.headers.get("Host") or "").split(":")[0]
        doms = (u.get("domains") or []) + [d for pk in user_providers(u) for d in gen_domains(pk)]
        server = host if host in doms else (doms[0] if doms else host)
        days = None
        try:
            days = (datetime.strptime(u.get("exp") or "", "%Y-%m-%d").date() - datetime.now(tz()).date()).days
        except ValueError:
            pass
        a = activity.get(u["username"]) or {}
        info = {"user": u["username"], "server": f"http://{server}", "exp": u.get("exp") or "", "days": days,
                "enabled": u.get("enabled", True), "has_line": bool(user_providers(u)), "last": a.get("t", 0),
                "test": f"/test/{speed_token(u['username'])}", "contact": str(config.get("support_contact") or "")}
        with open(ME_HTML, "rb") as f:
            page = f.read().replace(b"__INFO__", json.dumps(info, ensure_ascii=False).replace("<", "\\u003c").encode("utf-8"))
        return self.send_body(200, page, "text/html; charset=utf-8")

    def speedtest(self, path: str):
        """Geschwindigkeitstest: misst die Strecke Gerät -> dein VPS. Kein Anbieter ist beteiligt."""
        parts = path.split("/")  # ["", "test", token, (ping|data|result)]
        u = user_by_token(parts[2] if len(parts) > 2 else "")
        if not u:
            return self.send_body(404, b"Unbekannter Test-Link", "text/plain; charset=utf-8")
        sub = parts[3] if len(parts) > 3 else ""
        if sub == "":
            with open(SPEEDTEST_HTML, "rb") as f:
                return self.send_body(200, f.read().replace(b"{{USER}}", u["username"].encode()), "text/html; charset=utf-8")
        if sub == "ping":
            return self.send_body(200, b"ok", "text/plain")
        if sub == "data":
            now = time.time()
            hist = [t for t in _speed_rate.get(u["username"], []) if now - t < 3600]
            if len(hist) >= 40:
                return self.send_body(429, b"Zu viele Tests - bitte spaeter", "text/plain")
            _speed_rate[u["username"]] = hist + [now]
            mb = min(16, max(1, int(dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(self.path).query)).get("mb") or 8)))
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(mb << 20))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                for _ in range(mb):
                    self.wfile.write(_RAND)
            except (BrokenPipeError, ConnectionResetError):
                pass
            return
        if sub == "result" and self.command == "POST":
            try:
                d = json.loads(self.body() or b"{}")
                down, ping, jit = float(d.get("down", 0)), float(d.get("ping", 0)), float(d.get("jitter", 0))
            except (ValueError, TypeError):
                return self.send_json({"ok": False}, 400)
            if 0 < down < 100000 and 0 <= ping < 100000:
                diag_exec("INSERT INTO speed VALUES(?,?,?,?,?,?,?)", (int(time.time()), u["username"], round(down, 1),
                                                                     round(ping, 1), round(jit, 1), self.client_ip(),
                                                                     (self.headers.get("User-Agent") or "")[:300]))
                isp_of(self.client_ip())
            return self.send_json({"ok": True})
        return self.send_body(404, b"", "text/plain")

    def play(self, u, kind, sid, ext, duration="", start=""):
        try:
            vid = int(sid)
        except ValueError:
            return self.send_body(404, b"", "text/plain")
        if kind in ("live", "timeshift"):
            vid = dyn_real(vid)  # Eintrag aus einer Live-Kategorie -> echter Sender
            if vid is None:
                return self.send_body(404, b"", "text/plain")
        if kind != "timeshift":
            count_play(u["username"], "live" if kind == "live" else ("vod" if kind == "movie" else "series"), vid)
        pkey, orig = split_vid("live" if kind in ("live", "timeshift") else kind, vid)
        acc = u.get(pkey) or {}
        if not acc.get("user") or (kind in ("movie", "series") and pkey != "A"):
            return self.send_body(404, b"", "text/plain")
        if kind != "timeshift":
            log_start(u, kind, vid, pkey, self.client_ip(), self.headers.get("User-Agent") or "", self.headers.get("Host") or "")
        ext = re.sub(r"[^A-Za-z0-9]", "", ext)[:5] or "ts"
        qu, qp = urllib.parse.quote(acc["user"], safe=""), urllib.parse.quote(acc.get("pass", ""), safe="")
        base = provider_url(pkey)
        if kind == "timeshift":
            d = re.sub(r"[^0-9]", "", str(duration))
            s = re.sub(r"[^0-9:\-_ ]", "", str(start))
            return self.redirect(f"{base}/timeshift/{qu}/{qp}/{d}/{s}/{orig}.{ext}")
        self.redirect(f"{base}/{kind}/{qu}/{qp}/{orig}.{ext}")

    def player_api(self):
        q = self.params()
        u = self.auth(q.get("username"), q.get("password"))
        if not u:
            return
        action = q.get("action", "")
        pset = user_providers(u)
        if not action:
            now = datetime.now(tz())
            host = public_base(self.headers.get("Host") or "").split("://", 1)[1]
            return self.send_json({
                "user_info": {
                    "username": u["username"], "password": u.get("password", ""), "message": "", "auth": 1,
                    "status": "Active", "exp_date": exp_ts(u), "is_trial": "0", "active_cons": "0",
                    "created_at": str(int(u.get("created", time.time()))),
                    "max_connections": str(u.get("max_connections") or 1),
                    "allowed_output_formats": ["m3u8", "ts"]},
                "server_info": {
                    "url": host, "port": "80", "https_port": "443", "server_protocol": "http", "rtmp_port": "0",
                    "timezone": config.get("timezone", "Europe/Berlin"), "timestamp_now": int(now.timestamp()),
                    "time_now": now.strftime("%Y-%m-%d %H:%M:%S"), "process": True}})
        kinds = {"get_live_categories": ("live", "cats"), "get_vod_categories": ("vod", "cats"),
                 "get_series_categories": ("series", "cats"), "get_live_streams": ("live", "items"),
                 "get_vod_streams": ("vod", "items"), "get_series": ("series", "items")}
        if action in kinds:
            kind, what = kinds[action]
            cat = q.get("category_id") or None
            pkgs = user_packages(u)
            host = (self.headers.get("Host") or "").split(":")[0]
            key, body = list_for((kind, what, pset, pkgs, cat, host))
            return self.send_cached(key, body)
        if action in ("get_series_info", "get_vod_info"):
            if "A" not in pset:
                return self.send_json({})
            key = "series_id" if action == "get_series_info" else "vod_id"
            return self.send_json(cached_detail(action, key, q.get(key, "")))
        if action in ("get_short_epg", "get_simple_data_table"):
            try:
                vid = dyn_real(int(q.get("stream_id", "")))
            except ValueError:
                vid = None
            if vid is None:
                return self.send_json({"epg_listings": []})
            pkey, _ = split_vid("live", vid)
            if pkey not in pset:
                return self.send_json({"epg_listings": []})
            full = action == "get_simple_data_table"
            return self.send_json({"epg_listings": epg_for_stream(vid, int(q.get("limit") or 4), full)})
        return self.send_json([])

    def m3u(self):
        q = self.params()
        u = self.auth(q.get("username"), q.get("password"))
        if not u:
            return
        pset = user_providers(u)
        host = self.headers.get("Host") or config.get("public_host") or "localhost"
        ext = "m3u8" if q.get("output") in ("m3u8", "hls") else "ts"
        qu, qp = urllib.parse.quote(u["username"], safe=""), urllib.parse.quote(u.get("password", ""), safe="")
        esc = lambda s: (s or "").replace('"', "'").replace("\n", " ")
        lines = ["#EXTM3U"]
        pkgs = user_packages(u)
        names = {c["vid"]: c["name"] for c in visible_cats("live", pset, pkgs)}
        names.update({c["vid"]: c["name"] for c in live_state["cats"]})
        for it in list_items("live", pset, None, pkgs, host.split(":")[0]):
            lines.append(f'#EXTINF:-1 tvg-id="{esc(it.get("epg_channel_id"))}" tvg-name="{esc(it.get("name"))}" '
                         f'tvg-logo="{esc(it.get("stream_icon"))}" group-title="{esc(names.get(it["category_id"]))}",'
                         f'{esc(it.get("name"))}')
            lines.append(f"http://{host}/live/{qu}/{qp}/{it['stream_id']}.{ext}")
        if "A" in pset:
            vnames = {c["vid"]: c["name"] for c in visible_cats("vod", pset, pkgs)}
            for it in list_items("vod", pset, None, pkgs, host.split(":")[0]):
                lines.append(f'#EXTINF:-1 tvg-name="{esc(it.get("name"))}" tvg-logo="{esc(it.get("stream_icon"))}" '
                             f'group-title="{esc(vnames.get(it["category_id"]))}",{esc(it.get("name"))}')
                lines.append(f"http://{host}/movie/{qu}/{qp}/{it['stream_id']}.{it.get('container_extension') or 'mp4'}")
        self.send_body(200, ("\n".join(lines) + "\n").encode("utf-8"), "audio/x-mpegurl; charset=utf-8")


# ---------------------------------------------------------------- Synchronisation (nachts + per Knopf)
sync_state = {"running": False}
_sync_lock = threading.Lock()


def run_sync(which=None, force: bool = False) -> None:
    if not _sync_lock.acquire(blocking=False):  # läuft schon – nie zwei Abgleiche gleichzeitig
        return
    sync_state["running"] = True
    try:
        keys = [which] if which else [k for k in ("A", "B") if k in config["providers"]]
        for i, pkey in enumerate(keys):
            if i:
                time.sleep(int(config.get("sync_pause", 20)) * 3)
            st = status.setdefault(pkey, {})
            if not config["providers"][pkey].get("sync_user"):
                st["last_error"] = "Kein Sync-Zugang eingetragen"
                continue
            st["running_since"] = int(time.time())
            try:
                st["counts"] = sync_provider(pkey, force)
                st["last_ok"] = int(time.time())
                st["last_error"] = ""
                was_dirty = draft_dirty()
                build_view()
                if not was_dirty:
                    publish("Abgleich")      # niemand bearbeitet gerade – neuer Katalog gleich für alle
                else:
                    draft_state["catalog_pending"] = True  # wartet, bis du deinen Entwurf speicherst
            except Exception as e:
                st["last_error"] = f"Katalog: {e}"
                log.error("Sync %s: %s", pkey, e)
                notify("sync", f"❌ Abgleich bei {config['providers'][pkey].get('name') or pkey} fehlgeschlagen: {e}", key=f"sync-{pkey}")
            if config["providers"][pkey].get("epg", True) and not st.get("last_error") and \
                    (config.get("epg_ext") or {}).get("mode") != "only":
                time.sleep(int(config.get("sync_pause", 20)))
                try:
                    st["epg_rows"] = sync_epg(pkey)
                    st["epg_ok"] = int(time.time())
                    resp_cache.clear()
                    compute_livecats()
                except Exception as e:
                    st["last_error"] = f"EPG: {e}"
                    log.error("EPG %s: %s", pkey, e)
                    notify("sync", f"❌ Programm (EPG) bei {config['providers'][pkey].get('name') or pkey} konnte nicht geladen werden: {e}", key=f"epg-{pkey}")
            st.pop("running_since", None)
            st["requests_total"] = upstream_count.get(pkey, 0)
            save_json("status.json", status)
        if not which and (config.get("epg_ext") or {}).get("mode") in ("fill", "only") and (config.get("epg_ext") or {}).get("url"):
            run_epg_ext()
    finally:
        sync_state["running"] = False
        _sync_lock.release()


def run_epg_ext() -> None:
    try:
        sync_epg_ext()
        build_view()
        compute_livecats()
    except Exception as e:
        epg_ext_state["error"] = str(e)
        epg_ext_state["failed"] = int(time.time())
        save_json("epg_ext.json", epg_ext_state)
        log.error("Fremdes EPG: %s", e)


def scheduler() -> None:
    jitter = random.randint(0, 900)
    last_day = None
    last_weekly = None
    while True:
        try:
            hh, mm = (config.get("sync_time") or "04:17").split(":")
            now = datetime.now(tz())
            target = now.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0) + timedelta(seconds=jitter)
            if now >= target and last_day != now.date() and now - target < timedelta(hours=2):
                last_day = now.date()
                log.info("Nächtliche Synchronisation startet")
                run_sync()
                jitter = random.randint(0, 900)
            # I10: Jeden Sonntag um 10:00 Uhr Wochenbericht per Telegram
            if now.weekday() == 6 and now.hour == 10 and last_weekly != now.date():
                last_weekly = now.date()
                if notify_cfg().get("enabled"):
                    try:
                        tg_send(build_weekly_report())
                    except Exception as e:
                        log.warning("Wochenbericht Telegram: %s", e)
        except Exception as e:
            log.error("Zeitplan: %s", e)
        time.sleep(60)


# ---------------------------------------------------------------- Werkzeuge: Namens-Analyse, Varianten, Länder
COUNTRY_CODES = {"DE", "AT", "CH", "TR", "UK", "GB", "US", "USA", "FR", "IT", "ES", "PT", "NL", "BE", "PL", "RU", "UA", "RO", "BG",
                 "GR", "AL", "ALB", "KU", "KURD", "AR", "ARAB", "IR", "IN", "PK", "CZ", "SK", "HU", "HR", "RS", "BA", "SI", "MK",
                 "SE", "NO", "DK", "FI", "IE", "CA", "AU", "BR", "MX", "LAT", "AFR", "EXYU", "EX-YU", "AZ", "GE", "AM", "IL", "SY", "IQ", "LB",
                 "MA", "TN", "DZ", "EG", "AF", "BD", "LK", "CN", "JP", "KR", "TH", "VN", "PH", "ID", "MY", "SR", "CY", "LU", "LT", "LV", "EE"}
COUNTRY_WORDS = ((r"deutschland|germany|almanya|german\b|deutsch\b", "DE"), (r"t[üu]rk[iı]ye|turkey|t[üu]rk\b|turkish|türkçe", "TR"),
                 (r"[öo]sterreich|austria", "AT"), (r"schweiz|switzerland|suisse", "CH"), (r"united kingdom|\bengland\b|british", "UK"),
                 (r"france|french|fran[cç]ais", "FR"), (r"ital(y|ia|ian)", "IT"), (r"espa[ñn]a|spain|spanish", "ES"),
                 (r"nederland|netherlands|dutch", "NL"), (r"polska|poland|polish", "PL"), (r"arab", "ARAB"), (r"kurd", "KURD"),
                 (r"albania|shqip", "ALB"), (r"\busa\b|united states|america", "US"), (r"portugal", "PT"), (r"russia", "RU"))
QUALITY_ORDER = ("4K", "FHD", "HD", "SD")
_CC = "|".join(sorted((re.escape(c) for c in COUNTRY_CODES), key=len, reverse=True))
RX_CC_PREFIX = re.compile(r"^\s*[\[\(|┃▎]?\s*(" + _CC + r")\s*(?:[\]\)|┃▎:»\-–]+|\s(?=\S))\s*", re.I)
RX_CC_SUFFIX = re.compile(r"\s*[\[\(|]?\s*\b(" + _CC + r")\b\s*[\]\)|]?\s*$")
SUP = {"⁸ᴷ": " 8K", "ᵁᴴᴰ⁺": " 4K", "ᴴᴰ⁺": " HD+", "ᴴᴰ": " HD", "ᶠᴴᴰ": " FHD", "ᵁᴴᴰ": " 4K", "⁴ᴷ": " 4K", "ᴿᴬᵂ": " RAW", "ᴴᴱⱽᶜ": " HEVC", "ˢᴰ": " SD"}
RX_Q = re.compile(r"(?<![A-Za-z0-9])(8K|4320P?|4K|UHD|3840P?|2160P?|FHD|FULL ?HD|1080[PI]?|HD\+?|720P|SD|576[PI]?|480P)(?![A-Za-z0-9])", re.I)
RX_FLAGS = {"hevc": re.compile(r"(?<![A-Za-z0-9])(HEVC|H\.?265|X265)(?![A-Za-z0-9])", re.I),
            "raw": re.compile(r"(?<![A-Za-z0-9])RAW(?![A-Za-z0-9])", re.I),
            "fps": re.compile(r"(?<![A-Za-z0-9])(50|60) ?FPS(?![A-Za-z0-9])", re.I),
            "backup": re.compile(r"(?<![A-Za-z0-9])(BACKUP|BACK ?UP|RESERVE|ALT|BK|B\d|MULTI ?AUDIO)(?![A-Za-z0-9])|\(\s*2\s*\)\s*$", re.I)}
RX_DECO = r"[◉●○★☆✪✦✧⭐▶►▷◀◆◇■□▪▫♦♢❖✿❀⚽🔴🟢🔵🟡⚪⚫🔥💎✅❌⚡™®©•·]+"
RX_SYMBOLS = re.compile(RX_DECO[:-2] + r"┃▎|]+")


SUP_ORDER = sorted(SUP, key=len, reverse=True)  # „ᶠᴴᴰ“ vor „ᴴᴰ“ ersetzen


RX_BALL_O = re.compile(r"(?<=[A-Za-z])[⚽⚾🏀🏐🎾⚪●○◯⭕][\ufe0e\ufe0f\u200d]*(?=[A-Za-z])")  # „SP⚽RTS“ -> „SPORTS“ (auch mit Emoji-Zusatzzeichen)
RX_TAG_PREFIX = re.compile(r"^\s*(?:[A-Z]{2,6}\s*[:|]\s*)+")           # „GOLD: “, „VIP| “ am Anfang


# Kapitälchen („ʜᴅ“) sehen aus wie normale Buchstaben, sind aber andere Zeichen – für Erkennung und Anzeige umwandeln
SMALLCAPS = str.maketrans("ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡʏᴢ", "ABCDEFGHIJKLMNOPQRSTUVWYZ")
# Einzelne hochgestellte Zeichen, die nicht in SUP als Ganzes stehen
SUPCHARS = str.maketrans("ᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁⱽᵂᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻ⁰¹²³⁴⁵⁶⁷⁸⁹⁺",
                         "ABDEGHIJKLMNOPRTUVWabcdefghijklmnoprstuvwxyz0123456789+")


def fix_ball(s: str) -> str:
    return RX_BALL_O.sub("O", s or "").translate(SMALLCAPS)


RX_VIP_CLEAN = re.compile(r"(?<![A-Za-z0-9])(?:VIP|PREMIUM|ᴠɪᴘ|PLATINUM|GOLD|SERVER\s*\d+)(?![A-Za-z0-9])", re.I)
RX_FPS_CLEAN = re.compile(r"(?<![A-Za-z0-9])(?:50|60)\s*FPS(?![A-Za-z0-9])", re.I)
RX_CODEC_CLEAN = re.compile(r"(?<![A-Za-z0-9])(?:HEVC|H\.?265|X265|RAW|MULTI[- ]?AUDIO|HDR10\+?|HDR|DOLBY\s*VISION|DV)(?![A-Za-z0-9])", re.I)
RX_QUALITY_BRACKETS_CLEAN = re.compile(r"\s*[\[\(]\s*(?:8K|4K|UHD|FHD|FULL\s*HD|1080[PI]?|HD\+?|720P|SD|576[PI]?|480P|HEVC|H\.?265|50\s*FPS|60\s*FPS|RAW)\s*[\]\)]", re.I)
RX_CC_PREFIX_EXPANDED = re.compile(r"^\s*[\[\(|┃▎]?\s*(" + _CC + r")\s*(?:[\]\)|┃▎:»\-–_]+|\s(?=\S))\s*", re.I)


def find_logo_matches_in_view(kind: str = "live", cat: str = "", vids_set=None, min_len: int = 2):
    """Findet für Einträge ohne Logo passende Spender aus dem gesamten Katalog.
    100% lokal im RAM: keine einzige Anfrage an einen Anbieter, null Belastung oder Sperrgefahr."""
    all_items = [it for lst in view.get(kind, {}).get("items", {}).values() for it in lst]
    
    donors = {}
    for it in all_items:
        icon = it.get("_icon") or it.get("stream_icon") or it.get("cover") or ""
        if icon and str(icon).strip():
            raw_name = it.get("name") or it.get("_orig") or ""
            key = clean_base_name(raw_name)
            if len(key) >= min_len:
                is_custom = bool(it.get("_icon"))
                if key not in donors or (is_custom and not donors[key].get("is_custom")):
                    donors[key] = {
                        "icon": str(icon).strip(),
                        "donor_name": raw_name,
                        "donor_vid": it.get("vid") or it.get("stream_id"),
                        "is_custom": is_custom
                    }

    scope_items = list(view.get(kind, {}).get("items", {}).get(cat, [])) if cat else all_items
    matches = []
    for it in scope_items:
        vid = it.get("vid") or it.get("series_id" if kind == "series" else "stream_id")
        if vids_set is not None and vid not in vids_set:
            continue
        icon = it.get("_icon") or it.get("stream_icon") or it.get("cover") or ""
        if not icon or not str(icon).strip():
            raw_name = it.get("name") or it.get("_orig") or ""
            key = clean_base_name(raw_name)
            if key in donors:
                d = donors[key]
                matches.append({
                    "vid": vid,
                    "name": raw_name,
                    "key": key,
                    "logo": d["icon"],
                    "donor_name": d["donor_name"],
                    "donor_vid": d["donor_vid"]
                })
    return matches, donors


def clean_base_name(name: str) -> str:
    """Basis-Name für saubere Gruppierung und Sortierung – ohne Präfixe, Deko und Werbewörter."""
    s = base_name(name)
    s = RX_VIP_CLEAN.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def clean_item_name(name: str, kind: str = "live", options: dict = None) -> str:
    """Bereinigt Sendernamen: entfernt Länderkürzel (DE |, [DE]), Deko, VIP, Codecs und vereinheitlicht Qualitäts-Tags."""
    if not name:
        return ""
    opts = {"remove_cc": True, "remove_deco": True, "remove_vip": True, "normalize_quality": True}
    if options:
        opts.update(options)

    s = norm_text(name)
    is_backup = bool(RX_BACKUP.search(s)) if kind == "live" else False
    q = quality_of(s) if opts.get("normalize_quality") else ""

    if opts.get("remove_cc"):
        s = RX_CC_PREFIX_EXPANDED.sub("", s, count=1)
        s = re.sub(r"^\s*\[[A-Z]{2,4}\]\s*[:|\-_]?\s*", "", s, flags=re.I)
        s = re.sub(r"^\s*[A-Z]{2,4}[_\-]\s*", "", s)
        s = RX_TAG_PREFIX.sub("", s)

    if opts.get("remove_deco"):
        s = re.sub(RX_DECO, " ", s)
        s = RX_SYMBOLS.sub(" ", s)

    if opts.get("remove_vip"):
        s = RX_VIP_CLEAN.sub(" ", s)

    s = RX_FPS_CLEAN.sub(" ", s)
    s = RX_CODEC_CLEAN.sub(" ", s)
    s = RX_QUALITY_BRACKETS_CLEAN.sub(" ", s)

    if opts.get("normalize_quality"):
        s = RX_Q.sub(" ", s)

    if is_backup:
        s = RX_BACKUP.sub(" ", s)

    s = re.sub(r"[\[\(]\s*[\]\)]", " ", s)
    s = clean_edges(s)

    if opts.get("normalize_quality") and q:
        s = f"{s} {q}"

    if is_backup:
        s = f"{s} (Backup)"

    return clean_edges(s) or name


def norm_text(s: str) -> str:
    for k in SUP_ORDER:
        s = s.replace(k, SUP[k])
    s = fix_ball(s).replace("\ufe0f", "").replace("\ufe0e", "").replace("\u200d", "")
    # übrig gebliebene hochgestellte Zeichen: mit Abstand anhängen („RTLᴴᴰ⁺“ -> „RTL HD+“)
    return re.sub(r"(?<=[A-Za-z0-9ÄÖÜäöüß)\]])(?=[ᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁⱽᵂ⁰¹²³⁴⁵⁶⁷⁸⁹⁺])", " ", s).translate(SUPCHARS) if any(c in s for c in "ᴬᴮᴰᴱᴳᴴᴵᴶᴷᴸᴹᴺᴼᴾᴿᵀᵁⱽᵂᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖʳˢᵗᵘᵛʷˣʸᶻ⁰¹²³⁴⁵⁶⁷⁸⁹⁺") else s


def quality_of(name: str) -> str:
    m = RX_Q.findall(norm_text(name))
    if not m:
        return ""
    q = m[-1].upper().replace(" ", "")
    return "4K" if q in ("4K", "UHD", "2160", "2160P", "3840", "3840P", "8K", "4320", "4320P") else "FHD" if q in ("FHD", "FULLHD", "1080", "1080P", "1080I") \
        else "SD" if q in ("SD", "576", "576P", "576I", "480P") else "HD"


def country_of(text: str):
    t = norm_text(text or "")
    m = RX_CC_PREFIX.match(t)
    if m:
        c = m.group(1).upper()
        return {"GB": "UK", "USA": "US", "ALB": "AL", "EX-YU": "EXYU", "KURD": "KU", "ARAB": "AR"}.get(c, c)
    for rx, c in COUNTRY_WORDS:
        if re.search(rx, t, re.I):
            return {"ALB": "AL", "KURD": "KU", "ARAB": "AR"}.get(c, c)
    m = RX_CC_SUFFIX.search(t)
    if m and len(t) > len(m.group(0)) + 2:
        c = m.group(1).upper()
        return {"GB": "UK", "USA": "US"}.get(c, c)
    return ""


Q_RANK = {"4K": 0, "FHD": 1, "HD": 2, "SD": 3, "": 4}
RX_BACKUP = re.compile(r"backup|reserve|yedek|\bbk\b|\b(?:alt|alternativ)\b", re.I)


def grp(o: dict, known=None) -> str:
    """Zu welchem Sender gehört dieser Eintrag? Grundlage ist der Original-Name des Anbieters – so bleibt ein umbenannter
    „TRT 1 ONYX“ bei TRT 1. Passt dein eigener Name aber zu einem anderen Sender der Kategorie, zählt dein Name."""
    orig = base_name(o.get("_orig") or o.get("name", "")) or base_name(o.get("name", ""))
    if known and o.get("name") and o.get("name") != o.get("_auto"):
        mine = base_name(o["name"])
        if mine and mine != orig and mine in known:
            return mine
    return orig


def known_groups(lst: list) -> set:
    return {base_name(o.get("_orig") or o.get("name", "")) for o in lst} | {base_name(o.get("name", "")) for o in lst}


def variant_rank(o: dict) -> tuple:
    nm, orig = o.get("name", ""), o.get("_orig") or o.get("name", "")
    q = quality_of(orig) if RX_Q.search(norm_text(orig)) else quality_of(nm)
    return (bool(RX_BACKUP.search(orig) or RX_BACKUP.search(nm)), Q_RANK.get(q, 4), nm.lower())


def place_near_variants(kind: str, cat: str, moved: set) -> None:
    """Verschobene Sender zu ihren Varianten in der Ziel-Kategorie stellen – der Rest bleibt, wie er ist."""
    lst = sorted(view.get(kind, {}).get("items", {}).get(cat, []), key=lambda o: o["_order"])
    kn = known_groups(lst)
    gk = {id(o): grp(o, kn) for o in lst}
    new = [o for o in lst if item_key(kind, o) not in moved]
    for m in [o for o in lst if item_key(kind, o) in moved]:
        g, r = gk[id(m)], variant_rank(m)
        idx = [i for i, o in enumerate(new) if gk[id(o)] == g]
        if not idx:
            new.append(m)
            continue
        pos = next((i for i in idx if variant_rank(new[i]) > r), idx[-1] + 1)
        new.insert(pos, m)
    chan = curation.setdefault("channels", {})
    for n, o in enumerate(new):
        chan.setdefault(f"{kind}:{item_key(kind, o)}", {})["order"] = n


def sort_category(kind: str, cat: str, mode: str) -> int:
    """Sender einer Kategorie neu ordnen. group: Varianten desselben Senders untereinander (Reihenfolge wie beim
    Anbieter, innen 4K → FHD → HD → SD, Backup zuletzt) · az: alphabetisch · clean_az: alphabetisch nach bereinigtem Namen
    · quality: nach Bildqualität priorisiert (4K → FHD → HD → SD) · provider: wie beim Anbieter."""
    lst = list(view.get(kind, {}).get("items", {}).get(cat, []))
    chan = curation.setdefault("channels", {})
    if mode == "provider":
        for o in lst:
            st = chan.get(f"{kind}:{item_key(kind, o)}")
            if st and "order" in st:
                st.pop("order", None)
                if not st:
                    chan.pop(f"{kind}:{item_key(kind, o)}", None)
        return len(lst)
    kn = known_groups(lst)
    gk = {id(o): grp(o, kn) for o in lst}
    first = {}
    for i, o in enumerate(sorted(lst, key=lambda o: o["_order"])):
        first.setdefault(gk[id(o)], i)

    def key(o):
        b = gk[id(o)]
        cb = clean_base_name(b)
        nat_clean = tuple((0, int(t), "") if t.isdigit() else (1, 0, t) for t in re.findall(r"\d+|\D+", cb))
        nat_orig = tuple((0, int(t), "") if t.isdigit() else (1, 0, t) for t in re.findall(r"\d+|\D+", b))
        if mode == "quality":
            orig = o.get("_orig") or o.get("name", "")
            nm = o.get("name", "")
            q = quality_of(orig) if RX_Q.search(norm_text(orig)) else quality_of(nm)
            is_bk = bool(RX_BACKUP.search(orig) or RX_BACKUP.search(nm))
            return (Q_RANK.get(q, 4), is_bk, nat_clean, nm.lower())
        elif mode == "clean_az":
            return (nat_clean, ) + variant_rank(o)
        elif mode == "az":
            return (nat_orig, ) + variant_rank(o)
        else:
            return (first.get(b, 0), b) + variant_rank(o)

    for n, o in enumerate(sorted(lst, key=key)):
        chan.setdefault(f"{kind}:{item_key(kind, o)}", {})["order"] = n
    return len(lst)


def base_name(name: str) -> str:
    """„DE | SKY SPORT 1 FHD ᴴᴱⱽᶜ“ -> „sky sport 1“ – damit Varianten zusammenfinden."""
    s = norm_text(name or "")
    s = RX_CC_PREFIX.sub("", s, count=1)
    s = RX_TAG_PREFIX.sub("", s)
    s = RX_Q.sub(" ", s)
    for rx in RX_FLAGS.values():
        s = rx.sub(" ", s)
    s = RX_CC_SUFFIX.sub("", s)
    s = RX_SYMBOLS.sub(" ", s)
    s = re.sub(r"[\[\](){}]", " ", s)
    s = re.sub(r"(?<=[A-Za-zÄÖÜäöü])(?=\d)", " ", s)
    s = re.sub(r"[\s\-_:.,/+]+", " ", s).strip().lower()
    return s


_cc_cache: dict = {}
RX_EPG_TLD = re.compile(r"\.([a-z]{2})$", re.I)
NOT_CC = {"tv", "hd", "fm", "uk1", "eu"}


def cat_cc(kind: str, c: dict) -> str:
    """Land einer Kategorie. Steht es nicht im Namen („4K| RELAX“), wird es aus den Sendern darin abgeleitet
    (Länderkürzel im Sendernamen oder Endung der Programm-Kennung wie „trt1.tr“) – nur bei klarer Mehrheit."""
    cc = country_of(c.get("orig") or c.get("name") or "") or ""
    if cc or c.get("pkey") == "C":
        return cc
    lst = view.get(kind, {}).get("items", {}).get(c["vid"], [])
    key = (kind, c["vid"])
    hit = _cc_cache.get(key)
    if hit and hit[0] == len(lst):
        return hit[1]
    votes = {}
    for o in lst[:80]:
        x = country_of(o.get("_orig") or o.get("name", "")) or ""
        if not x:
            m = RX_EPG_TLD.search(str(o.get("epg_channel_id") or ""))
            if m and m.group(1).lower() not in NOT_CC:
                x = {"GB": "UK"}.get(m.group(1).upper(), m.group(1).upper())
        if x:
            votes[x] = votes.get(x, 0) + 1
    res = ""
    if votes:
        best, n = max(votes.items(), key=lambda kv: kv[1])
        if n >= 3 and n >= 0.6 * sum(votes.values()):
            res = best
    _cc_cache[key] = (len(lst), res)
    return res


def cat_country_map(kind: str) -> dict:
    return {c["vid"]: cat_cc(kind, c) for c in view.get(kind, {}).get("cats", [])}


def variant_groups(kind: str = "live", only_visible: bool = True, hidden_cats=None) -> list:
    hidden_cats = hidden_cats or set()
    cc = cat_country_map(kind)
    shown = {c["vid"]: c for c in view.get(kind, {}).get("cats", [])}
    drops = drops_by_channel(7 * 24) if kind == "live" else {}
    pl = plays_30d(kind)
    groups = {}
    pos = 0
    for c in view.get(kind, {}).get("cats", []):
        for it in view[kind]["items"].get(c["vid"], []):
            pos += 1
            visible = c["show"] and c["vid"] not in hidden_cats and not it.get("_hide")
            if only_visible and not visible:
                continue
            b = base_name(it.get("_orig") or it.get("name", ""))
            if not b or len(b) < 2:
                continue
            country = country_of(it.get("_orig", "")) or cc.get(it["_home"], "") or cc.get(c["vid"], "")
            vid = item_key(kind, it)
            text = norm_text(it.get("_orig", ""))
            groups.setdefault(f"{country}|{b}", []).append({
                "vid": vid, "name": it.get("name", ""), "orig": it.get("_orig", ""), "pkey": it["_p"], "cat": c["vid"],
                "cat_name": c["name"], "q": quality_of(it.get("_orig", "")), "hevc": bool(RX_FLAGS["hevc"].search(text)),
                "backup": bool(RX_FLAGS["backup"].search(text)), "raw": bool(RX_FLAGS["raw"].search(text)),
                "fps": bool(RX_FLAGS["fps"].search(text)), "hide": bool(it.get("_hide")), "visible": visible, "cat_show": bool(c["show"]),
                "epg": it.get("epg_channel_id") or "", "icon": it.get("_icon") or it.get("stream_icon") or "",
                "custom_icon": bool(it.get("_icon")), "drops": drops.get(vid, 0), "plays": pl.get(vid, 0), "pos": pos,
                "country": country})
    out = []
    for key, mem in groups.items():
        if len(mem) < 2:
            continue
        country, b = key.split("|", 1)
        out.append({"key": key, "base": b, "country": country, "label": base_display(mem), "items": mem})
    out.sort(key=lambda g: (-len(g["items"]), g["base"]))
    return out


def base_display(mem: list) -> str:
    n = min((m["orig"] for m in mem), key=lambda x: (x.upper() == x, len(x)))  # lieber „Sky Sport 1“ als „SKY SPORT 1“
    s = norm_text(n)
    s = RX_CC_PREFIX.sub("", s, count=1)
    s = RX_Q.sub(" ", s)
    for rx in RX_FLAGS.values():
        s = rx.sub(" ", s)
    s = RX_SYMBOLS.sub(" ", s)
    return re.sub(r"\s+", " ", re.sub(r"[\[\](){}]", " ", s)).strip(" -:|") or n


def rank_variants(mem: list, pref: dict) -> list:
    order = pref.get("quality") or ["FHD", "4K", "HD", "SD"]
    qi = {q: i for i, q in enumerate(order)}
    prov = pref.get("provider") or ""

    def score(m):
        return (1 if pref.get("avoid_backup", True) and m["backup"] else 0,
                1 if pref.get("avoid_hevc", True) and m["hevc"] else 0,
                qi.get(m["q"], len(order)) if m["q"] else len(order) - 0.5,
                0 if not prov or m["pkey"] == prov else 1,
                m["drops"] if pref.get("use_drops", True) else 0,
                m["pos"])
    return sorted(mem, key=score)


def plan_variants(pref: dict, keys=None, hidden_cats=None) -> dict:
    keep_n = max(1, min(10, int(pref.get("keep") or 2)))
    hide, keep, n_groups = [], [], 0
    for g in variant_groups("live", True, hidden_cats):
        if keys and g["key"] not in keys:
            continue
        r = rank_variants(g["items"], pref)
        if len(r) <= keep_n:
            continue
        n_groups += 1
        keep += [m["vid"] for m in r[:keep_n]]
        hide += [m["vid"] for m in r[keep_n:]]
    return {"groups": n_groups, "hide": hide, "keep": keep}


def countries_overview() -> dict:
    out = {}
    for kind in KINDS:
        items = view.get(kind, {}).get("items", {})
        for c in view.get(kind, {}).get("cats", []):
            code = cat_cc(kind, c)
            o = out.setdefault(code, {"code": code, "cats": 0, "items": 0, "visible": 0, "examples": []})
            o["cats"] += 1
            o["items"] += sum(1 for x in items.get(c["vid"], []) if not x.get("_hide"))
            o["visible"] += 1 if c["show"] else 0
            if len(o["examples"]) < 4:
                o["examples"].append(c["name"])
    return dict(sorted(out.items(), key=lambda kv: -kv[1]["items"]))


SPECIAL_CATS = {"adult": (r"adult|xxx|\b18\s*\+|porn|erotik|erotic|for adults|\+18", "Erwachsenen-Inhalte (Adult/XXX/18+)"),
                "ppv": (r"\bppv\b|pay.?per.?view", "Pay-per-View (PPV)"),
                "reserve": (r"backup|reserve|\btest\b|\binfo\b|ersatz|\bbk\b", "Reserve, Backup und Test"),
                "events": (r"\bevents?\b|\bmatch ?center\b|\blive ?events?\b", "Event-Kanäle (oft leer außerhalb von Events)")}


def special_cats() -> dict:
    out = {}
    for key, (rx, label) in SPECIAL_CATS.items():
        r = re.compile(rx, re.I)
        lst = [{"kind": kind, "vid": c["vid"], "name": c["name"], "show": c["show"]}
               for kind in KINDS for c in view.get(kind, {}).get("cats", []) if r.search(c["orig"]) or r.search(c["name"])]
        out[key] = {"label": label, "cats": lst}
    return out


def junk_proposals(kind: str = "live") -> list:
    """Typischer Müll in Namen – mit Anzahl und Vorher/Nachher. Wird als Umbenennungs-Regel gespeichert."""
    names = [it.get("name", "") for lst in view.get(kind, {}).get("items", {}).values() for it in lst]
    codes = {}
    for n in names:
        m = RX_CC_PREFIX.match(norm_text(n))
        if m:
            codes[m.group(1).upper()] = codes.get(m.group(1).upper(), 0) + 1
    props = []
    if codes:
        top = sorted(codes, key=lambda c: -codes[c])
        props.append({"id": "cc", "note": "Länderkürzel am Anfang", "rules": [[r"^\s*[\[\(|┃▎]?\s*(?:" + "|".join(re.escape(c) for c in top) + r")\s*[\]\)|┃▎:»\-–]+\s*", ""]], "desc": "Entfernt „" + "“, „".join(f"{c} |" for c in top[:4]) + "“ usw. vom Anfang – die Kategorie zeigt das Land ja schon."})
    props += [
        {"id": "sup", "note": "Hochgestellte Zeichen", "rules": [["ᶠᴴᴰ", " FHD"], ["ᵁᴴᴰ", " 4K"], ["⁴ᴷ", " 4K"], ["ᴴᴱⱽᶜ", " HEVC"], ["ᴿᴬᵂ", " RAW"], ["ᴴᴰ", " HD"], ["ˢᴰ", " SD"]],
         "desc": "Macht aus ᴴᴰ, ᶠᴴᴰ, ᵁᴴᴰ normales „HD“, „FHD“, „4K“ – hochgestellte Zeichen sehen auf vielen Fernsehern kaputt aus."},
        {"id": "sym", "note": "Deko-Symbole", "rules": [[RX_DECO, " "]], "desc": "Entfernt Sterne, Punkte, Pfeile und Emojis."},
        {"id": "brq", "note": "Qualität in Klammern", "rules": [[r"\s*[\[\(]\s*(?:4K|UHD|FHD|HD|SD|HEVC|H\.?265|RAW|50 ?FPS|1080P?|720P?)\s*[\]\)]", ""]],
         "desc": "Entfernt „[FHD]“, „(HD)“ usw. Achtung: Dann steht die Qualität nicht mehr im Namen – nur sinnvoll, wenn du pro Sender nur noch eine Variante behältst."},
        {"id": "vip", "note": "Werbe-Wörter", "rules": [[r"(?<![A-Za-z])(?:VIP|PREMIUM|ᴠɪᴘ)(?![A-Za-z])", ""]], "desc": "Entfernt „VIP“ und „PREMIUM“."},
    ]
    for p in props:
        if "rules" not in p:
            p["rules"] = [[p.pop("find"), p.pop("replace")]]
    existing = {(r.get("find"), r.get("replace")) for r in curation.get("rules", [])}
    out = []
    for p in props:
        try:
            rxs = [(re.compile(f, re.IGNORECASE), r) for f, r in p["rules"]]
        except re.error:
            continue
        ex, n = [], 0
        for name in names:
            new = name
            for rx, r in rxs:
                new = rx.sub(r, new)
            new = clean_edges(new)
            if new != name and new:
                n += 1
                if len(ex) < 4:
                    ex.append([name, new])
        if n:
            out.append({**p, "count": n, "examples": ex, "exists": all((f, r) in existing for f, r in p["rules"])})
    return sorted(out, key=lambda p: -p["count"])


def merge_categories(kind: str, vids: list, name: str) -> str:
    """Fasst Kategorien zu einer eigenen zusammen. Die Quellen werden gemerkt (nicht nur die heutigen Sender),
    damit auch später neu hinzukommende Sender automatisch in der zusammengefassten Kategorie landen."""
    lst = curation.setdefault("custom", {}).setdefault(kind, [])
    cur = curation.setdefault(kind, {})
    chan = curation.setdefault("channels", {})
    n = max([int(c["vid"]) - CUSTOM_BASE for c in lst] + [0]) + 1
    new_vid = str(CUSTOM_BASE + n)
    first = min((cur.get(v, {}).get("order", 0) for v in vids), default=0)
    sources, shown, absorbed = [], [], set()
    for v in vids:
        cc = next((c for c in lst if c["vid"] == v), None)
        if cc is not None:  # eine eigene/zusammengefasste Kategorie geht in der neuen auf
            sources += cc.get("sources") or []
            shown += cc.get("shown") or []
            absorbed.add(v)
            cur.pop(v, None)
            continue
        if v in sources:
            continue
        sources.append(v)
        if cur.get(v, {}).get("show", True):
            shown.append(v)
        cur.setdefault(v, {})["show"] = False
    for st in chan.values():
        if st.get("cat") in absorbed or st.get("cat") in sources:
            st["cat"] = new_vid
    curation["custom"][kind] = [c for c in lst if c["vid"] not in absorbed]
    curation["custom"][kind].append({"vid": new_vid, "name": name, "sources": sources, "shown": shown})
    cur[new_vid] = {"show": True, "name": "", "order": first}
    return new_vid




def fuse_categories(kind: str, target_vid: str, source_vids: list, name: str) -> int:
    """Führt mehrere Kategorien in die zuerst ausgewählte Kategorie (target_vid) zusammen.
    Inhalte der source_vids wandern in target_vid, source_vids werden ausgeblendet.
    Gilt für Live-TV, Filme (vod) und Serien."""
    cur = curation.setdefault(kind, {})
    chan = curation.setdefault("channels", {})
    custom = curation.setdefault("custom", {}).setdefault(kind, [])
    cat_sources = curation.setdefault("cat_sources", {}).setdefault(kind, {})
    
    t_entry = cur.setdefault(target_vid, {})
    t_entry["show"] = True
    if name:
        t_entry["name"] = name
        
    cc_target = next((c for c in custom if c["vid"] == target_vid), None)
    if cc_target is not None:
        if name:
            cc_target["name"] = name
        src_list = cc_target.setdefault("sources", [])
        for s in source_vids:
            if s not in src_list and s != target_vid:
                src_list.append(s)
    else:
        src_list = cat_sources.setdefault(target_vid, [])
        for s in source_vids:
            if s not in src_list and s != target_vid:
                src_list.append(s)
                
    for s in source_vids:
        cur.setdefault(s, {})["show"] = False
        
    moved = 0
    id_key = "series_id" if kind == "series" else "stream_id"
    v_items = view.get(kind, {}).get("items", {})
    for s in source_vids:
        for it in v_items.get(s, []):
            sid = it.get(id_key)
            if sid is not None:
                chan.setdefault(f"{kind}:{sid}", {})["cat"] = target_vid
                moved += 1
                
    return moved



def unfuse_category(kind: str, target_vid: str, source_vid: str) -> bool:
    """Trennt eine zuvor fusionierte Quellkategorie wieder von der Hauptkategorie."""
    cur = curation.setdefault(kind, {})
    chan = curation.setdefault("channels", {})
    custom = curation.setdefault("custom", {}).setdefault(kind, [])
    cat_sources = curation.setdefault("cat_sources", {}).setdefault(kind, {})
    
    # 1. Aus cat_sources entfernen
    if target_vid in cat_sources:
        if source_vid in cat_sources[target_vid]:
            cat_sources[target_vid].remove(source_vid)
        if not cat_sources[target_vid]:
            cat_sources.pop(target_vid, None)
            
    # 2. Aus custom[kind] entfernen
    for cc in custom:
        if cc.get("vid") == target_vid and "sources" in cc:
            if source_vid in cc["sources"]:
                cc["sources"].remove(source_vid)
                
    # 3. Quellkategorie wieder einblenden
    cur.setdefault(source_vid, {})["show"] = True
    
    # 4. Kanäle, die ursprünglich aus source_vid stammen, von target_vid befreien
    id_key = "series_id" if kind == "series" else "stream_id"
    for pkey in ("A", "B"):
        for it in (catalog.get(pkey, {}).get(kind) or {}).get("items", []):
            vc = cat_vid(pkey, it.get("category_id"))
            if vc == source_vid:
                try:
                    sid = stream_vid(pkey, it[id_key])
                    key = f"{kind}:{sid}"
                    if key in chan and chan[key].get("cat") == target_vid:
                        chan[key].pop("cat", None)
                        if not chan[key]:
                            chan.pop(key, None)
                except (KeyError, TypeError, ValueError):
                    pass
    return True

def dup_cat_groups(kind: str = "live") -> list:
    """Kategorien mit demselben Namen (ohne Qualität/Deko) im selben Land – meist eine von Anbieter 1 und eine von Anbieter 2."""
    merged = {s for cc in curation.get("custom", {}).get(kind, []) for s in cc.get("sources") or []}
    items = view.get(kind, {}).get("items", {})
    groups = {}
    for c in view.get(kind, {}).get("cats", []):
        if c["pkey"] == "C" or c["vid"] in merged:
            continue
        b = base_name(c["orig"])
        if not b or len(b) < 2:
            continue
        country = cat_cc(kind, c) or ""
        groups.setdefault(f"{country}|{b}", []).append({
            "vid": c["vid"], "name": c["name"], "orig": c["orig"], "pkey": c["pkey"], "show": c["show"],
            "count": sum(1 for it in items.get(c["vid"], []) if not it.get("_hide"))})
    out = []
    for key, mem in groups.items():
        if len(mem) < 2:
            continue
        vis = [m for m in mem if m["show"]] or mem
        label = min((m["name"] for m in vis), key=lambda x: (x.upper() == x, len(x)))
        out.append({"key": key, "country": key.split("|", 1)[0], "label": label, "cats": mem,
                    "visible": sum(1 for m in mem if m["show"])})
    out.sort(key=lambda g: (-g["visible"], -len(g["cats"]), g["label"].lower()))
    return out


def set_hidden(kind: str, vids: list, hide: bool) -> None:
    with lock:
        chan = curation.setdefault("channels", {})
        for v in vids:
            key = f"{kind}:{int(v)}"
            st = chan.setdefault(key, {})
            st["hide"] = hide
            if not any(st.get(f) for f in ("cat", "name", "hide", "icon", "epg")) and st.get("order") is None:
                chan.pop(key, None)
    changes_seen(kind, vids=list(vids))
    build_view((kind,))


def epg_channels_with_data() -> set:
    con = epg_conn()
    s = {r[0] for r in con.execute("SELECT DISTINCT channel FROM prog")}
    con.close()
    return s


def variant_fill(apply: bool = False, what=("epg", "logo")) -> dict:
    """Sender ohne Programm/Logo bekommen es von einer Variante desselben Senders."""
    have = epg_channels_with_data()
    epg, logo = [], []
    for g in variant_groups("live", only_visible=False):
        donors_e = [m for m in g["items"] if m["epg"] in have]
        donors_l = sorted([m for m in g["items"] if m["icon"]], key=lambda m: not m["custom_icon"])
        for m in g["items"]:
            if not m["visible"]:
                continue
            if donors_e and m["epg"] not in have:
                epg.append({"vid": m["vid"], "name": m["name"], "from": donors_e[0]["name"], "epg": donors_e[0]["epg"]})
            if donors_l and not m["icon"]:
                logo.append({"vid": m["vid"], "name": m["name"], "from": donors_l[0]["name"], "icon": donors_l[0]["icon"]})
    if apply:
        chan = curation.setdefault("channels", {})
        if "epg" in what:
            for x in epg:
                chan.setdefault(f"live:{x['vid']}", {})["epg"] = x["epg"]
        if "logo" in what:
            for x in logo:
                chan.setdefault(f"live:{x['vid']}", {})["icon"] = x["icon"]
    return {"epg": len(epg), "logo": len(logo), "epg_examples": epg[:8], "logo_examples": logo[:8],
            "applied": bool(apply)}


def run_wizard(data: dict, dry: bool = True) -> dict:
    keep = {str(c).upper() for c in data.get("countries") or []}
    keep_unknown = bool(data.get("keep_unknown", True))
    special = [k for k in data.get("special") or [] if k in SPECIAL_CATS]
    merge_dups = bool(data.get("merge_dups"))
    sp_rx = [re.compile(SPECIAL_CATS[k][0], re.I) for k in special]
    hide_cats, before_vis, total = {k: [] for k in KINDS}, 0, 0
    with lock:
        for kind in KINDS:
            for c in view.get(kind, {}).get("cats", []):
                total += 1
                if not c["show"]:
                    continue
                before_vis += 1
                if c["pkey"] == "C":
                    continue  # eigene Kategorien fasst der Assistent nicht an
                code = cat_cc(kind, c)
                drop = False
                if keep:
                    drop = (code and code not in keep) or (not code and not keep_unknown)
                if not drop and any(r.search(c["orig"]) or r.search(c["name"]) for r in sp_rx):
                    drop = True
                if drop:
                    hide_cats[kind].append(c["vid"])
        pref = data.get("variants")
        plan = plan_variants(pref, hidden_cats=set(hide_cats["live"])) if pref else {"groups": 0, "hide": [], "keep": []}
        merges = []  # nur Kategorien, die nach dem Ausblenden noch sichtbar sind – ausgeblendete nimmt der Assistent nicht mit
        if merge_dups:
            for kind in KINDS:
                gone = set(hide_cats[kind])
                for g in dup_cat_groups(kind):
                    vids = [m["vid"] for m in g["cats"] if m["show"] and m["vid"] not in gone]
                    if len(vids) >= 2:
                        merges.append({"kind": kind, "vids": vids, "name": g["label"]})
        props = {p["id"]: p for p in junk_proposals("live")}
        rules = [props[i] for i in data.get("rules") or [] if i in props and not props[i]["exists"]]
    n_hidden = sum(len(v) for v in hide_cats.values())
    summary = {"cats_total": total, "cats_visible_before": before_vis, "cats_hide": n_hidden,
               "cats_visible_after": before_vis - n_hidden, "per_kind": {k: len(v) for k, v in hide_cats.items()},
               "variant_groups": plan["groups"], "variants_hide": len(plan["hide"]),
               "merges": len(merges), "merge_examples": [m["name"] for m in merges[:8]],
               "cats_merged": sum(len(m["vids"]) for m in merges),
               "rules": [{"note": r["note"], "count": r["count"]} for r in rules]}
    if dry:
        return {"dry": True, **summary}
    with lock:
        save_json(os.path.join("templates", "_vor-assistent.json"),
                  {"name": "Automatisch: Stand vor dem Aufräum-Assistenten", "created": int(time.time()),
                   "curation": json.loads(json.dumps(curation))})
        for kind, vids in hide_cats.items():
            for v in vids:
                curation.setdefault(kind, {}).setdefault(v, {})["show"] = False
        chan = curation.setdefault("channels", {})
        for v in plan["hide"]:
            chan.setdefault(f"live:{int(v)}", {})["hide"] = True
        for m in merges:
            merge_categories(m["kind"], m["vids"], m["name"])
        for r in rules:
            for f, rp in r["rules"]:
                curation.setdefault("rules", []).append({"find": f, "replace": rp, "regex": True, "case": False,
                                                         "kind": "all", "enabled": True, "note": "Assistent: " + r["note"]})
    build_view()
    return {"dry": False, **summary}


# ---------------------------------------------------------------- Änderungsverlauf
JOURNAL_MAX = 100
journal: list = load_json("journal.json", [])


def cur_flat() -> dict:
    with lock:
        f = {}
        for kind in KINDS:
            for vid, st in curation.get(kind, {}).items():
                f[f"cat\t{kind}\t{vid}"] = json.dumps(st, sort_keys=True)
        for key, st in curation.get("channels", {}).items():
            f[f"ch\t{key}"] = json.dumps(st, sort_keys=True)
        for k in ("custom", "rules", "packages", "livecats", "numbering", "hide_separators"):
            if k in curation:
                f[k] = json.dumps(curation[k], sort_keys=True)
        return f


def describe_diff(diff: list) -> str:
    c = {}
    for key, before, after in diff:
        b, a = json.loads(before) if before else {}, json.loads(after) if after else {}
        if key.startswith("ch\t"):
            if (b.get("cat") or "") != (a.get("cat") or ""): c["moved"] = c.get("moved", 0) + 1
            if bool(b.get("hide")) != bool(a.get("hide")): c["hid" if a.get("hide") else "unhid"] = c.get("hid" if a.get("hide") else "unhid", 0) + 1
            if (b.get("name") or "") != (a.get("name") or ""): c["renamed"] = c.get("renamed", 0) + 1
            if (b.get("icon") or "") != (a.get("icon") or ""): c["icon"] = c.get("icon", 0) + 1
            if (b.get("epg") or "") != (a.get("epg") or ""): c["epg"] = c.get("epg", 0) + 1
            if b.get("order") != a.get("order"): c["order"] = c.get("order", 0) + 1
        elif key.startswith("cat\t"):
            if b.get("show", True) != a.get("show", True): c["chid" if not a.get("show", True) else "cshow"] = c.get("chid" if not a.get("show", True) else "cshow", 0) + 1
            if (b.get("name") or "") != (a.get("name") or ""): c["cren"] = c.get("cren", 0) + 1
            if b.get("order") != a.get("order"): c["corder"] = c.get("corder", 0) + 1
        else:
            c[key] = 1
    words = [("moved", "{} Sender verschoben"), ("hid", "{} ausgeblendet"), ("unhid", "{} eingeblendet"), ("renamed", "{} umbenannt"),
             ("icon", "{} Logos geändert"), ("epg", "{} Programm-Zuordnungen"), ("chid", "{} Kategorien ausgeblendet"),
             ("cshow", "{} Kategorien eingeblendet"), ("cren", "{} Kategorien umbenannt"), ("custom", "eigene Kategorien geändert"),
             ("rules", "Regeln geändert"), ("packages", "Pakete geändert"), ("livecats", "Live-Kategorien geändert"),
             ("numbering", "Sendernummern geändert"), ("hide_separators", "Trennzeilen ein-/ausgeblendet")]
    parts = [w.format(c[k]) for k, w in words if c.get(k)]
    if not parts and (c.get("order") or c.get("corder")):
        parts = ["Reihenfolge geändert"]
    return ", ".join(parts) or "Änderung"


def journal_record(before: dict, label: str = "") -> None:
    after = cur_flat()
    diff = [(k, before.get(k), after.get(k)) for k in set(before) | set(after) if before.get(k) != after.get(k)]
    if not diff:
        return
    text = describe_diff(diff)
    journal.append({"id": secrets.token_hex(5), "t": int(time.time()), "text": (label + ": " if label else "") + text, "diff": diff})
    del journal[:-JOURNAL_MAX]
    try:
        save_json("journal.json", journal)
    except Exception as e:
        log.warning("journal.json: %s", e)


def journal_undo(jid: str) -> str:
    e = next((x for x in journal if x["id"] == jid), None)
    if not e:
        raise ValueError("Eintrag nicht gefunden")
    with lock:
        for key, before, after in e["diff"]:
            val = json.loads(before) if before else None
            parts = key.split("\t")
            if parts[0] == "cat":
                d = curation.setdefault(parts[1], {})
                d.pop(parts[2], None) if val is None else d.__setitem__(parts[2], val)
            elif parts[0] == "ch":
                d = curation.setdefault("channels", {})
                d.pop(parts[1], None) if val is None else d.__setitem__(parts[1], val)
            else:
                curation.pop(key, None) if val is None else curation.__setitem__(key, val)
    build_view()
    return e["text"]


JOURNAL_PATHS = {"/api/categories": "", "/api/channels": "", "/api/custom": "Eigene Kategorie", "/api/custom_delete": "Kategorie gelöscht",
                 "/api/rules": "Regeln", "/api/separators": "Trennzeilen", "/api/packages": "Pakete", "/api/livecats": "Live-Kategorien", "/api/templates/load": "Vorlage geladen",
                 "/api/variants_apply": "Varianten", "/api/wizard": "Aufräum-Assistent", "/api/merge_cats": "Zusammengeführt", "/api/package_from_state": "Paket aus IST-Zustand gespeichert", "/api/fuse_cats": "Kategorien fusioniert", "/api/unfuse_cat": "Kategorie getrennt", "/api/clean_names": "Namen bereinigt", "/api/merge_dups": "Doppelte Kategorien", "/api/country_show": "", "/api/hide_all": "Alles ausgeblendet", "/api/sort_cat": "Sortiert",
                 "/api/variant_fill": "Von Varianten übernommen", "/api/numbering": "Sendernummern", "/api/backup_restore": "Sicherung wiederhergestellt"}


# ---------------------------------------------------------------- Reseller-Panel (8K, Anbieter 1)
# Die Panel-Schnittstelle ist für Reseller gedacht. Trotzdem: eigene Drossel, Wächter-Zähler, kein Dauerfeuer.
PANEL_DEFAULT = {"url": "https://8k.online-cms.ru/api/api.php", "api_key": "", "enabled": False, "provider": "A",
                 "sync_exp": True, "low_credits": 3}
panel_lines: dict = load_json("panel_lines.json", {})     # Line-Benutzername -> {expire, enabled, country, user_id, note, checked}
panel_state: dict = load_json("panel_state.json", {})     # {credits, reseller, checked, error}
_panel_lock = threading.Lock()
_panel_last = [0.0]


class PanelError(RuntimeError):
    pass


def panel_cfg() -> dict:
    p = config.setdefault("panel", {})
    for k, v in PANEL_DEFAULT.items():
        p.setdefault(k, v)
    return p


def panel_call(params: dict) -> dict:
    p = panel_cfg()
    if not p.get("api_key"):
        raise PanelError("Kein API-Key eingetragen")
    if not guard_allow("P", "own", "Panel " + params.get("action", "")):
        raise PanelError("Anfragen-Wächter: Panel-Anfragen gerade pausiert oder Stundengrenze erreicht")
    with _panel_lock:  # höchstens eine Anfrage alle 2 Sekunden
        wait = _panel_last[0] + 2 - time.time()
        if wait > 0:
            time.sleep(wait)
        _panel_last[0] = time.time()
    url = p["url"] + "?" + urllib.parse.urlencode({**params, "api_key": p["api_key"]})
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Onyx Merge)", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            body = r.read(1 << 20)
    except urllib.error.HTTPError as e:
        guard_report("P", "Panel", e.code)
        raise PanelError(f"Panel antwortet mit HTTP {e.code}")
    except Exception as e:
        guard_report("P", "Panel", None, type(e).__name__)
        raise PanelError(f"Panel nicht erreichbar ({type(e).__name__})")
    try:
        data = json.loads(body.decode("utf-8", "replace"))
    except ValueError:
        raise PanelError("Panel hat keine gültige Antwort geschickt")
    if isinstance(data, list):
        data = data[0] if data else {}
    if not isinstance(data, dict):
        raise PanelError("Unerwartete Antwort vom Panel")
    if str(data.get("status", "true")).lower() not in ("true", "1"):
        raise PanelError(str(data.get("message") or data.get("messasge") or "Panel hat abgelehnt"))
    return data


def panel_reseller() -> dict:
    d = panel_call({"action": "reseller"})
    panel_state.update({"credits": d.get("credits"), "reseller": d.get("username"), "enabled": d.get("enabled"),
                        "checked": int(time.time()), "error": ""})
    save_json("panel_state.json", panel_state)
    try:
        if float(d.get("credits")) <= float(panel_cfg().get("low_credits", 3)):
            notify("credits", f"💳 Nur noch {d.get('credits')} Credits im Panel – Verlängerungen und neue Lines brauchen Guthaben.", cooldown=24 * 3600)
    except (TypeError, ValueError):
        pass
    return panel_state


def panel_line_info(line: str, pw: str) -> dict:
    d = panel_call({"action": "device_info", "username": line, "password": pw})
    info = {"expire": str(d.get("expire") or "")[:10], "enabled": str(d.get("enabled", "1")) in ("1", "true"),
            "country": str(d.get("country") or "").upper(), "user_id": str(d.get("user_id") or ""),
            "note": str(d.get("note") or ""), "checked": int(time.time())}
    panel_lines[line] = info
    save_json("panel_lines.json", panel_lines)
    if panel_cfg().get("sync_exp") and re.fullmatch(r"\d{4}-\d{2}-\d{2}", info["expire"]):
        changed = False
        for u in users:
            if (u.get(panel_cfg()["provider"]) or {}).get("user") == line and u.get("exp") != info["expire"]:
                u["exp"] = info["expire"]
                changed = True
        if changed:
            save_json("users.json", users)
            resp_cache.clear()
    return info


def panel_refresh_all() -> dict:
    """Einmal am Tag: Guthaben + Ablaufdatum jeder Line. Eine Anfrage pro Line, mit Pausen."""
    pk = panel_cfg()["provider"]
    done, errors = 0, []
    try:
        panel_reseller()
    except PanelError as e:
        panel_state.update({"error": str(e), "checked": int(time.time())})
        save_json("panel_state.json", panel_state)
        return {"done": 0, "errors": [str(e)]}
    seen = set()
    for u in list(users):
        acc = u.get(pk) or {}
        if not acc.get("user") or acc["user"] in seen:
            continue
        seen.add(acc["user"])
        try:
            panel_line_info(acc["user"], acc.get("pass", ""))
            done += 1
        except PanelError as e:
            errors.append(f"{u['username']}: {e}")
            if "Wächter" in str(e) or "HTTP" in str(e) or "erreichbar" in str(e):
                break  # bei Störung nicht weiter anfragen
        time.sleep(1)
    panel_state["last_refresh"] = int(time.time())
    panel_state["refresh_errors"] = errors[:10]
    save_json("panel_state.json", panel_state)
    return {"done": done, "errors": errors}


def panel_scheduler() -> None:
    last = None
    while True:
        try:
            now = datetime.now(tz())
            if panel_cfg().get("enabled") and panel_cfg().get("api_key") and now.hour == 5 and now.minute >= 40 and last != now.date():
                last = now.date()
                time.sleep(random.randint(0, 600))
                panel_refresh_all()
        except Exception as e:
            log.error("Panel-Abgleich: %s", e)
        time.sleep(60)


def panel_user(name: str):
    u = next((x for x in users if x["username"] == name), None)
    if not u:
        raise PanelError("Benutzer nicht gefunden")
    acc = u.get(panel_cfg()["provider"]) or {}
    if not acc.get("user"):
        raise PanelError(f"Dieser Benutzer hat keine Line bei {pname('A')}")
    return u, acc


# ---------------------------------------------------------------- Zusatz-Laufzeit (Lines bei Anbieter 2 – ohne Panel-API)
# Jede Line nennt bei der Anmeldung ihr Ablaufdatum (wie in jeder App). Einmal am Tag pro Kunde mit Zusatz-Line,
# mit Pausen und über den Anfragen-Wächter. Gespeichert getrennt von den Kunden (kein Konflikt beim Speichern).
bexp: dict = load_json("bexp.json", {})  # Line bei Anbieter 2 -> {exp, status, auth, checked, error}
_bexp_lock = threading.Lock()
bexp_state = {"running": False, "last_run": 0}


def bline_check(line: str, pw: str) -> dict:
    now = int(time.time())
    try:
        d = upstream_get("B", "player_api.php", {"username": line, "password": pw}, timeout=30)
        ui = (d.get("user_info") if isinstance(d, dict) else None) or {}
        exp = ""
        try:
            if ui.get("exp_date"):
                exp = datetime.fromtimestamp(int(ui["exp_date"]), tz()).strftime("%Y-%m-%d")
        except (TypeError, ValueError):
            pass
        auth = str(ui.get("auth", "0")) in ("1", "True", "true")
        info = {"exp": exp, "status": str(ui.get("status") or ""), "auth": auth, "checked": now,
                "error": "" if ui else "Anbieter hat keine Zugangsdaten zurückgegeben"}
    except GuardBlocked:
        raise
    except Exception as e:
        info = {**bexp.get(line, {}), "checked": now, "error": f"Nicht erreichbar ({type(e).__name__})"}
    with _bexp_lock:
        bexp[line] = info
        save_json("bexp.json", bexp)
    return info


def bline_of(u: dict):
    acc = u.get("B") or {}
    return (acc.get("user"), acc.get("pass", "")) if acc.get("user") else (None, None)


def bexp_refresh_all(force: bool = False) -> dict:
    """Einmal am Tag: Ablauf jeder Zusatz-Line. Eine Anfrage pro Line, 20–40 s Pause dazwischen."""
    if bexp_state["running"]:
        return {"done": 0, "errors": ["läuft schon"]}
    bexp_state["running"] = True
    done, errors, seen = 0, [], set()
    try:
        for u in list(users):
            line, pw = bline_of(u)
            if not line or line in seen or u.get("enabled", True) is False:
                continue
            seen.add(line)
            if not force and time.time() - (bexp.get(line) or {}).get("checked", 0) < 20 * 3600:
                continue
            if done:
                time.sleep(random.uniform(20, 40))
            try:
                info = bline_check(line, pw)
                done += 1
                if info.get("error"):
                    errors.append(f"{u['username']}: {info['error']}")
                    if "Nicht erreichbar" in info["error"]:
                        break  # bei Störung nicht weiter anfragen
            except GuardBlocked as e:
                errors.append(str(e))
                break
        # Lines, die kein Kunde mehr hat, vergessen
        with _bexp_lock:
            have = {bline_of(u)[0] for u in users}
            for k in [k for k in bexp if k not in have]:
                bexp.pop(k, None)
            save_json("bexp.json", bexp)
    finally:
        bexp_state.update({"running": False, "last_run": int(time.time()), "errors": errors[:10]})
    return {"done": done, "errors": errors}


def bexp_scheduler() -> None:
    last = None
    while True:
        try:
            now = datetime.now(tz())
            if config.get("bexp_check", True) and now.hour == 5 and now.minute >= 10 and last != now.date():
                last = now.date()
                time.sleep(random.randint(0, 900))
                bexp_refresh_all()
        except Exception as e:
            log.error("Zusatz-Laufzeit: %s", e)
        time.sleep(60)


def bexp_due(days: int = 1) -> list:
    """Kunden, deren Zusatz-Line heute bis in `days` Tagen abläuft."""
    today = datetime.now(tz()).date()
    out = []
    for u in users:
        line, _ = bline_of(u)
        e = bexp.get(line or "") or {}
        if not line or not e.get("exp") or u.get("enabled", True) is False:
            continue
        try:
            n = (datetime.strptime(e["exp"], "%Y-%m-%d").date() - today).days
        except ValueError:
            continue
        if 0 <= n <= days:
            out.append((u["username"], n))
    return out


def parse_m3u_url(url: str) -> tuple:
    q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url or "").query))
    return q.get("username", ""), q.get("password", "")


# ---------------------------------------------------------------- Übersicht (Lagebild für die Startseite)
def overview() -> dict:
    now = int(time.time())
    today = datetime.now(tz()).date()
    issues = []   # (stufe, text, seite)  stufe: 3 = sofort, 2 = bald, 1 = Hinweis

    prov = {}
    for k, p in config["providers"].items():
        st = status.get(k, {})
        g = _g(k)
        paused = guard_paused(k)
        prov[k] = {"name": p.get("name"), "last_ok": st.get("last_ok", 0), "error": st.get("last_error", ""),
                   "epg_ok": st.get("epg_ok", 0), "epg_rows": st.get("epg_rows", 0), "counts": st.get("counts", {}),
                   "paused_for": int(paused), "pass_paused_for": int(guard_pass_paused(k)), "used": guard_used(k, "own"),
                   "limit": int(config.get("guard_limit_own", 120)), "has_sync": bool(p.get("sync_user"))}
        nm = p.get("name") or k
        ips = ip_status(k)
        if ips["verdict"] == "suspect":
            issues.append((3, f"{nm}: Verdacht, dass deine Server-IP gesperrt ist – {ips['check'].get('text') or ips['fail_sign']}", "ops"))
        if paused:
            issues.append((3, f"{nm}: Notstopp aktiv, noch {int(paused // 60) + 1} Min. – der Server fragt dort nichts an ({g.get('pause_reason', '')}).", "prov"))
        if not p.get("sync_user"):
            issues.append((3, f"{nm}: Noch kein Sync-Zugang eingetragen – ohne ihn gibt es keine Liste.", "prov"))
        elif st.get("last_error"):
            issues.append((3, f"{nm}: Letzter Abgleich fehlgeschlagen – {st['last_error']}", "ops", {"do": "sync", "key": k, "label": "Neu abgleichen"}))
        elif st.get("last_ok") and now - st["last_ok"] > 36 * 3600:
            issues.append((2, f"{nm}: Letzter erfolgreicher Abgleich ist über 36 Stunden her.", "ops", {"do": "sync", "key": k, "label": "Jetzt abgleichen"}))
        if p.get("epg", True) and st.get("last_ok") and not st.get("epg_rows") and (config.get("epg_ext") or {}).get("mode") != "only":
            issues.append((1, f"{nm}: Kein Programm (EPG) geladen – Live-Kategorien bleiben leer.", "prov"))

    def days(u):
        try:
            return (datetime.strptime(u.get("exp") or "", "%Y-%m-%d").date() - today).days
        except ValueError:
            return None
    soon = sorted([(days(u), u["username"]) for u in users if u.get("enabled", True) and days(u) is not None and 0 <= days(u) <= 7])
    gone = [u["username"] for u in users if u.get("enabled", True) and days(u) is not None and days(u) < 0]
    noline = [u["username"] for u in users if not (u.get("A") or {}).get("user") and not (u.get("B") or {}).get("user")]
    active24 = [n for n, a in activity.items() if now - a.get("t", 0) < 86400 and any(u["username"] == n for u in users)]
    refused = [(n, a["refused"]) for n, a in activity.items() if a.get("refused") and now - a["refused"]["t"] < 86400
               and a["refused"]["t"] > a.get("t", 0)]
    if soon:
        issues.append((2, "Läuft bald ab: " + ", ".join(f"{n} ({'heute' if d == 0 else f'in {d} T.'})" for d, n in soon), "users",
                       {"do": "filter", "filter": "soon", "label": "Verlängern"}))
    if gone:
        issues.append((2, f"Abgelaufen ({len(gone)}): " + ", ".join(gone[:8]) + (" …" if len(gone) > 8 else ""), "users",
                       {"do": "filter", "filter": "gone", "label": "Anzeigen"}))
    if noline:
        issues.append((1, "Ohne Line (sehen eine leere Liste): " + ", ".join(noline[:8]), "users", {"do": "filter", "filter": "noline", "label": "Anzeigen"}))
    for n, r in refused[:5]:
        issues.append((2, f"{n} wurde in den letzten 24 Std. abgelehnt: {r['why']} (über {r.get('host', '?')}).", "users", {"do": "user", "user": n, "label": "Öffnen"}))
    if not users:
        issues.append((2, "Noch keine Benutzer angelegt.", "users"))

    ds = load_json("domains.status.json", {})
    if ds.get("applied") and not ds.get("ok"):
        issues.append((3, f"Nginx hat die letzte Domain-Änderung abgelehnt: {ds.get('error', '')}", "prov"))
    bad_dns = [d for d, x in (ds.get("dns") or {}).items() if not x.get("here")]
    if bad_dns:
        issues.append((2, "Zeigt nicht auf diesen Server: " + ", ".join(bad_dns[:6]) + " – A-Eintrag prüfen.", "prov"))

    bks = list_backups()
    last_bk = bks[0]["t"] if bks else 0
    oi = offsite_info()
    if oi["enabled"]:
        ost = oi["status"]
        if not oi["mounted"]:
            issues.append((2, "Die Storage Box ist nicht eingebunden – die Sicherung landet gerade nur auf dem VPS.", "ops", {"do": "page", "page": "bk", "label": "Ansehen"}))
        elif ost and not ost.get("ok"):
            issues.append((2, f"Sicherung auf die Storage Box fehlgeschlagen: {ost.get('error', '?')}", "ops", {"do": "page", "page": "bk", "label": "Ansehen"}))
        elif not ost.get("t") or now - ost.get("t", 0) > 2 * 86400:
            issues.append((1, "Seit über zwei Tagen keine Sicherung mehr auf der Storage Box angekommen.", "ops", {"do": "page", "page": "bk", "label": "Ansehen"}))
    if not last_bk or now - last_bk > 2 * 86400:
        issues.append((2, "Die letzte Sicherung ist älter als zwei Tage." if last_bk else "Es gibt noch keine Sicherung.", "ops", {"do": "backup", "label": "Jetzt sichern"}))

    pc = panel_cfg()
    if pc.get("enabled"):
        cr = panel_state.get("credits")
        try:
            if cr is not None and float(cr) <= pc.get("low_credits", 3):
                issues.append((2, f"Nur noch {cr} Credits im Panel – Verlängerungen und neue Lines brauchen Guthaben.", "prov"))
        except (TypeError, ValueError):
            pass
        if panel_state.get("error"):
            issues.append((2, f"Panel: {panel_state['error']}", "prov"))
        pk = pc["provider"]
        for u in users:
            info = panel_lines.get((u.get(pk) or {}).get("user") or "")
            if info and info.get("country") not in ("", "ALL"):
                issues.append((2, f"Line von {u['username']} ist im Panel auf das Land {info['country']} festgelegt – über deinen VPS wird die Anmeldung "
                                  f"dann meist abgelehnt („User authentication failed“). Im Panel auf ALL stellen.", "users", {"do": "user", "user": u["username"], "label": "Öffnen"}))
            if info and not info.get("enabled", True):
                issues.append((2, f"Line von {u['username']} ist im Panel gesperrt.", "users", {"do": "user", "user": u["username"], "label": "Öffnen"}))
    vis_cats = sum(1 for k in KINDS for c in view.get(k, {}).get("cats", []) if c["show"])
    if vis_cats > 60 and not any(e["text"].startswith("Aufräum-Assistent") for e in journal):
        issues.append((1, f"{vis_cats} Kategorien sind sichtbar – der Aufräum-Assistent (Senderliste → Aufräumen) erledigt das erste Aufräumen in wenigen Minuten.", "clean", {"do": "wizard", "label": "Assistent starten"}))
    new_items = sum(len(v) for v in changes.get("new", {}).values())
    new_cats = sum(len(v) for v in changes.get("newcats", {}).values())
    if new_items or new_cats:
        parts = [f"{new_items} {'Eintrag' if new_items == 1 else 'Einträge'}" if new_items else "",
                 f"{new_cats} {'Kategorie' if new_cats == 1 else 'Kategorien'}" if new_cats else ""]
        issues.append((1, "Neu seit dem Abgleich: " + " und ".join(x for x in parts if x) + " – im Editor prüfen.", "editor", {"do": "new", "label": "Ansehen"}))
    pl = passthru_list()
    pw = [e for e in pl if e["week"] and e.get("auth") is not False]
    if pw:
        issues.append((2 if sum(e["week"] for e in pw) > 500 else 1,
                       f"{len(pw)} {'Zugang wird' if len(pw) == 1 else 'Zugänge werden'} noch über deine VPS-IP durchgereicht "
                       f"({sum(e['week'] for e in pw)} Anfragen in 7 Tagen) – in den Merger übernehmen senkt das Sperr-Risiko.", "users",
                       {"do": "passthru", "label": "Übernehmen"}))
    tech = route_issues()  # Technik (Routen, Absender-IP) gehört nach „Betrieb“ – hier nur als eine Zeile
    if tech:
        top = max(t[0] for t in tech)
        issues.append((top, f"Technik: {len(tech)} {'Hinweis' if len(tech) == 1 else 'Hinweise'} zur Verbindung mit den Anbietern – {tech[0][1][:90]}{'…' if len(tech[0][1]) > 90 else ''}",
                       "ops", {"do": "page", "page": "ops", "label": "Ansehen"}))
    for w in config_warnings:
        issues.append((2, w, "prov"))

    live = []
    for c in live_state["cats"]:
        evs = [e for e in c["events"] if e["stop"] > now]
        nxt = evs[0] if evs else None
        live.append({"name": c["name"], "count": len(evs), "running": sum(1 for e in evs if e["start"] <= now),
                     "next": {"title": nxt["title"], "start": nxt["start"]} if nxt else None})

    try:
        hh, mm = (config.get("sync_time") or "04:17").split(":")
        nxt = datetime.now(tz()).replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
        if nxt <= datetime.now(tz()):
            nxt += timedelta(days=1)
        next_sync = int(nxt.timestamp())
    except ValueError:
        next_sync = 0
    try:  # Befunde der Diagnose (ohne abgelehnte Anmeldungen – die stehen oben schon)
        for f in diagnose(24)["findings"]:
            if f["level"] >= 2 and f["kind"] != "refused":
                issues.append((f["level"], f["title"] + " – Details unter Diagnose.", "diag"))
    except Exception as e:
        log.warning("Diagnose in der Übersicht: %s", e)
    issues.sort(key=lambda x: -x[0])
    dis = load_json("ov_dismiss.json", {})
    shown, hidden = [], 0
    for x in issues:
        l, t, pg = x[:3]
        iid = hashlib.sha1(t.encode()).hexdigest()[:12]
        d = dis.get(iid)
        if d and (d.get("until", 0) == 0 or d["until"] > now):
            hidden += 1
            continue
        shown.append({"id": iid, "level": l, "text": t, "page": pg,
                      "action": (x[3] if len(x) > 3 else None) or {"do": "page", "page": pg, "label": "Öffnen"}})
    pt_wait = sum(1 for e in passthru_list() if e.get("auth"))
    kpis = {"active24": len(active24), "total": len(users), "soon7": sum(1 for u in users if u.get("enabled", True) and (days(u) is not None and 0 <= days(u) <= 7)),
            "gone": len(gone), "passthru": pt_wait, "credits": panel_state.get("credits") if pc.get("enabled") else None,
            "draft": draft_dirty(), "ip_suspect": [pname(k) for k in config["providers"] if ip_status(k)["verdict"] == "suspect"]}
    return {"issues": shown, "dismissed": hidden, "providers": prov, "kpis": kpis,
            "users": {"total": len(users), "active24": len(active24), "soon": len(soon), "gone": len(gone),
                      "disabled": sum(1 for u in users if not u.get("enabled", True))},
            "domains": {"names": ds.get("names", []), "ok": ds.get("ok"), "applied": ds.get("applied", 0)},
            "backup": {"last": last_bk, "count": len(bks)}, "live": live, "next_sync": next_sync,
            "panel": {"enabled": bool(pc.get("enabled")), "credits": panel_state.get("credits"), "checked": panel_state.get("checked", 0),
                      "last_refresh": panel_state.get("last_refresh", 0)},
            "new": {"items": new_items, "cats": new_cats}, "now": now}


# ---------------------------------------------------------------- Ausgangs-Wächter (IP des Anbieters + Route)
# Fragt nur DNS und die Routing-Tabelle des eigenen Servers – keine einzige Anfrage an einen Anbieter.
route_state: dict = load_json("route_state.json", {})


def source_ip_for(ip: str) -> dict:
    """Welche Absender-IP nimmt der Server für dieses Ziel? (UDP-connect sendet nichts, fragt nur die Routing-Tabelle)"""
    out = {"src": "", "via": "", "dev": ""}
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((ip, 80))
        out["src"] = s.getsockname()[0]
        s.close()
    except OSError:
        pass
    try:
        r = subprocess.run(["ip", "-4", "route", "get", ip], capture_output=True, text=True, timeout=5).stdout
        for k in ("src", "via", "dev"):
            m = re.search(rf"\b{k} (\S+)", r)
            if m:
                out[k] = m.group(1)
    except Exception:
        pass
    return out


def egress_for(pkey: str) -> str:
    return str((config.get("egress") or {}).get(pkey) or "").strip()


_bindable: dict = {}


def bind_src(pkey: str):
    """Absender-IP, von der der Merger diesen Anbieter anfragt – nur wenn sie wirklich auf diesem Server liegt.
    So bleibt die Absender-IP gleich, auch wenn der Anbieter auf eine neue IP umzieht und keine Route dafür existiert."""
    ip = egress_for(pkey)
    if not ip:
        return None
    if ip not in _bindable or time.time() - _bindable[ip][1] > 300:
        try:
            t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            t.bind((ip, 0))
            t.close()
            _bindable[ip] = (True, time.time())
        except OSError:
            _bindable[ip] = (False, time.time())
            log.warning("Absender-IP %s liegt nicht auf diesem Server – Anbieter %s wird normal angefragt", ip, pkey)
    return (ip, 0) if _bindable[ip][0] else None


class _SrcHTTP(urllib.request.HTTPHandler):
    def __init__(self, src):
        super().__init__()
        self.src = src

    def http_open(self, req):
        return self.do_open(lambda host, **kw: http.client.HTTPConnection(host, source_address=self.src, **kw), req)


class _SrcHTTPS(urllib.request.HTTPSHandler):
    def __init__(self, src):
        super().__init__()
        self.src = src

    def https_open(self, req):
        return self.do_open(lambda host, **kw: http.client.HTTPSConnection(host, source_address=self.src, **kw), req,
                            context=self._context)


def provider_open(pkey: str, req, timeout: int):
    src = bind_src(pkey)
    if not src:
        return urllib.request.urlopen(req, timeout=timeout)
    return urllib.request.build_opener(_SrcHTTP(src), _SrcHTTPS(src)).open(req, timeout=timeout)


def route_check() -> dict:
    now = int(time.time())
    for pkey in config["providers"]:
        want = egress_for(pkey)
        host = urllib.parse.urlsplit(provider_url(pkey)).hostname or ""
        st = route_state.setdefault(pkey, {"history": []})
        try:
            ips = sorted({a[4][0] for a in socket.getaddrinfo(host, 80, socket.AF_INET)})
        except OSError as e:
            st.update({"host": host, "checked": now, "error": f"DNS: {e}"})
            continue
        routes = {ip: source_ip_for(ip) for ip in ips}
        old = st.get("ips") or []
        if old and set(ips) != set(old):
            st["history"] = ([{"t": now, "from": old, "to": ips}] + st.get("history", []))[:20]
            st["changed"] = now
            log.warning("Anbieter %s: IP geändert %s -> %s", pkey, old, ips)
            notify("route", f"🔀 {config['providers'][pkey].get('name') or pkey}: {host} zeigt jetzt auf {', '.join(ips)} (vorher {', '.join(old)}). "
                            f"Prüfen, ob die Failover-Route die neue IP abdeckt.", key=f"route-ip-{pkey}-{','.join(ips)}", cooldown=0)
        st.update({"host": host, "ips": ips, "routes": routes, "checked": now, "error": ""})
        st["wrong_src"] = sorted(ip for ip, r in routes.items() if want and r["src"] and r["src"] != want)
        if st["wrong_src"]:
            ip0 = st["wrong_src"][0]
            notify("route", f"⚠️ {config['providers'][pkey].get('name') or pkey}: Verbindung zu {ip0} geht über {routes[ip0]['src']} raus statt über {want}.\n"
                            f"Reparieren: sudo ip route replace {ip0} via {routes[ip0].get('via') or 'GATEWAY'} dev {routes[ip0].get('dev') or 'ens3'} onlink src {want}",
                   key=f"route-src-{pkey}")
    save_json("route_state.json", route_state)
    return route_state


def route_scheduler() -> None:
    time.sleep(20)
    while True:
        try:
            route_check()
        except Exception as e:
            log.error("Ausgangs-Wächter: %s", e)
        time.sleep(900)


def route_issues() -> list:
    out = []
    for pkey, st in route_state.items():
        if pkey not in config["providers"]:
            continue
        want = egress_for(pkey)
        nm = config["providers"][pkey].get("name") or pkey
        if st.get("error"):
            out.append((2, f"{nm}: {st['host']} lässt sich gerade nicht auflösen ({st['error']}).", "ops", None))
        if st.get("wrong_src"):
            out.append((3, f"{nm}: Anfragen an {', '.join(st['wrong_src'])} gehen über die Absender-IP "
                           f"{st['routes'][st['wrong_src'][0]]['src']} raus statt über {want}. Wenn diese IP gesperrt ist, "
                           f"schlagen Abgleich und Durchreichen fehl („User authentication failed“). Route für die neue IP eintragen.", "ops", None))
        elif st.get("changed") and time.time() - st["changed"] < 3 * 86400:
            h = st["history"][0]
            out.append((2, f"{nm}: {st['host']} zeigt seit {datetime.fromtimestamp(h['t'], tz()).strftime('%d.%m. %H:%M')} auf "
                           f"{', '.join(h['to'])} (vorher {', '.join(h['from'])}). Prüfen, ob deine Failover-Route die neue IP abdeckt.", "ops", None))
    return out


# ---------------------------------------------------------------- Benachrichtigungen (Telegram)
NOTIFY_EVENTS = {
    "down": ("Nginx läuft nicht – Kunden kommen nicht rein", True),
    "route": ("Verbindung zum Anbieter über falsche IP oder IP-Wechsel", True),
    "guard": ("Notstopp des Anfragen-Wächters", True),
    "sync": ("Nächtlicher Abgleich fehlgeschlagen", True),
    "credits": ("Wenig Credits im Panel", True),
    "backup": ("Sicherung auf die Storage Box fehlgeschlagen", True),
    "disk": ("Wenig freier Speicherplatz auf dem VPS", True),
    "expiry": ("Jeden Morgen: wer heute oder morgen abläuft", True),
    "start": ("Merger wurde neu gestartet", False),
    "load": ("Server ausgelastet (Prozessor oder Arbeitsspeicher)", True),
    "draft": ("Senderliste: Änderungen seit über 2 Stunden nicht gespeichert", True),
    "block": ("Verdacht: Anbieter sperrt deine Server-IP", True),
}
notify_state: dict = load_json("notify_state.json", {})


def notify_cfg() -> dict:
    n = config.setdefault("notify", {})
    for k, v in DEFAULT_CONFIG["notify"].items():
        n.setdefault(k, json.loads(json.dumps(v)))
    return n


def tg_call(method: str, params: dict, timeout: int = 15) -> dict:
    token = notify_cfg().get("token") or ""
    if not token:
        raise RuntimeError("Noch kein Bot-Schlüssel eingetragen")
    req = urllib.request.Request(f"https://api.telegram.org/bot{token}/{method}",
                                 data=urllib.parse.urlencode(params).encode(), headers={"User-Agent": "Onyx Merge"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        try:
            d = json.loads(e.read().decode("utf-8", "replace"))
        except Exception:
            d = {"ok": False, "description": f"HTTP {e.code}"}
    except (urllib.error.URLError, OSError) as e:
        raise RuntimeError(f"Telegram ist vom Server aus nicht erreichbar ({getattr(e, 'reason', e)}).")
    if not d.get("ok"):
        desc = str(d.get("description") or "unbekannter Fehler")
        if "Unauthorized" in desc:
            desc = "Der Bot-Schlüssel stimmt nicht (Telegram sagt „Unauthorized“)."
        elif "chat not found" in desc:
            desc = "Chat nicht gefunden – schreib deinem Bot einmal „/start“ und such den Chat neu."
        raise RuntimeError(desc)
    return d


def tg_send(text: str) -> None:
    n = notify_cfg()
    if not n.get("chat_id"):
        raise RuntimeError("Noch kein Chat verbunden")
    tg_call("sendMessage", {"chat_id": n["chat_id"], "text": text[:3900], "disable_web_page_preview": "true"})


def notify(ev: str, text: str, key: str = "", cooldown: int = 6 * 3600) -> None:
    """Schickt eine Nachricht – aber dieselbe Sache höchstens einmal pro Sperrzeit."""
    n = notify_cfg()
    if not n.get("enabled") or not n.get("token") or not n.get("chat_id"):
        return
    if not n.get("events", {}).get(ev, NOTIFY_EVENTS.get(ev, ("", True))[1]):
        return
    key = key or ev
    now = time.time()
    if now - notify_state.get(key, 0) < cooldown:
        return
    notify_state[key] = now

    def go():
        try:
            tg_send(text)
            notify_state["_last"] = int(time.time())
            notify_state.pop("_error", None)
        except Exception as e:
            notify_state["_error"] = f"{datetime.now(tz()).strftime('%d.%m. %H:%M')}: {e}"
            log.warning("Telegram: %s", e)
        for k in [k for k, v in notify_state.items() if not k.startswith("_") and isinstance(v, (int, float)) and now - v > 14 * 86400]:
            notify_state.pop(k, None)
        save_json("notify_state.json", notify_state)
    threading.Thread(target=go, daemon=True).start()


def build_weekly_report() -> str:
    """I10: Kompakter wöchentlicher Statusbericht."""
    now = datetime.now(tz())
    u = users or []
    tot_users = len(u)
    active_7d = 0
    expiring_soon = 0
    now_ts = int(time.time())
    for usr in u:
        act = activity.get(usr.get("name", ""), {})
        if now_ts - act.get("t", 0) < 7 * 86400:
            active_7d += 1
        exp = usr.get("exp")
        if exp and 0 < exp - now_ts < 7 * 86400:
            expiring_soon += 1

    prov_lines = []
    for pk in config.get("providers", {}):
        pname = config["providers"][pk].get("name", pk)
        st = status.get(pk, {})
        last_sync = st.get("last_sync")
        sync_txt = datetime.fromtimestamp(last_sync, tz()).strftime("%d.%m. %H:%M") if last_sync else "nie"
        cats_live = len((catalog.get(pk, {}).get("live") or {}).get("items", []))
        cats_vod = len((catalog.get(pk, {}).get("vod") or {}).get("items", []))
        prov_lines.append(f"• {pname}: Abgleich {sync_txt} ({cats_live} Live, {cats_vod} VOD)")

    h = health.get("now", {})
    cpu = h.get("cpu", 0)
    rss_mb = h.get("rss", 0) / (1 << 20)
    avail_mb = h.get("mem_avail", 0) / (1 << 20)
    err_count = len(err_recent)

    lines = [
        f"📊 Wöchentlicher Onyx Merge Bericht ({now.strftime('%d.%m.%Y')})",
        "",
        "👥 Kunden:",
        f"• {tot_users} Kunden angelegt",
        f"• {active_7d} aktiv in den letzten 7 Tagen",
        f"• {expiring_soon} laufen in den nächsten 7 Tagen ab" if expiring_soon else "• Keine auslaufenden Abos nächste Woche",
        "",
        "📡 Anbieter:",
        *prov_lines,
        "",
        "💻 Server-Status:",
        f"• Prozessor: {cpu:.1f} %",
        f"• Speicher: {rss_mb:.0f} MB belegt (frei: {avail_mb:.0f} MB)",
        f"• Protokollierte Fehler: {err_count}",
        "",
        "✅ System läuft stabil."
    ]
    return chr(10).join(lines)


def service_state(name: str) -> str:
    """'active', 'failed', 'inactive' … – oder '' wenn sich das nicht feststellen lässt (z. B. kein systemd)."""
    try:
        r = subprocess.run(["systemctl", "is-active", name], capture_output=True, text=True, timeout=5)
        out = r.stdout.strip()
        return out if out in ("active", "failed", "inactive", "activating", "deactivating") else ""
    except Exception:
        return ""


watch_state: dict = {"nginx_bad": 0, "nginx_alerted": False, "offsite_seen": 0, "expiry_day": ""}


def watchdog() -> None:
    """Alle 60 Sekunden: Nginx, Speicherplatz, Sicherung auf der Storage Box, morgens die Ablauf-Liste."""
    time.sleep(30)
    while True:
        try:
            st = service_state("nginx")
            if st and st != "active":
                watch_state["nginx_bad"] += 1
                if watch_state["nginx_bad"] >= 2 and not watch_state["nginx_alerted"]:
                    watch_state["nginx_alerted"] = True
                    notify("down", f"⚠️ Nginx läuft nicht ({st}) – deine Kunden kommen gerade nicht rein.\n"
                                   "Auf dem VPS: sudo systemctl start nginx", key="nginx-down", cooldown=0)
            elif st == "active":
                if watch_state["nginx_alerted"]:
                    notify("down", "✅ Nginx läuft wieder – Kunden kommen wieder rein.", key="nginx-up", cooldown=0)
                watch_state.update({"nginx_bad": 0, "nginx_alerted": False})
            du = shutil.disk_usage(DATA)
            if du.free < 1 << 30 or du.free / du.total < 0.08:
                notify("disk", f"💾 Auf dem VPS sind nur noch {du.free / (1 << 30):.1f} GB frei ({du.free / du.total:.0%}).", cooldown=24 * 3600)
            os_st = load_json("offsite.status.json", {})
            if os_st.get("t", 0) > watch_state["offsite_seen"]:
                if watch_state["offsite_seen"] and not os_st.get("ok") and (config.get("offsite") or {}).get("enabled"):
                    notify("backup", f"❌ Sicherung auf die Storage Box fehlgeschlagen: {os_st.get('error', '?')}", key=f"bk-{os_st['t']}", cooldown=0)
                watch_state["offsite_seen"] = os_st["t"]
            now = datetime.now(tz())
            day = now.strftime("%Y-%m-%d")
            if now.hour >= 9 and watch_state["expiry_day"] != day:
                watch_state["expiry_day"] = day
                tom = (now + timedelta(days=1)).strftime("%Y-%m-%d")
                t0 = [u["username"] for u in users if u.get("enabled", True) and u.get("exp") == day]
                t1 = [u["username"] for u in users if u.get("enabled", True) and u.get("exp") == tom]
                bz = bexp_due(1)
                z0 = [n for n, d in bz if d == 0]
                z1 = [n for n, d in bz if d == 1]
                if z0 or z1:
                    t0 = t0 + [f"{n} (nur Zusatz)" for n in z0 if n not in t0]
                    t1 = t1 + [f"{n} (nur Zusatz)" for n in z1 if n not in t1]
                if t0 or t1:
                    notify("expiry", "📅 " + " · ".join(x for x in [f"Heute laufen ab: {', '.join(t0)}" if t0 else "",
                                                                  f"Morgen laufen ab: {', '.join(t1)}" if t1 else ""] if x),
                           key=f"exp-{day}", cooldown=0)
        except Exception as e:
            log.warning("Wächter (Benachrichtigung): %s", e)
        time.sleep(60)


# ---------------------------------------------------------------- Domain-Test
def local_ips() -> set:
    ips = set()
    try:
        ips |= set(subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5).stdout.split())
    except Exception:
        pass
    return ips


def check_domains() -> dict:
    """Prüft jede eingetragene Domain: DNS zeigt hierher? Antwortet Onyx Merge über Port 80 und 8080?
    Fragt nur den eigenen Server an – nie einen Anbieter: Zeigt eine Domain woanders hin, wird sie gar nicht abgerufen."""
    mine = local_ips()
    applied = set(load_json("domains.status.json", {}).get("names", []))
    names = []
    for d in all_domains():
        names.append(d)
        if d.count(".") == 1:
            names.append("www." + d)
    results = {}

    def one(d):
        r = {"domain": d, "ips": [], "dns": "fehlt", "nginx": d in applied, "ports": {}}
        try:
            r["ips"] = sorted({a[4][0] for a in socket.getaddrinfo(d, 80, socket.AF_INET)})
        except Exception:
            results[d] = r
            return
        r["dns"] = "hier" if set(r["ips"]) & mine else "woanders"
        if r["dns"] == "hier" and r["nginx"]:
            for port in (80, 8080):
                t0 = time.time()
                try:
                    req = urllib.request.Request(f"http://{d}:{port}/onyx-merge-ping", headers={"User-Agent": "onyx-merge-check"})
                    with urllib.request.urlopen(req, timeout=6) as resp:
                        j = json.loads(resp.read(2000) or b"{}")
                    ok = j.get("id") == config.get("instance_id")
                    r["ports"][port] = {"ok": ok, "ms": int((time.time() - t0) * 1000),
                                        "error": "" if ok else "antwortet, aber nicht Onyx Merge"}
                except Exception as e:
                    why = getattr(e, "reason", e)
                    txt = ("Verbindung abgelehnt" if isinstance(why, ConnectionRefusedError) else
                           "Zeitüberschreitung" if isinstance(why, (socket.timeout, TimeoutError)) else
                           f"HTTP {e.code}" if isinstance(e, urllib.error.HTTPError) else "nicht erreichbar")
                    r["ports"][port] = {"ok": False, "ms": int((time.time() - t0) * 1000), "error": txt}
        results[d] = r

    threads = [threading.Thread(target=one, args=(d,)) for d in names]
    for t in threads:
        t.start()
    for t in threads:
        t.join(20)
    return {"checked": int(time.time()), "server_ips": sorted(mine), "id": config.get("instance_id"),
            "results": [results[d] for d in names if d in results]}


# ---------------------------------------------------------------- Sicherungen
BACKUP_DIR = os.path.join(DATA, "backups")
BACKUP_FILES = ("config.json", "users.json", "curation.json", "curation_pub.json", "changes.json", "tests.json")
BACKUP_DIRS = ("templates", "logos")
KEEP = {"nachts": 14, "hand": 10, "vor-wiederherstellen": 5}


def make_backup(kind: str = "hand") -> str:
    os.makedirs(BACKUP_DIR, exist_ok=True)
    with lock:
        save_json("curation.json", curation)
        save_json("users.json", users)
        save_json("config.json", config)
        name = f"{kind}-{datetime.now(tz()).strftime('%Y-%m-%d_%H%M%S')}.tar.gz"
        tmp = os.path.join(BACKUP_DIR, name + ".tmp")
        with tarfile.open(tmp, "w:gz") as tf:
            for f in BACKUP_FILES:
                if os.path.exists(_path(f)):
                    tf.add(_path(f), arcname=f)
            for d in BACKUP_DIRS:
                if os.path.isdir(os.path.join(DATA, d)):
                    tf.add(os.path.join(DATA, d), arcname=d)
        os.replace(tmp, os.path.join(BACKUP_DIR, name))
        os.chmod(os.path.join(BACKUP_DIR, name), 0o600)
    for k, n in KEEP.items():  # alte Sicherungen aufräumen
        old = sorted(f for f in os.listdir(BACKUP_DIR) if f.startswith(k + "-") and f.endswith(".tar.gz"))
        for f in old[:-n]:
            try:
                os.remove(os.path.join(BACKUP_DIR, f))
            except OSError:
                pass
    log.info("Sicherung angelegt: %s", name)
    return name


def offsite_request() -> None:
    """Gibt dem Hilfsdienst (root) Bescheid, die neueste Sicherung auf die Storage Box zu kopieren."""
    if not (config.get("offsite") or {}).get("enabled"):
        return
    try:
        with open(_path("offsite.request"), "w") as f:
            f.write(str(time.time()))
    except OSError as e:
        log.warning("offsite.request: %s", e)


def offsite_info() -> dict:
    o = config.setdefault("offsite", json.loads(json.dumps(DEFAULT_CONFIG["offsite"])))
    d = o.get("dir") or ""
    root = d
    while root not in ("/", "") and not os.path.ismount(root):
        root = os.path.dirname(root)
    return {"enabled": bool(o.get("enabled")), "dir": d, "keep": int(o.get("keep") or 30), "has_pass": bool(o.get("pass")),
            "mounted": bool(root and root != "/"), "mount": root if root and root != "/" else "",
            "status": load_json("offsite.status.json", {})}


def list_backups() -> list:
    if not os.path.isdir(BACKUP_DIR):
        return []
    out = []
    for f in sorted(os.listdir(BACKUP_DIR), key=lambda x: os.path.getmtime(os.path.join(BACKUP_DIR, x)), reverse=True):
        if f.endswith(".tar.gz"):
            st = os.stat(os.path.join(BACKUP_DIR, f))
            kind = next((k for k in KEEP if f.startswith(k + "-")), "hand")
            out.append({"name": f, "kind": kind, "t": int(st.st_mtime), "size": st.st_size})
    return out


def backup_path(name: str):
    if not re.fullmatch(r"[a-z-]+-\d{4}-\d{2}-\d{2}_\d{6}\.tar\.gz", name or ""):
        return None
    p = os.path.join(BACKUP_DIR, name)
    return p if os.path.isfile(p) else None


def restore_backup(name: str) -> str:
    global users
    p = backup_path(name)
    if not p:
        raise ValueError("Sicherung nicht gefunden")
    with tarfile.open(p, "r:gz") as tf:  # erst prüfen: nur unsere eigenen Dateien
        members = tf.getmembers()
        for m in members:
            top = m.name.split("/")[0]
            if m.name.startswith("/") or ".." in m.name.split("/") or not (m.isfile() or m.isdir()) or \
                    (top not in BACKUP_FILES and top not in BACKUP_DIRS):
                raise ValueError(f"Unerwarteter Inhalt in der Sicherung: {m.name}")
    before = make_backup("vor-wiederherstellen")
    with lock:
        with tarfile.open(p, "r:gz") as tf:
            for d in BACKUP_DIRS:  # Ordner exakt auf den gesicherten Stand bringen
                if any(m.name.split("/")[0] == d for m in tf.getmembers()):
                    shutil.rmtree(os.path.join(DATA, d), ignore_errors=True)
            tf.extractall(DATA, filter="data") if hasattr(tarfile, "data_filter") else tf.extractall(DATA)
        newc = load_json("config.json", None)
        if isinstance(newc, dict):
            config.clear(); config.update(newc)
            for k, v in DEFAULT_CONFIG.items():
                config.setdefault(k, v)
        users = load_json("users.json", [])
        newcur = load_json("curation.json", {})
        curation.clear(); curation.update(newcur)
        for k in KINDS:
            curation.setdefault(k, {})
        resp_cache.clear()
    build_view()
    write_domains_file()
    log.info("Sicherung %s wiederhergestellt (vorher gesichert als %s)", name, before)
    return before


def nightly_maintenance() -> dict:
    """I4: Nächtliche Wartung: Datenbanken aufräumen, alte Diagnose- und Statistikdaten löschen, WAL checkpointen & VACUUM."""
    log.info("Nächtliche Wartung startet...")
    res = {}
    now = int(time.time())

    # 1. Diagnose-Datenbank (starts, refused, speed älter als 14 Tage)
    try:
        cut_diag = now - 14 * 86400
        for tbl in ("starts", "refused", "speed"):
            diag_exec(f"DELETE FROM {tbl} WHERE t < ?", (cut_diag,))
        diag_exec("PRAGMA wal_checkpoint(TRUNCATE)")
        diag_exec("VACUUM")
        res["diag"] = "ok"
    except Exception as e:
        log.warning("Wartung diag: %s", e)
        res["diag"] = str(e)

    # 2. Statistik-Datenbank (plays älter als 90 Tage)
    try:
        con = stats_conn()
        cutoff_stats = (datetime.now(tz()) - timedelta(days=90)).strftime("%Y-%m-%d")
        con.execute("DELETE FROM plays WHERE day < ?", (cutoff_stats,))
        con.commit()
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        con.close()
        res["stats"] = "ok"
    except Exception as e:
        log.warning("Wartung stats: %s", e)
        res["stats"] = str(e)

    # 3. EPG-Datenbank (abgelaufenes Programm älter als 24 Stunden + ungenutzte Sender)
    try:
        con = epg_conn()
        con.execute("DELETE FROM prog WHERE stop < ?", (now - 86400,))
        con.commit()
        con.close()
        pruned = prune_epg_unwanted()
        con = epg_conn()
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        con.execute("VACUUM")
        con.commit()
        con.close()
        res["epg"] = f"ok (pruned {pruned})"
    except Exception as e:
        log.warning("Wartung epg: %s", e)
        res["epg"] = str(e)

    # 4. Verlauf (journal.json) begrenzen auf max. 300 Einträge
    try:
        j = load_json("journal.json", [])
        if isinstance(j, list) and len(j) > 300:
            save_json("journal.json", j[-300:])
            res["journal"] = f"gekürzt auf 300 (vorher {len(j)})"
        else:
            res["journal"] = "ok"
    except Exception as e:
        res["journal"] = str(e)

    log.info("Nächtliche Wartung abgeschlossen: %s", res)
    return res


def backup_scheduler() -> None:
    """Jede Nacht um 03:30 eine Sicherung (vor dem Abgleich)."""
    last = None
    while True:
        try:
            now = datetime.now(tz())
            if now.hour == 3 and now.minute >= 30 and last != now.date():
                last = now.date()
                make_backup("nachts")
                offsite_request()
                nightly_maintenance()
        except Exception as e:
            log.error("Sicherung: %s", e)
        time.sleep(60)


# ---------------------------------------------------------------- Verwaltung (nur 127.0.0.1 bzw. Tailscale)
TS_NETS = (ipaddress.ip_network("100.64.0.0/10"), ipaddress.ip_network("fd7a:115c:a1e0::/48"))


def admin_ip_ok(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return False
    if a.is_loopback or (a.version == 6 and a.ipv4_mapped and a.ipv4_mapped.is_loopback):
        return True
    return config.get("admin_remote") == "tailscale" and any(a in n for n in TS_NETS)


def admin_bind() -> str:
    host, port = config["admin_listen"].rsplit(":", 1)
    return f"0.0.0.0:{port}" if config.get("admin_remote") == "tailscale" else config["admin_listen"]

ADMIN_HTML = os.path.join(HOME, "admin.html")


class AdminHandler(BaseHTTPRequestHandler):
    timeout = 120  # M7: 120 s Zeitgrenze für Verwaltung

    def log_message(self, fmt, *args):
        pass

    def handle_one_request(self):
        try:
            super().handle_one_request()
        except (BrokenPipeError, ConnectionResetError, TimeoutError, socket.timeout, ConnectionAbortedError):
            self.close_connection = True

    def allowed(self) -> bool:
        """Die Verwaltung antwortet nur dem eigenen Server (SSH-Tunnel) – und, wenn eingeschaltet, Geräten im eigenen Tailscale-Netz."""
        if admin_ip_ok(self.client_address[0]):
            return True
        self.send(403, {"error": "Kein Zugriff"})
        return False

    def send(self, code, obj=None, body=None, ctype="application/json; charset=utf-8"):
        if body is None:
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        _tl.draft = True
        if not self.allowed():
            return
        u = urllib.parse.urlsplit(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        if u.path in ("/", "/index.html"):
            with open(ADMIN_HTML, "rb") as f:
                return self.send(200, body=f.read(), ctype="text/html; charset=utf-8")
        if u.path.startswith("/logos/"):
            return serve_logo(self, u.path[7:])
        if u.path.startswith("/ui/"):
            name = u.path[4:]
            types = {".js": "text/javascript; charset=utf-8", ".woff2": "font/woff2", ".jpg": "image/jpeg", ".webp": "image/webp", ".png": "image/png"}
            ext = os.path.splitext(name)[1]
            fp = os.path.join(HOME, "ui", name)
            if not re.fullmatch(r"[a-z0-9-]+\.[a-z0-9]+", name) or ext not in types or not os.path.isfile(fp):
                return self.send(404, {"error": "?"})
            with open(fp, "rb") as f:
                return self.send(200, body=f.read(), ctype=types[ext])
        if u.path == "/api/panel":
            pc = panel_cfg()
            return self.send(200, {"url": pc["url"], "enabled": pc["enabled"], "has_key": bool(pc["api_key"]), "sync_exp": pc["sync_exp"],
                                   "low_credits": pc["low_credits"], "state": panel_state, "lines": panel_lines})
        if u.path == "/api/panel_bouquets":
            try:
                pc = panel_cfg()
                if not pc["api_key"]:
                    raise PanelError("Kein API-Key eingetragen")
                if not guard_allow("P", "own", "Panel bouquet"):
                    raise PanelError("Anfragen-Wächter: gerade pausiert")
                url = pc["url"] + "?" + urllib.parse.urlencode({"action": "bouquet", "api_key": pc["api_key"]})
                with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Onyx Merge)"}), timeout=30) as r:
                    data = json.loads(r.read(1 << 20).decode("utf-8", "replace"))
                return self.send(200, [{"id": str(x.get("id")), "name": str(x.get("name"))} for x in data if isinstance(x, dict)])
            except PanelError as e:
                return self.send(400, {"error": str(e)})
            except Exception as e:
                return self.send(502, {"error": f"Pakete konnten nicht geladen werden ({type(e).__name__})"})
        if u.path == "/api/state":
            prov = {}
            for k, p in config["providers"].items():
                prov[k] = {**{x: p.get(x) for x in ("name", "url", "kinds", "sync_user", "epg", "panel_url")},
                           "has_pass": bool(p.get("sync_pass")), "status": status.get(k, {})}
            return self.send(200, {"providers": prov, "sync_running": sync_state["running"],
                                   "settings": {k: config.get(k) for k in ("sync_time", "new_categories_visible",
                                                                           "public_host", "domains", "fallback", "support_contact")},
                                   "domain_status": load_json("domains.status.json", {}),
                                   "stats_since": stats_since(),
                                   "all_domains": all_domains(),
                                   "guard": guard_state(),
                                   "guard_limits": {k: config.get(k) for k in ("guard_limit_own", "guard_limit_passthrough", "guard_pause_min")},
                                   "gen_domains": {"A": gen_domains("A"), "B": gen_domains("B")},
                                   "requests": upstream_count})
        if u.path == "/api/categories":
            kind = q.get("kind", "live")
            with lock:
                cats = view.get(kind, {}).get("cats", [])
                items = view.get(kind, {}).get("items", {})
                nc = changes["newcats"].get(kind, {})
                pl = plays_30d(kind)
                ik = "series_id" if kind == "series" else "stream_id"
                def tstat(vid):
                    ok = bad = 0
                    for o in items.get(vid, []):
                        tt = tests.get(f"{kind}:{o[ik]}")
                        if tt:
                            ok += tt.get("s") == "ok"
                            bad += tt.get("s") == "bad"
                    return {"t_ok": ok, "t_bad": bad, "total": len(items.get(vid, []))}
                cat_by_vid = {c["vid"]: c for c in cats}
                cat_src = curation.get("cat_sources", {}).get(kind, {})
                custom_cats = curation.get("custom", {}).get(kind, [])
                master_map = {}
                absorbed_map = {}
                for t_vid, s_list in cat_src.items():
                    t_c = cat_by_vid.get(t_vid)
                    t_name = t_c.get("name") or t_vid if t_c else t_vid
                    for s in s_list:
                        s_c = cat_by_vid.get(s)
                        s_name = s_c.get("name") or s if s_c else s
                        s_pkey = s_c.get("pkey") or "" if s_c else ""
                        master_map.setdefault(t_vid, []).append({"vid": s, "name": s_name, "pkey": s_pkey})
                        absorbed_map[s] = {"vid": t_vid, "name": t_name}
                for cc in custom_cats:
                    t_vid = cc.get("vid")
                    t_name = cc.get("name") or t_vid
                    for s in cc.get("sources") or []:
                        s_c = cat_by_vid.get(s)
                        s_name = s_c.get("name") or s if s_c else s
                        s_pkey = s_c.get("pkey") or "" if s_c else ""
                        if not any(x["vid"] == s for x in master_map.get(t_vid, [])):
                            master_map.setdefault(t_vid, []).append({"vid": s, "name": s_name, "pkey": s_pkey})
                        absorbed_map[s] = {"vid": t_vid, "name": t_name}
                out = [{**c, **tstat(c["vid"]), "cc": cat_cc(kind, c) or "", "count": sum(1 for o in items.get(c["vid"], []) if not o.get("_hide")), "new": c["vid"] in nc,
                        "plays": sum(pl.get(o[ik], 0) for o in items.get(c["vid"], [])),
                        "fused_sources": master_map.get(c["vid"], []),
                        "fused_into": absorbed_map.get(c["vid"])} for c in cats]
            return self.send(200, out)
        if u.path == "/api/users":
            return self.send(200, [{**x, "_v": uhash(x), "_token": speed_token(x["username"])} for x in users])
        if u.path == "/api/preview":
            kind = q.get("kind", "live") if q.get("kind") in KINDS else "live"
            uname = q.get("user", "")
            if uname:
                usr = next((x for x in users if x.get("username") == uname), None)
                if not usr:
                    return self.send(404, {"error": "Benutzer nicht gefunden"})
                pset, pkgs = user_providers(usr), user_packages(usr)
            else:
                pset = tuple(x for x in ("A", "B") if x in (q.get("prov") or "A,B").split(","))
                pkgs = tuple(sorted(x for x in (q.get("pkgs") or "").split(",") if x in view.get("packages", {})))
            if kind != "live" and "A" not in pset:
                return self.send(200, {"cats": [], "items": []})
            with lock:
                cats = visible_cats(kind, pset, pkgs)
                cat = q.get("cat") or ""
                items = list_items(kind, pset, cat or None, pkgs, rel=True)
                counts = {}
                for it in (items if not cat else list_items(kind, pset, None, pkgs)):
                    counts[it["category_id"]] = counts.get(it["category_id"], 0) + 1
                out_cats = [{"id": c["vid"], "name": c["name"], "pkey": c["pkey"], "count": counts.get(c["vid"], 0)}
                            for c in cats]
                if kind == "live":  # Live-Kategorien oben
                    out_cats = [{"id": c["category_id"], "name": c["category_name"], "pkey": "L", "count": counts.get(c["category_id"], 0)}
                                for c in list_categories("live", pset, pkgs) if is_livecat(c["category_id"])] + out_cats
                total = sum(n for k, n in counts.items() if not is_livecat(k))
            now_map = {}
            if kind == "live":
                con = epg_conn()
                tnow = int(time.time())
                idx = view.get("epg_index", {})
                for it in items[:400]:
                    ch = idx.get(dyn_real(it["stream_id"]) or 0)
                    if ch:
                        r = con.execute("SELECT title, start, stop FROM prog WHERE channel=? AND start<=? AND stop>? LIMIT 1",
                                        (ch, tnow, tnow)).fetchone()
                        if r:
                            now_map[it["stream_id"]] = {"title": r[0], "pct": int(100 * (tnow - r[1]) / max(1, r[2] - r[1]))}
                con.close()
            id_key = "series_id" if kind == "series" else "stream_id"
            out_items = [{"num": it.get("num"), "id": it[id_key], "name": it.get("name", ""),
                          "icon": it.get("stream_icon") or it.get("cover") or "", "cat": it.get("category_id"),
                          "pkey": "B" if kind == "live" and (dyn_real(it[id_key]) or 0) >= STREAM_OFFSET["B"] else "A",
                          "now": now_map.get(it[id_key])} for it in items[:3000]]
            return self.send(200, {"cats": out_cats, "items": out_items, "total": total, "providers": list(pset),
                                   "packages": list(pkgs)})
        if u.path == "/api/rules":
            return self.send(200, curation.get("rules", []))
        if u.path == "/api/package_from_state":
            name = str(data.get("name") or "").strip()
            if not name:
                return self.send(400, {"error": "Bitte einen Namen für das Paket angeben"})
            kinds_req = data.get("kinds")
            if not kinds_req or not isinstance(kinds_req, list):
                kinds_req = list(KINDS)
            kinds_valid = [k for k in kinds_req if k in KINDS]
            if not kinds_valid:
                return self.send(400, {"error": "Keine gültigen Kategorietypen"})

            with lock:
                pkgs = curation.setdefault("packages", [])
                pid = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "paket"
                seen = {p.get("id") for p in pkgs}
                base_pid = pid
                counter = 2
                while pid in seen:
                    pid = f"{base_pid}-{counter}"
                    counter += 1

                # Aktiven IST-Zustand sammeln: alle sichtbaren Kategorien (show == True)
                include_keys = []
                for k in kinds_valid:
                    cats = view.get(k, {}).get("cats", [])
                    for c in cats:
                        if c.get("show"):
                            include_keys.append(f"{k}:{c['vid']}")

                new_pkg = {
                    "id": pid,
                    "name": name,
                    "patterns": [],
                    "include": include_keys,
                    "exclude": [],
                    "kinds": kinds_valid
                }
                pkgs.append(new_pkg)
                self._label = f"Paket „{name}“ aus IST-Zustand gespeichert ({len(include_keys)} Kategorien)"
                build_view()

            return self.send(200, {
                "ok": True,
                "id": pid,
                "name": name,
                "count": len(include_keys),
                "counts": {k: sum(1 for x in include_keys if x.startswith(k + ":")) for k in kinds_valid}
            })
        if u.path == "/api/packages":
            with lock:
                mem = view.get("packages", {})
                out = []
                for pk in curation.get("packages", []):
                    m = mem.get(pk["id"], set())
                    out.append({**pk, "members": sorted(m),
                                "counts": {k: sum(1 for x in m if x.startswith(k + ":")) for k in KINDS},
                                "users": sum(1 for us in users if pk["id"] in (us.get("packages") or []))})
            return self.send(200, out)
        if u.path == "/api/templates":
            out = []
            for fn in sorted(os.listdir(TPL_DIR)):
                if fn.endswith(".json"):
                    t = load_json(os.path.join("templates", fn), {})
                    out.append({"id": fn[:-5], "name": t.get("name", fn[:-5]), "created": t.get("created", 0)})
            return self.send(200, out)
        if u.path == "/api/templates/export":
            tid = re.sub(r"[^a-z0-9_-]", "", q.get("id", ""))
            t = load_json(os.path.join("templates", tid + ".json"), None)
            if not t:
                return self.send(404, {"error": "Nicht gefunden"})
            body = json.dumps(t, ensure_ascii=False, indent=1).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Disposition", f'attachment; filename="onyx-vorlage-{tid}.json"')
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            return self.wfile.write(body)
        if u.path == "/api/changes":
            kind = q.get("kind", "live")
            out = []
            with lock:
                nw = changes["new"].get(kind, {})
                names = {c["vid"]: c["name"] for c in view.get(kind, {}).get("cats", [])}
                if nw:
                    for cat, lst in view.get(kind, {}).get("items", {}).items():
                        for o in lst:
                            v = item_key(kind, o)
                            if str(v) in nw:
                                out.append({"vid": v, "name": o.get("name", ""), "orig": o.get("_orig", ""), "pkey": o["_p"],
                                            "hide": bool(o.get("_hide")), "moved": o["_home"] != cat, "cat": cat,
                                            "icon": o.get("_icon") or o.get("stream_icon") or o.get("cover") or "",
                                            "custom_icon": bool(o.get("_icon")), "cat_name": names.get(cat, ""),
                                            "since": nw[str(v)]})
                out.sort(key=lambda x: (-x["since"], x["cat_name"], x["name"]))
                gone = [g for g in changes["gone"] if g["kind"] == kind][-100:][::-1]
                runs = changes["runs"][-1:] if changes["runs"] else []
            return self.send(200, {"items": out[:2000], "total": len(out), "cats": len(changes["newcats"].get(kind, {})),
                                   "gone": gone, "last": runs[0] if runs else None})
        if u.path == "/api/search":
            kind, ql = q.get("kind", "live"), (q.get("q") or "").strip().lower()
            out = []
            if len(ql) >= 2:
                with lock:
                    names = {c["vid"]: c["name"] for c in view.get(kind, {}).get("cats", [])}
                    for cat, lst in view.get(kind, {}).get("items", {}).items():
                        for o in lst:
                            if ql in (o.get("name") or "").lower() or ql in (o.get("_orig") or "").lower():
                                out.append({"vid": item_key(kind, o), "name": o.get("name", ""), "orig": o.get("_orig", ""),
                                            "pkey": o["_p"], "hide": bool(o.get("_hide")), "moved": o["_home"] != cat,
                                            "icon": o.get("_icon") or o.get("stream_icon") or o.get("cover") or "", "cat": cat,
                                            "custom_icon": bool(o.get("_icon")),
                                            "cat_name": names.get(cat, "")})
                                if len(out) >= 500:
                                    break
                        if len(out) >= 500:
                            break
            return self.send(200, out)
        if u.path == "/api/diag":
            return self.send(200, diagnose(min(168, max(1, int(q.get("hours") or 24)))))
        if u.path == "/api/diag_log":
            return self.send(200, diag_log(min(168, max(1, int(q.get("hours") or 24)))))
        if u.path == "/api/diag_user":
            return self.send(200, diag_user(q.get("user", "")))
        if u.path == "/api/variants":
            with lock:
                gs = variant_groups(q.get("kind", "live") if q.get("kind") in KINDS else "live", q.get("all") != "1")
            qq = (q.get("q") or "").strip().lower()
            if qq:
                gs = [g for g in gs if qq in g["base"] or any(qq in m["orig"].lower() for m in g["items"])]
            return self.send(200, {"groups": gs[:400], "total": len(gs)})
        if u.path == "/api/ops":
            pass_week = {}
            for e in passthru_list():
                pass_week[e["provider"]] = pass_week.get(e["provider"], 0) + e["week"]
            return self.send(200, {
                "health": {**health["now"], "hist": list(health["hist"]), "users": len(users),
                           "active_24h": sum(1 for a in activity.values() if time.time() - (a.get("t") or 0) < 86400)},
                "errors": {"counts": dict(err_counts), "recent": list(err_recent)},
                "endpoints": endpoint_stats(),
                "route": route_state, "egress": {k: egress_for(k) for k in config["providers"]}, "reserve_ips": config.get("reserve_ips") or [], "available_ips": server_ips(), "epg_ext": config.get("epg_ext") or {},
                "epg_ext_state": epg_ext_state, "sync_days": config.get("sync_days") or {}, "detail_days": config.get("detail_days") or {},
                "sync_time": config.get("sync_time"), "sync_running": sync_state["running"],
                "providers": {k: {"name": p.get("name"), "kinds": p.get("kinds", []), "epg": p.get("epg", True),
                                  "status": {x: status.get(k, {}).get(x) for x in ("last_ok", "last_error", "epg_ok", "epg_rows", "counts", "kind_ok", "requests_total", "running_since")},
                                  "guard_used": guard_used(k, "own"), "guard_pass": guard_used(k, "pass"),
                                  "paused_for": int(guard_paused(k)), "pass_week": pass_week.get(k, 0)}
                              for k, p in config["providers"].items()},
                "limits": {"own": config.get("guard_limit_own"), "pass": config.get("guard_limit_passthrough")}})
        if u.path == "/api/passthru":
            return self.send(200, passthru_list())
        if u.path == "/api/trash":
            return self.send(200, trash_list())
        if u.path == "/api/reminders":
            return self.send(200, reminders)
        if u.path == "/api/ipwatch":
            return self.send(200, {k: {**ip_status(k), "name": pname(k), "url": provider_url(k)} for k in config["providers"]})
        if u.path == "/api/draft":
            jn = sum(1 for e in journal if e.get("t", 0) > draft_state["published"])
            return self.send(200, {"dirty": draft_dirty(), "published": draft_state["published"], "changes": jn,
                                   "dirty_since": draft_state.get("dirty_since") or 0,
                                   "catalog_pending": draft_state["catalog_pending"], "enabled": config.get("draft_mode", True)})
        if u.path == "/api/logo_search":
            # Logos anderer Einträge zum Übernehmen – nur aus dem eigenen Speicher, keine Anfrage an einen Anbieter
            kind = q.get("kind") if q.get("kind") in KINDS else "live"
            qq = norm_text(q.get("q") or "").strip().lower()
            base = base_name(q.get("like") or "") if q.get("like") else ""
            seen, out = set(), []
            with lock:
                for lst in view.get(kind, {}).get("items", {}).values():
                    for o in lst:
                        icon = o.get("_icon") or o.get("stream_icon") or o.get("cover") or ""
                        if not icon or icon in seen:
                            continue
                        nm = o.get("name", "")
                        same = bool(base) and base_name(nm) == base
                        if qq and qq not in norm_text(nm).lower() and qq not in norm_text(o.get("_orig", "")).lower():
                            continue
                        if not qq and not same:
                            continue
                        seen.add(icon)
                        out.append({"icon": icon, "name": nm, "same": same, "custom": bool(o.get("_icon"))})
                        if len(out) >= 300:
                            break
            out.sort(key=lambda x: (not x["same"], x["name"].lower()))
            return self.send(200, out[:60])
        if u.path == "/api/separators":
            ck = ("sep", sum(len((catalog.get(pk, {}).get(k) or {}).get("items", [])) for pk in config["providers"] for k in KINDS))
            if _summary_cache.get("sep_k") != ck:
                ex, n = [], 0
                for pkey in config["providers"]:
                    for kind in KINDS:
                        for it in (catalog.get(pkey, {}).get(kind) or {}).get("items", []):
                            if is_separator(it.get("name", "")):
                                n += 1
                                if len(ex) < 8:
                                    ex.append(it.get("name", ""))
                _summary_cache.update({"sep_k": ck, "sep": (n, ex)})
            n, ex = _summary_cache["sep"]
            return self.send(200, {"enabled": bool(curation.get("hide_separators")), "count": n, "examples": ex})
        if u.path == "/api/bexp":
            return self.send(200, {"lines": bexp, "panel_url": config["providers"].get("B", {}).get("panel_url", ""),
                                   "enabled": config.get("bexp_check", True), **bexp_state})
        if u.path == "/api/offsite":
            return self.send(200, offsite_info())
        if u.path == "/api/weekly_report":
            return self.send(200, {"report": build_weekly_report()})
        if u.path == "/api/version":
            return self.send(200, {"version": VERSION, "changes": CHANGES, "admin_remote": config.get("admin_remote", "off"),
                                   "via_tailscale": not ipaddress.ip_address(self.client_address[0].split("%")[0]).is_loopback})
        if u.path == "/api/notify":
            n = notify_cfg()
            return self.send(200, {"enabled": n.get("enabled"), "has_token": bool(n.get("token")), "chat_id": n.get("chat_id"),
                                   "chat_name": n.get("chat_name"), "events": {k: n.get("events", {}).get(k, d) for k, (_, d) in NOTIFY_EVENTS.items()},
                                   "labels": {k: t for k, (t, _) in NOTIFY_EVENTS.items()}, "error": notify_state.get("_error", ""),
                                   "last": notify_state.get("_last", 0)})
        if u.path == "/api/clean_summary":
            kind = q.get("kind") if q.get("kind") in KINDS else "live"
            ck = (kind, view_gen[0])
            if _summary_cache.get("k") != ck:
                with lock:
                    out = {"countries": None,
                           "dups": sum(1 for g in dup_cat_groups(kind) if g["visible"] >= 2),
                           "names": sum(1 for p in junk_proposals(kind) if not p["exists"])}
                    try:
                        vf = variant_fill(False)
                        out["fill"] = vf["epg"] + vf["logo"]
                    except Exception:
                        out["fill"] = None
                _summary_cache.update({"k": ck, "v": out})
            return self.send(200, _summary_cache["v"])
        if u.path == "/api/user_log":
            name = q.get("user", "")
            return self.send(200, [e for e in user_log if not name or e["user"] == name][:200])
        if u.path == "/api/dup_cats":
            with lock:
                return self.send(200, dup_cat_groups(q.get("kind", "live") if q.get("kind") in KINDS else "live"))
        if u.path == "/api/name_junk":
            with lock:
                return self.send(200, junk_proposals(q.get("kind", "live") if q.get("kind") in KINDS else "live"))
        if u.path == "/api/countries":
            with lock:
                return self.send(200, {"countries": countries_overview(), "special": special_cats()})
        if u.path == "/api/variant_fill":
            with lock:
                return self.send(200, variant_fill(apply=False))
        if u.path == "/api/journal":
            return self.send(200, [{k: e[k] for k in ("id", "t", "text")} | {"n": len(e["diff"])} for e in journal[::-1]])
        if u.path == "/api/numbering":
            return self.send(200, curation.get("numbering") or {})
        if u.path == "/api/overview":
            return self.send(200, overview())
        if u.path == "/api/livecats":
            with lock:
                res = {c["id"]: [{"title": e["title"], "start": e["start"], "stop": e["stop"],
                                  "chans": [{"name": s["name"], "p": s["p"]} for s in e["cands"][:6]], "more": max(0, len(e["cands"]) - 6)}
                                 for e in c["events"][:80]] for c in live_state["cats"]}
            return self.send(200, {"cats": livecats_cfg(), "presets": LIVECAT_PRESETS, "computed": live_state["computed"],
                                   "results": res, "epg_rows": sum(int(st.get("epg_rows") or 0) for st in status.values())})
        if u.path == "/api/domain_check":
            return self.send(200, check_domains())
        if u.path == "/api/backups":
            return self.send(200, {"backups": list_backups(), "keep": KEEP})
        if u.path == "/api/backup_download":
            bp = backup_path(q.get("name", ""))
            if not bp:
                return self.send(404, {"error": "Sicherung nicht gefunden"})
            with open(bp, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "application/gzip")
            self.send_header("Content-Disposition", f'attachment; filename="onyx-merge-{os.path.basename(bp)}"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if u.path == "/api/activity":
            return self.send(200, activity)
        if u.path == "/api/playurl":
            # Nur die Adresse bauen – der VPS fragt dabei NICHTS beim Anbieter an.
            # Abgespielt wird im Browser auf deinem PC, also mit deiner eigenen IP.
            kind = q.get("kind", "live")
            if kind not in ("live", "vod"):
                return self.send(400, {"error": "Nur Live-TV und Filme lassen sich testen"})
            try:
                pkey, orig = split_vid(kind, int(q.get("vid", "")))
            except ValueError:
                return self.send(400, {"error": "vid"})
            cands = [x for x in users if (x.get(pkey) or {}).get("user")]
            sc = sync_creds(pkey)
            if sc["username"]:  # der Sync-Zugang des Anbieters taugt auch zum Testen – ohne einen Kunden zu belegen
                cands = [{"username": "__sync", pkey: {"user": sc["username"], "pass": sc["password"]}}] + cands
            usr = next((x for x in cands if x.get("username") == q.get("user")), cands[0] if cands else None)
            if not usr:
                return self.send(400, {"error": f"Keine Line bei {pname(pkey)} zum Testen – "
                                                "trag unter Einstellungen den Sync-Zugang ein oder leg einen Kunden mit Line an."})
            acc = usr[pkey]
            base = provider_url(pkey)
            qu, qp = urllib.parse.quote(acc["user"], safe=""), urllib.parse.quote(acc.get("pass", ""), safe="")
            if kind == "live":
                urls = {"ts": f"{base}/live/{qu}/{qp}/{orig}.ts", "m3u8": f"{base}/live/{qu}/{qp}/{orig}.m3u8"}
            else:
                ext = "mp4"
                with lock:
                    for it in catalog.get("A", {}).get("vod", {}).get("items", []):
                        if str(it.get("stream_id")) == str(orig):
                            ext = re.sub(r"[^A-Za-z0-9]", "", str(it.get("container_extension") or "mp4")) or "mp4"
                            break
                urls = {"file": f"{base}/movie/{qu}/{qp}/{orig}.{ext}", "ext": ext}
            return self.send(200, {"pkey": pkey, "user": usr["username"], "line": acc["user"],
                                   "users": [x["username"] for x in cands], **urls})
        if u.path == "/api/channels":
            kind, cat = q.get("kind", "live"), q.get("cat", "")
            with lock:
                lst = view.get(kind, {}).get("items", {}).get(cat, [])
                out = [{"vid": item_key(kind, o), "name": o.get("name", ""), "orig": o.get("_orig", ""), "auto": o.get("_auto", ""),
                        "pkey": o["_p"], "hide": bool(o.get("_hide")), "moved": o["_home"] != cat,
                        "icon": o.get("_icon") or o.get("stream_icon") or o.get("cover") or "", "cat": cat,
                        "custom_icon": bool(o.get("_icon")), "home": o["_home"]} for o in lst]
                pl = plays_30d(kind)
                dr = drops_by_channel(24) if kind == "live" else {}
                for o in out:
                    o["plays"] = pl.get(o["vid"], 0)
                    o["drops"] = dr.get(o["vid"], 0)
                    tt = tests.get(f"{kind}:{o['vid']}")
                    if tt:
                        o["test"], o["tested"] = tt.get("s"), tt.get("t")
            return self.send(200, out)
        self.send(404, {"error": "?"})

    def panel_post(self, path: str, data: dict) -> dict:
        pc = panel_cfg()
        if path == "/api/panel_settings":
            url = str(data.get("url") or pc["url"]).strip()
            if not re.fullmatch(r"https?://[A-Za-z0-9.-]+(:\d+)?/[^\s?#]*", url):
                raise PanelError("Ungültige API-Adresse")
            pc["url"] = url
            if data.get("api_key"):
                pc["api_key"] = str(data["api_key"]).strip()
            if data.get("remove_key"):
                pc["api_key"] = ""
            pc["enabled"] = bool(data.get("enabled", pc["enabled"])) and bool(pc["api_key"])
            pc["sync_exp"] = bool(data.get("sync_exp", pc["sync_exp"]))
            pc["low_credits"] = max(0, min(1000, int(data.get("low_credits") or pc["low_credits"])))
            save_json("config.json", config)
            return {"ok": True, "enabled": pc["enabled"], "has_key": bool(pc["api_key"])}
        if path == "/api/panel_test":
            return {"ok": True, **panel_reseller()}
        if path == "/api/panel_refresh":
            if data.get("user"):
                u, acc = panel_user(str(data["user"]))
                return {"ok": True, "line": acc["user"], "info": panel_line_info(acc["user"], acc.get("pass", ""))}
            return {"ok": True, **panel_refresh_all()}
        if path == "/api/panel_renew":
            months = int(data.get("months") or 0)
            if months not in (1, 3, 6, 12):
                raise PanelError("Laufzeit muss 1, 3, 6 oder 12 Monate sein")
            u, acc = panel_user(str(data.get("user") or ""))
            before = panel_state.get("credits")
            d = panel_call({"action": "renew", "type": "m3u", "username": acc["user"], "password": acc.get("pass", ""), "sub": months})
            info = panel_line_info(acc["user"], acc.get("pass", ""))
            try:
                panel_reseller()
            except PanelError:
                pass
            log.info("Panel: %s (%s) um %d Monate verlängert", u["username"], acc["user"], months)
            ulog(u["username"], f"Im Panel um {months} {'Monat' if months == 1 else 'Monate'} verlängert" + (f" – läuft bis {info.get('expire')}" if info.get("expire") else ""))
            return {"ok": True, "message": d.get("message") or d.get("messasge") or "", "info": info,
                    "credits_before": before, "credits": panel_state.get("credits")}
        if path == "/api/panel_new":
            months = int(data.get("months") or 0)
            if months not in (1, 3, 6, 12):
                raise PanelError("Laufzeit muss 1, 3, 6 oder 12 Monate sein")
            pack = str(data.get("pack") or "").strip()
            if not pack:
                raise PanelError("Bitte ein Paket wählen")
            country = str(data.get("country") or "ALL").upper()
            if not re.fullmatch(r"ALL|[A-Z]{2}", country):
                raise PanelError("Land: ALL oder zwei Buchstaben")
            before = panel_state.get("credits")
            d = panel_call({"action": "new", "type": "m3u", "sub": months, "pack": pack, "country": country,
                            "notes": str(data.get("notes") or "")[:60]})
            line, pw = parse_m3u_url(d.get("url", ""))
            if not line:
                raise PanelError("Line wurde angelegt, aber das Panel hat keine Zugangsdaten zurückgegeben – bitte im Panel nachsehen.")
            try:
                panel_line_info(line, pw)
                panel_reseller()
            except PanelError:
                pass
            log.info("Panel: neue Line %s angelegt (%d Monate)", line, months)
            return {"ok": True, "line": line, "pass": pw, "user_id": str(d.get("user_id") or ""),
                    "credits_before": before, "credits": panel_state.get("credits")}
        if path == "/api/panel_status":
            u, acc = panel_user(str(data.get("user") or ""))
            info = panel_lines.get(acc["user"]) or panel_line_info(acc["user"], acc.get("pass", ""))
            if not info.get("user_id"):
                raise PanelError("Die Line-ID ist unbekannt – erst „Aktualisieren“")
            want = "enable" if data.get("enable") else "disable"
            panel_call({"action": "device_status", "status": want, "id": info["user_id"]})
            ulog(u["username"], "Im Panel " + ("entsperrt" if want == "enable" else "gesperrt"))
            return {"ok": True, "info": panel_line_info(acc["user"], acc.get("pass", ""))}
        raise PanelError("Unbekannte Panel-Aktion")

    def do_POST(self):
        _tl.draft = True
        if not self.allowed():
            return
        path = urllib.parse.urlsplit(self.path).path
        if path in JOURNAL_PATHS or path == "/api/journal_undo":
            before = cur_flat()
            self._label = JOURNAL_PATHS.get(path, "")
            try:
                return self._do_POST()
            finally:
                try:
                    journal_record(before, getattr(self, "_label", ""))
                except Exception as e:
                    log.warning("Verlauf: %s", e)
        return self._do_POST()

    def _do_POST(self):
        global users
        u = urllib.parse.urlsplit(self.path)
        if u.path == "/api/logo_upload":
            n = int(self.headers.get("Content-Length") or 0)
            if not 0 < n <= 3 * 1024 * 1024:
                return self.send(400, {"error": "Bild zu groß (max. 3 MB)"})
            raw = self.rfile.read(n)
            ext = sniff_image(raw)
            if not ext:
                return self.send(400, {"error": "Nur PNG, JPG, WebP oder GIF"})
            import hashlib
            name = hashlib.sha1(raw).hexdigest()[:16] + ext
            with open(os.path.join(LOGO_DIR, name), "wb") as f:
                f.write(raw)
            return self.send(200, {"ok": True, "icon": "/logos/" + name})
        try:
            data = self.body()
        except Exception:
            return self.send(400, {"error": "Ungültige Daten"})
        if u.path == "/api/provider":
            k = data.get("key")
            if k not in config["providers"]:
                return self.send(400, {"error": "Unbekannter Anbieter"})
            p = config["providers"][k]
            for f in ("name", "url", "sync_user", "panel_url"):
                if f in data:
                    p[f] = str(data[f]).strip()
            if p.get("panel_url") and not re.match(r"https?://", p["panel_url"]):
                p["panel_url"] = "https://" + p["panel_url"]
            if data.get("sync_pass"):
                p["sync_pass"] = str(data["sync_pass"])
            if "epg" in data:
                p["epg"] = bool(data["epg"])
            save_json("config.json", config)
            # Erster Abgleich automatisch, sobald ein Sync-Zugang da ist (danach nur noch nachts).
            first = p.get("sync_user") and p.get("sync_pass") and not status.get(k, {}).get("last_ok")
            if first and not sync_state["running"]:
                threading.Thread(target=run_sync, args=(k,), daemon=True).start()
            return self.send(200, {"ok": True, "first_sync": bool(first)})
        if u.path == "/api/domains":
            raw = data.get("domains") or {}
            if isinstance(raw, list):
                raw = {"A": raw}
            out, bad = {"A": [], "B": []}, []
            for pk in ("A", "B"):
                for d in raw.get(pk) or []:
                    d = norm_domain(d)
                    if not d:
                        continue
                    if not DOMAIN_RE.match(d):
                        bad.append(d)
                    elif d not in out[pk]:
                        out[pk].append(d)
            if bad:
                return self.send(400, {"error": "Keine gültige Domain: " + ", ".join(bad)})
            config["domains"] = out
            if "fallback" in data:
                config["fallback"] = bool(data["fallback"])
            flat = out["A"] + out["B"]
            if flat and (not config.get("public_host") or config["public_host"] not in flat):
                config["public_host"] = flat[0]
            save_json("config.json", config)
            # Der Helfer (läuft als root) bemerkt die Änderung dieser Datei und stellt Nginx um.
            write_domains_file()
            return self.send(200, {"ok": True, "domains": out})
        if u.path.startswith("/api/panel_"):
            try:
                return self.send(200, self.panel_post(u.path, data))
            except PanelError as e:
                return self.send(400, {"error": str(e)})
        if u.path == "/api/variants_apply":
            pref = data.get("pref") or {}
            keys = set(data.get("keys") or []) or None
            with lock:
                plan = plan_variants(pref, keys)
            if data.get("dry"):
                return self.send(200, {"groups": plan["groups"], "hide": len(plan["hide"]), "keep": len(plan["keep"])})
            set_hidden("live", plan["hide"], True)
            return self.send(200, {"ok": True, "groups": plan["groups"], "hide": len(plan["hide"])})
        if u.path == "/api/variant_fill":
            with lock:
                r = variant_fill(apply=True, what=set(data.get("what") or ["epg", "logo"]))
            build_view()
            return self.send(200, r)
        if u.path == "/api/unfuse_cat":
            kind = data.get("kind")
            target = str(data.get("target") or "").strip()
            source = str(data.get("source") or "").strip()
            if kind not in KINDS or not target or not source:
                return self.send(400, {"error": "Parameter kind, target und source erforderlich."})
            with lock:
                ok = unfuse_category(kind, target, source)
            self._label = f"Kategorie {source} von {target} getrennt"
            build_view((kind,))
            return self.send(200, {"ok": ok, "target": target, "source": source})
        if u.path == "/api/match_logos":
            kind = data.get("kind", "live")
            if kind not in KINDS:
                return self.send(400, {"error": "kind"})
            cat = str(data.get("cat") or "")
            vids = data.get("vids")
            if vids is not None and not isinstance(vids, (list, tuple)):
                return self.send(400, {"error": "vids"})
            vids_set = {int(v) for v in vids} if vids else None
            preview_only = bool(data.get("preview"))

            with lock:
                matches, donors = find_logo_matches_in_view(kind=kind, cat=cat, vids_set=vids_set)
                chan = curation.setdefault("channels", {})
                applied_count = 0
                if not preview_only and matches:
                    for m_item in matches:
                        vid = m_item["vid"]
                        icon_url = m_item["logo"]
                        if icon_url:
                            chan.setdefault(f"{kind}:{vid}", {})["icon"] = icon_url
                            applied_count += 1
                    if applied_count:
                        self._label = f"{applied_count} Logos automatisch zugewiesen"
                        changes_seen(kind, vids=[m_item["vid"] for m_item in matches])
                        build_view((kind,))

            return self.send(200, {
                "ok": True,
                "count": len(matches),
                "applied": applied_count if not preview_only else 0,
                "donors_available": len(donors),
                "items": matches[:60],
                "total": len(matches)
            })
        if u.path == "/api/clean_names":
            kind = data.get("kind", "live")
            if kind not in KINDS:
                return self.send(400, {"error": "kind"})
            cat = str(data.get("cat") or "")
            vids = data.get("vids")
            if vids is not None and not isinstance(vids, (list, tuple)):
                return self.send(400, {"error": "vids"})
            vids_set = {int(v) for v in vids} if vids else None
            options = data.get("options") or {}
            preview_only = bool(data.get("preview"))

            with lock:
                items_in_cat = list(view.get(kind, {}).get("items", {}).get(cat, [])) if cat else [
                    it for lst in view.get(kind, {}).get("items", {}).values() for it in lst
                ]
                chan = curation.setdefault("channels", {})
                cleaned_items = []
                for it in items_in_cat:
                    vid = item_key(kind, it)
                    if vids_set is not None and vid not in vids_set:
                        continue
                    cur_name = it.get("name", "")
                    cleaned = clean_item_name(cur_name, kind=kind, options=options)
                    if cleaned and cleaned != cur_name:
                        cleaned_items.append({"vid": vid, "orig": cur_name, "new": cleaned})
                        if not preview_only:
                            chan.setdefault(f"{kind}:{vid}", {})["name"] = cleaned

                if not preview_only and cleaned_items:
                    self._label = f"{len(cleaned_items)} Namen bereinigt"
                    changes_seen(kind, vids=[c["vid"] for c in cleaned_items])
                    build_view((kind,))

            return self.send(200, {"ok": True, "count": len(cleaned_items), "items": cleaned_items[:50], "total": len(cleaned_items)})
        if u.path == "/api/fuse_cats":
            kind = data.get("kind")
            target = str(data.get("target") or "").strip()
            sources = [str(s).strip() for s in data.get("sources") or [] if str(s).strip() and str(s).strip() != target]
            name = str(data.get("name") or "").strip()
            if kind not in KINDS or not target or not sources:
                return self.send(400, {"error": "Ungültige Parameter: kind, target und mindestens eine Quellkategorie erforderlich."})
            with lock:
                moved = fuse_categories(kind, target, sources, name)
            self._label = f"Kategorien fusioniert in „{name or target}“"
            build_view((kind,))
            return self.send(200, {"ok": True, "target": target, "moved": moved})
        if u.path == "/api/merge_cats":
            kind, vids, name = data.get("kind"), [str(v) for v in data.get("vids") or []], str(data.get("name") or "").strip()
            if kind not in KINDS or len(vids) < 2 or not name:
                return self.send(400, {"error": "Mindestens zwei Kategorien und einen Namen angeben."})
            with lock:
                new_vid = merge_categories(kind, vids, name)
            self._label = f"„{name}“ aus {len(vids)} Kategorien"
            build_view()
            moved = len(view.get(kind, {}).get("items", {}).get(new_vid, []))
            return self.send(200, {"ok": True, "vid": new_vid, "moved": moved})
        if u.path == "/api/merge_dups":
            kind, groups = data.get("kind"), data.get("groups") or []
            if kind not in KINDS:
                return self.send(400, {"error": "kind"})
            done = 0
            with lock:
                for g in groups:
                    vids, name = [str(v) for v in g.get("vids") or []], str(g.get("name") or "").strip()
                    if len(vids) >= 2 and name:
                        merge_categories(kind, vids, name)
                        done += 1
            self._label = f"{done} doppelte Kategorien zusammengefasst"
            build_view()
            return self.send(200, {"ok": True, "merged": done})
        if u.path == "/api/numbering":
            out = {}
            for k, v in (data.get("numbering") or {}).items():
                try:
                    if v not in (None, "", 0) and 1 <= int(v) <= 99999:
                        out[str(k)] = int(v)
                except (TypeError, ValueError):
                    return self.send(400, {"error": f"Ungültige Nummer: {v}"})
            with lock:
                curation["numbering"] = out
            build_view()
            return self.send(200, {"ok": True, "numbering": out})
        if u.path == "/api/journal_undo":
            try:
                txt = journal_undo(str(data.get("id") or ""))
            except ValueError as e:
                return self.send(404, {"error": str(e)})
            self._label = "Rückgängig"
            return self.send(200, {"ok": True, "text": txt})
        if u.path == "/api/wizard":
            try:
                res = run_wizard(data, dry=bool(data.get("dry")))
            except ValueError as e:
                return self.send(400, {"error": str(e)})
            return self.send(200, res)
        if u.path in ("/api/livecats", "/api/livecat_preview"):
            def clean(x, num):
                words = [str(w).strip() for w in (x.get("words") or []) if str(w).strip()][:200]
                return {"id": re.sub(r"[^a-z0-9-]", "", str(x.get("id") or "")) or secrets.token_hex(4), "num": num,
                        "name": (str(x.get("name") or "").strip() or "Heute live")[:60], "enabled": bool(x.get("enabled", True)),
                        "words": words, "exclude": [str(w).strip() for w in (x.get("exclude") or []) if str(w).strip()][:200],
                        "hours": min(48, max(1, int(x.get("hours") or 18))), "desc": bool(x.get("desc")),
                        "max_per_event": min(10, max(1, int(x.get("max_per_event") or 2)))}
            if u.path == "/api/livecat_preview":
                lc = clean(data.get("cat") or {}, 0)
                with lock:
                    idx = live_channel_index()
                evs = match_events(lc, idx)
                return self.send(200, {"results": [{"title": e["title"], "start": e["start"], "stop": e["stop"],
                                                    "chans": [{"name": s["name"], "p": s["p"]} for s in e["cands"][:6]],
                                                    "more": max(0, len(e["cands"]) - 6)} for e in evs[:80]], "total": len(evs)})
            old = {c.get("id"): c.get("num") for c in livecats_cfg()}
            used = {n for n in old.values() if n}
            out = []
            for x in (data.get("cats") or [])[:20]:
                num = old.get(x.get("id"))
                if not num:
                    num = next(n for n in range(1, 999) if n not in used)
                    used.add(num)
                out.append(clean(x, num))
            with lock:
                curation["livecats"] = out
                save_json("curation.json", curation)
            compute_livecats()
            return self.send(200, {"ok": True, "cats": out})
        if u.path == "/api/maintenance":
            return self.send(200, nightly_maintenance())
        if u.path == "/api/send_weekly_report":
            rep = build_weekly_report()
            if notify_cfg().get("enabled"):
                tg_send(rep)
                return self.send(200, {"ok": True, "report": rep})
            return self.send(400, {"error": "Telegram ist nicht aktiviert."})
        if u.path == "/api/backup":
            return self.send(200, {"ok": True, "name": make_backup("hand")})
        if u.path == "/api/backup_restore":
            try:
                before = restore_backup(str(data.get("name") or ""))
            except ValueError as e:
                return self.send(400, {"error": str(e)})
            return self.send(200, {"ok": True, "before": before})
        if u.path == "/api/guard":
            if data.get("resume") in config["providers"]:
                guard_resume(data["resume"])
            for f, lo, hi in (("guard_limit_own", 20, 2000), ("guard_limit_passthrough", 0, 20000), ("guard_pause_min", 10, 1440)):
                if f in data:
                    try:
                        config[f] = max(lo, min(hi, int(data[f])))
                    except (TypeError, ValueError):
                        return self.send(400, {"error": f"Ungültige Zahl: {f}"})
            save_json("config.json", config)
            guard_save()
            return self.send(200, {"ok": True, "guard": guard_state()})
        if u.path == "/api/settings":
            for f in ("sync_time", "public_host", "support_contact"):
                if f in data:
                    config[f] = str(data[f]).strip()[:200]
            if "new_categories_visible" in data:
                config["new_categories_visible"] = bool(data["new_categories_visible"])
            save_json("config.json", config)
            return self.send(200, {"ok": True})
        if u.path == "/api/changes_seen":
            kind = data.get("kind")
            if kind not in KINDS:
                return self.send(400, {"error": "kind"})
            changes_seen(kind, data.get("vids"), data.get("cats"), bool(data.get("all")))
            return self.send(200, {"ok": True})
        if u.path == "/api/sync":
            which = data.get("key")
            left = guard_paused(which or "A")
            if left:
                return self.send(429, {"error": f"Der Anfragen-Wächter hat diesen Anbieter noch {int(left // 60) + 1} Minuten "
                                                "pausiert. Erst danach (oder nach „Pause aufheben“) abgleichen."})
            st = status.get(which or "A", {})
            if not data.get("force") and time.time() - st.get("last_ok", 0) < 1800:
                return self.send(429, {"error": "Letzte Synchronisation ist keine 30 Minuten her – bitte warten "
                                                "(schützt vor einer Sperre)."})
            threading.Thread(target=run_sync, args=(which, data.get("full", True) is not False), daemon=True).start()
            return self.send(200, {"ok": True})
        if u.path == "/api/ops_settings":
            if "egress" in data:
                eg = {}
                for k in config["providers"]:
                    ip = str((data["egress"] or {}).get(k) or "").strip()
                    if ip and not re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", ip):
                        return self.send(400, {"error": f"Anbieter {k}: bitte eine IPv4-Adresse wie 51.68.192.142 eintragen – oder leer lassen."})
                    eg[k] = ip
                config["egress"] = eg
                _bindable.clear()
            if "reserve_ips" in data:
                raw_rips = data.get("reserve_ips")
                if isinstance(raw_rips, str):
                    raw_rips = [x.strip() for x in raw_rips.split(",") if x.strip()]
                elif not isinstance(raw_rips, list):
                    raw_rips = []
                clean_rips = []
                for rip in raw_rips:
                    rip = str(rip).strip()
                    if rip and re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", rip) and rip not in clean_rips:
                        clean_rips.append(rip)
                config["reserve_ips"] = clean_rips
            if "epg_ext" in data:
                e = data["epg_ext"] or {}
                mode = e.get("mode") if e.get("mode") in ("off", "fill", "only") else "off"
                url = str(e.get("url") or "").strip()
                if mode != "off":
                    err = epg_ext_url_ok(url)
                    if err:
                        return self.send(400, {"error": err})
                config["epg_ext"] = {"mode": mode, "url": url}
            if "sync_days" in data:
                config["sync_days"] = {k: max(1, min(14, int((data["sync_days"] or {}).get(k) or 1))) for k in KINDS}
            if "detail_days" in data:
                config["detail_days"] = {k: max(1, min(60, int((data["detail_days"] or {}).get(k) or 1))) for k in ("vod", "series")}
            save_json("config.json", config)
            threading.Thread(target=route_check, daemon=True).start()
            return self.send(200, {"ok": True})
        if u.path == "/api/route_check":
            return self.send(200, route_check())
        if u.path == "/api/epg_ext_run":
            if sync_state["running"]:
                return self.send(409, {"error": "Gerade läuft ein Abgleich – danach nochmal."})
            if not (config.get("epg_ext") or {}).get("url"):
                return self.send(400, {"error": "Erst eine Adresse eintragen und speichern."})
            threading.Thread(target=run_epg_ext, daemon=True).start()
            return self.send(200, {"ok": True})
        if u.path == "/api/hide_all":
            kinds = [k for k in (data.get("kinds") or []) if k in KINDS] or list(KINDS)
            changed = 0
            with lock:
                save_json(os.path.join("templates", "_vor-alles-aus.json"),
                          {"name": "Automatisch: Stand vor „Alles ausblenden“", "created": int(time.time()), "curation": json.loads(json.dumps(curation))})
                for kind in kinds:
                    for c in view.get(kind, {}).get("cats", []):
                        if c["pkey"] != "C" and c["show"]:
                            curation.setdefault(kind, {}).setdefault(c["vid"], {})["show"] = False
                            changed += 1
                config["new_categories_visible"] = False  # Neue Kategorien der Anbieter kommen ab jetzt ausgeblendet
                save_json("config.json", config)
            self._label = "Alles ausgeblendet"
            build_view(tuple(kinds))
            return self.send(200, {"ok": True, "changed": changed})
        if u.path == "/api/country_show":
            show = bool(data.get("show"))
            changed = 0
            with lock:
                rx = re.compile(SPECIAL_CATS[data["special"]][0], re.I) if data.get("special") in SPECIAL_CATS else None
                code = str(data.get("code") or "").upper() if "code" in data else None
                for kind in KINDS:
                    for c in view.get(kind, {}).get("cats", []):
                        if c["pkey"] == "C" or c["show"] == show:
                            continue
                        if rx is not None:
                            hit = rx.search(c["orig"]) or rx.search(c["name"])
                        elif code is not None:
                            hit = (cat_cc(kind, c) or "") == code
                        else:
                            hit = False
                        if hit:
                            curation.setdefault(kind, {}).setdefault(c["vid"], {})["show"] = show
                            changed += 1
            self._label = ("Eingeblendet: " if show else "Ausgeblendet: ") + (data.get("code") or SPECIAL_CATS.get(data.get("special"), ("", "?"))[1] or "ohne Land")
            build_view()
            return self.send(200, {"ok": True, "changed": changed})
        if u.path == "/api/trash_restore":
            name = str(data.get("username") or "")
            with lock:
                x = next((x for x in trash if x["user"]["username"] == name), None)
                if not x:
                    return self.send(404, {"error": "Nicht mehr im Papierkorb."})
                if any(u["username"] == name for u in users):
                    return self.send(409, {"error": f"Den Login „{name}“ gibt es inzwischen wieder – erst umbenennen oder löschen."})
                users.append(x["user"])
                trash.remove(x)
                save_json("users.json", users)
                save_json("trash.json", trash)
                resp_cache.clear()
            write_domains_file()
            ulog(name, "Aus dem Papierkorb wiederhergestellt")
            return self.send(200, {"ok": True})
        if u.path == "/api/trash_purge":
            name = str(data.get("username") or "")
            with lock:
                trash[:] = [x for x in trash if name and x["user"]["username"] != name] if name else []
                save_json("trash.json", trash)
            return self.send(200, {"ok": True})
        if u.path == "/api/bexp_check":
            name = str(data.get("username") or "")
            usr = next((x for x in users if x["username"] == name), None)
            line, pw = bline_of(usr) if usr else (None, None)
            if not line:
                return self.send(400, {"error": f"Dieser Kunde hat keine Line bei {pname('B')}"})
            try:
                info = bline_check(line, pw)
            except GuardBlocked as e:
                return self.send(429, {"error": str(e)})
            if info.get("exp"):
                ulog(name, f"Zusatz-Laufzeit geprüft: gültig bis {info['exp']}")
            return self.send(200, info)
        if u.path == "/api/separators":
            with lock:
                curation["hide_separators"] = bool(data.get("enabled"))
                save_json("curation.json", curation)
            build_view()
            return self.send(200, {"ok": True})
        if u.path == "/api/testmark":
            kind, st = data.get("kind"), data.get("state")
            if kind not in KINDS or st not in ("ok", "bad", None):
                return self.send(400, {"error": "Ungültige Angabe"})
            now = int(time.time())
            with lock:
                for v in data.get("vids") or []:
                    key = f"{kind}:{int(v)}"
                    if st is None:
                        tests.pop(key, None)
                    else:
                        tests[key] = {"s": st, "t": now}
                save_json("tests.json", tests)
            return self.send(200, {"ok": True})
        if u.path == "/api/switch_egress":
            pkey = data.get("provider")
            if pkey not in config["providers"]:
                return self.send(400, {"error": "Unbekannter Anbieter"})
            new_ip = str(data.get("ip") or "").strip()
            if new_ip and not re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", new_ip):
                return self.send(400, {"error": "Ungültiges IP-Format. Bitte IPv4 oder leer für Haupt-IP angeben."})
            
            old_ip = egress_for(pkey) or "Haupt-IP"
            if new_ip:
                bindable, reason = test_bindable_ip(new_ip)
                if not bindable:
                    return self.send(400, {"error": f"Die IP {new_ip} liegt nicht auf diesem Server ({reason})."})
            
            eg = dict(config.get("egress") or {})
            eg[pkey] = new_ip
            config["egress"] = eg
            _bindable.clear()
            save_json("config.json", config)
            
            target_label = new_ip if new_ip else "Haupt-IP"
            log.info("Absender-IP für %s gewechselt: %s -> %s", pkey, old_ip, target_label)
            
            chk = ip_check(pkey)
            chk_text = chk.get("text") or ("Frei" if chk.get("verdict") == "free" else "Verdacht auf Sperre")
            notify("route", f"🔀 {pname(pkey)}: Absender-IP auf {target_label} umgestellt (vorher: {old_ip}).\nVerbindungstest: {chk_text}", key=f"egress-switch-{pkey}-{int(time.time())}", cooldown=0)
            
            return self.send(200, {
                "ok": True,
                "provider": pkey,
                "egress": new_ip,
                "label": target_label,
                "status": ip_status(pkey),
                "check": chk
            })
        if u.path == "/api/ipcheck":
            k = data.get("key")
            if k not in config["providers"]:
                return self.send(400, {"error": "Unbekannter Anbieter"})
            ip_check(k)
            return self.send(200, {**ip_status(k), "name": pname(k), "url": provider_url(k)})
        if u.path == "/api/publish":
            publish("Speichern im Admin")
            return self.send(200, {"ok": True, "published": draft_state["published"]})
        if u.path == "/api/discard":
            if not load_json("curation_pub.json", None):
                return self.send(400, {"error": "Kein gespeicherter Stand vorhanden"})
            discard_draft()
            return self.send(200, {"ok": True, "dirty": draft_dirty()})
        if u.path == "/api/sort_cat":
            kind, mode = data.get("kind"), data.get("mode")
            if kind not in KINDS or mode not in ("group", "az", "provider", "clean_az", "quality"):
                return self.send(400, {"error": "Ungültige Angabe"})
            with lock:
                n = sort_category(kind, str(data.get("cat") or ""), mode)
            self._label = {"group": "Varianten zusammen sortiert", "az": "A–Z sortiert", "clean_az": "A–Z (bereinigt) sortiert", "quality": "Nach Qualität sortiert", "provider": "Reihenfolge wie beim Anbieter"}[mode]
            build_view((kind,))
            return self.send(200, {"ok": True, "n": n})
        if u.path == "/api/bexp_settings":
            config["bexp_check"] = bool(data.get("enabled", True))
            save_json("config.json", config)
            return self.send(200, {"ok": True})
        if u.path == "/api/reminded":
            name, exp = str(data.get("username") or ""), str(data.get("exp") or "")
            with lock:
                if data.get("undo"):
                    reminders.pop(name, None)
                else:
                    reminders[name] = exp
                for k in [k for k in reminders if not any(x["username"] == k.split("|")[0] for x in users)]:
                    reminders.pop(k, None)
                save_json("reminders.json", reminders)
            if not data.get("undo"):
                ulog(name.split("|")[0], f"An den Ablauf {'der Zusatz-Line ' if name.endswith('|B') else ''}am {exp} erinnert")
            return self.send(200, {"ok": True})
        if u.path == "/api/offsite_settings":
            o = config.setdefault("offsite", json.loads(json.dumps(DEFAULT_CONFIG["offsite"])))
            if "dir" in data:
                d = str(data["dir"] or "").strip().rstrip("/")
                if not re.fullmatch(r"/mnt/[A-Za-z0-9._/-]+", d) or ".." in d:
                    return self.send(400, {"error": "Der Zielordner muss unter /mnt/ liegen, z. B. /mnt/storagebox/onyx-merge-backups"})
                o["dir"] = d
            if "keep" in data:
                o["keep"] = max(3, min(365, int(data["keep"] or 30)))
            if data.get("pass"):
                if len(str(data["pass"])) < 10:
                    return self.send(400, {"error": "Das Passwort für die Verschlüsselung sollte mindestens 10 Zeichen haben."})
                o["pass"] = str(data["pass"])
            if data.get("remove_pass"):
                o["pass"] = ""
            if "enabled" in data:
                o["enabled"] = bool(data["enabled"])
            save_json("config.json", config)
            return self.send(200, {"ok": True, **offsite_info()})
        if u.path == "/api/offsite_run":
            if not (config.get("offsite") or {}).get("enabled"):
                return self.send(400, {"error": "Erst einschalten und speichern."})
            make_backup("hand")
            offsite_request()
            return self.send(200, {"ok": True})
        if u.path == "/api/notify_settings":
            n = notify_cfg()
            if data.get("token"):
                tok = str(data["token"]).strip()
                if not re.fullmatch(r"\d{5,}:[A-Za-z0-9_-]{20,}", tok):
                    return self.send(400, {"error": "Das sieht nicht wie ein Bot-Schlüssel aus (Form: 123456789:ABC…)."})
                if tok != n.get("token"):
                    n.update({"token": tok, "chat_id": "", "chat_name": ""})
            if data.get("remove_token"):
                n.update({"token": "", "chat_id": "", "chat_name": "", "enabled": False})
            if "events" in data:
                n["events"] = {k: bool((data["events"] or {}).get(k)) for k in NOTIFY_EVENTS}
            if "enabled" in data:
                n["enabled"] = bool(data["enabled"]) and bool(n.get("token")) and bool(n.get("chat_id"))
            save_json("config.json", config)
            return self.send(200, {"ok": True, "enabled": n["enabled"]})
        if u.path == "/api/notify_findchat":
            try:
                d = tg_call("getUpdates", {"limit": 50, "timeout": 0})
            except Exception as e:
                return self.send(400, {"error": str(e)})
            chats = {}
            for upd in d.get("result", []):
                m = upd.get("message") or upd.get("edited_message") or {}
                c = m.get("chat") or {}
                if c.get("id") and c.get("type") == "private":
                    chats[str(c["id"])] = " ".join(x for x in [c.get("first_name"), c.get("last_name")] if x) or c.get("username") or str(c["id"])
            if not chats:
                return self.send(400, {"error": "Noch keine Nachricht gefunden. Öffne deinen Bot in Telegram, drück „Starten“ bzw. schreib „/start“ und versuch es dann nochmal."})
            n = notify_cfg()
            cid, name = list(chats.items())[-1]
            n.update({"chat_id": cid, "chat_name": name, "enabled": True})
            save_json("config.json", config)
            return self.send(200, {"ok": True, "chat_name": name, "count": len(chats)})
        if u.path == "/api/notify_test":
            try:
                tg_send("✅ Test von Onyx Merge – Benachrichtigungen funktionieren.")
                notify_state["_last"] = int(time.time())
                notify_state.pop("_error", None)
                save_json("notify_state.json", notify_state)
            except Exception as e:
                return self.send(400, {"error": str(e)})
            return self.send(200, {"ok": True})
        if u.path == "/api/ov_dismiss":
            dis = {k: v for k, v in load_json("ov_dismiss.json", {}).items() if time.time() - v.get("t", 0) < 30 * 86400}
            if data.get("reset"):
                dis = {}
            elif data.get("id"):
                dis[str(data["id"])[:20]] = {"t": int(time.time()), "until": 0 if data.get("forever") else int(time.time()) + 86400}
            save_json("ov_dismiss.json", dis)
            return self.send(200, {"ok": True})
        if u.path == "/api/passthru_adopt":
            r = passthru_adopt([str(k) for k in data.get("keys") or []], data.get("packages") or [], data.get("extra") or {})
            for name in r["adopted"]:  # Zusatz-Line gleich einmal prüfen
                usr = next((x for x in users if x["username"] == name), None)
                if usr and bline_of(usr)[0]:
                    threading.Thread(target=bline_check, args=bline_of(usr), daemon=True).start()
            self._label = f"{len(r['adopted'])} Zugänge übernommen"
            return self.send(200, r)
        if u.path == "/api/passthru_forget":
            with lock:
                for k in data.get("keys") or []:
                    passthru.pop(str(k), None)
                    
                save_json("passthru.json", passthru)
            return self.send(200, {"ok": True})
        if u.path == "/api/categories":
            kind = data.get("kind")
            if kind not in KINDS:
                return self.send(400, {"error": "kind"})
            with lock:
                cur = curation.setdefault(kind, {})
                for it in data.get("items", []):
                    vid = str(it.get("vid"))
                    st = cur.setdefault(vid, {})
                    if "show" in it:
                        st["show"] = bool(it["show"])
                    if "name" in it:
                        st["name"] = str(it["name"]).strip()
                    if "order" in it:
                        st["order"] = int(it["order"])
            changes_seen(kind, cats=[str(it.get("vid")) for it in data.get("items", []) if "show" in it or "name" in it])
            build_view((kind,))
            return self.send(200, {"ok": True})
        if u.path == "/api/channels":
            kind = data.get("kind")
            if kind not in KINDS:
                return self.send(400, {"error": "kind"})
            with lock:
                chan = curation.setdefault("channels", {})
                for it in data.get("items", []):
                    key = f"{kind}:{int(it['vid'])}"
                    st = chan.setdefault(key, {})
                    for f in ("cat", "name", "icon", "epg"):
                        if f in it:
                            st[f] = str(it[f] or "").strip()
                    if st.get("icon") and not re.fullmatch(r"/logos/[a-z0-9_-]+\.(png|jpg|webp|gif)|https?://\S+", st["icon"]):
                        st["icon"] = ""
                    if "hide" in it:
                        st["hide"] = bool(it["hide"])
                    if "order" in it:
                        st["order"] = None if it["order"] is None else int(it["order"])
                    if not any(st.get(f) for f in ("cat", "name", "hide", "icon", "epg")) and st.get("order") is None:
                        chan.pop(key, None)
            # Wer einen neuen Sender verschiebt, aus-/einblendet oder umbenennt, hat ihn gesehen
            changes_seen(kind, vids=[it["vid"] for it in data.get("items", []) if any(f in it for f in ("cat", "hide", "name"))])
            build_view((kind,))
            # Verschobene Sender landen gleich bei ihren Varianten: Ziel-Kategorie „Varianten zusammen“ sortieren
            moved = {int(it["vid"]) for it in data.get("items", []) if "cat" in it}
            if moved and config.get("auto_sort_moves", True):
                with lock:
                    targets = {vc for vc, lst in view.get(kind, {}).get("items", {}).items()
                               if any(item_key(kind, o) in moved for o in lst)}
                    for vc in targets:
                        place_near_variants(kind, vc, moved)
                if targets:
                    build_view((kind,))
            return self.send(200, {"ok": True})
        if u.path == "/api/packages":
            if not isinstance(data, list):
                return self.send(400, {"error": "Liste erwartet"})
            clean, seen = [], set()
            for pk in data:
                name = str(pk.get("name") or "").strip()
                if not name:
                    return self.send(400, {"error": "Jedes Paket braucht einen Namen"})
                pid = str(pk.get("id") or "") or re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "paket"
                while pid in seen:
                    pid += "-2"
                seen.add(pid)
                pats = pk.get("patterns") or []
                if isinstance(pats, str):
                    pats = [x.strip() for x in pats.split(",")]
                if pattern_regex(pats) is None and any(str(x).strip() for x in pats):
                    return self.send(400, {"error": f"Ungültiges Muster in „{name}“"})
                clean.append({"id": pid, "name": name, "patterns": [str(x).strip() for x in pats if str(x).strip()],
                              "include": [str(x) for x in pk.get("include", [])],
                              "exclude": [str(x) for x in pk.get("exclude", [])],
                              "kinds": [k for k in (pk.get("kinds") or list(KINDS)) if k in KINDS]})
            with lock:
                curation["packages"] = clean
            build_view()
            return self.send(200, {"ok": True})
        if u.path == "/api/rules":
            if not isinstance(data, list):
                return self.send(400, {"error": "Liste erwartet"})
            clean = []
            for r in data:
                if not str(r.get("find") or ""):
                    continue
                if r.get("regex"):
                    try:
                        re.compile(r["find"])
                    except re.error as e:
                        return self.send(400, {"error": f"Ungültiges Muster „{r['find']}“: {e}"})
                clean.append({"find": str(r["find"]), "replace": str(r.get("replace") or ""),
                              "regex": bool(r.get("regex")), "case": bool(r.get("case")),
                              "kind": r.get("kind") if r.get("kind") in KINDS else "all",
                              "enabled": bool(r.get("enabled", True)), "note": str(r.get("note") or "")})
            with lock:
                curation["rules"] = clean
            build_view()
            return self.send(200, {"ok": True})
        if u.path in ("/api/templates/save", "/api/templates/import"):
            name = str(data.get("name") or "").strip()
            if not name:
                return self.send(400, {"error": "Name fehlt"})
            tid = re.sub(r"[^a-z0-9_-]+", "-", name.lower()).strip("-") or "vorlage"
            if u.path.endswith("import"):
                cur = (data.get("data") or {}).get("curation")
                if not isinstance(cur, dict):
                    return self.send(400, {"error": "Das ist keine Onyx-Vorlage."})
            else:
                with lock:
                    cur = json.loads(json.dumps(curation))
            save_json(os.path.join("templates", tid + ".json"),
                      {"name": name, "created": int(time.time()), "curation": cur})
            return self.send(200, {"ok": True, "id": tid})
        if u.path == "/api/templates/load":
            tid = re.sub(r"[^a-z0-9_-]", "", str(data.get("id") or ""))
            t = load_json(os.path.join("templates", tid + ".json"), None)
            if not t or not isinstance(t.get("curation"), dict):
                return self.send(404, {"error": "Vorlage nicht gefunden"})
            with lock:
                save_json(os.path.join("templates", "_vor-dem-laden.json"),
                          {"name": "Automatisch: Stand vor dem letzten Laden", "created": int(time.time()),
                           "curation": json.loads(json.dumps(curation))})
                keep_live = curation.get("livecats", [])
                curation.clear()
                curation.update(t["curation"])
                if "livecats" not in t["curation"]:
                    curation["livecats"] = keep_live  # ältere Vorlage ohne Live-Kategorien: die jetzigen behalten
                for k in KINDS:
                    curation.setdefault(k, {})
            build_view()
            return self.send(200, {"ok": True})
        if u.path == "/api/templates/delete":
            tid = re.sub(r"[^a-z0-9_-]", "", str(data.get("id") or ""))
            try:
                os.remove(os.path.join(TPL_DIR, tid + ".json"))
            except OSError:
                pass
            return self.send(200, {"ok": True})
        if u.path == "/api/custom":
            kind, name = data.get("kind"), str(data.get("name") or "").strip()
            if kind not in KINDS or not name:
                return self.send(400, {"error": "Name fehlt"})
            with lock:
                lst = curation.setdefault("custom", {}).setdefault(kind, [])
                n = max([int(c["vid"]) - CUSTOM_BASE for c in lst] + [0]) + 1
                vid = str(CUSTOM_BASE + n)
                lst.append({"vid": vid, "name": name})
                curation.setdefault(kind, {})[vid] = {"show": True, "name": "", "order": -1000 - n}
            build_view()
            return self.send(200, {"ok": True, "vid": vid})
        if u.path == "/api/custom_delete":
            kind, vid = data.get("kind"), str(data.get("vid"))
            with lock:
                lst = curation.setdefault("custom", {}).setdefault(kind, [])
                gone = next((c for c in lst if c["vid"] == vid), None) or {}
                for v in gone.get("shown") or []:  # zusammengefasst: die vorher sichtbaren Kategorien kommen zurück
                    curation.setdefault(kind, {}).setdefault(v, {})["show"] = True
                curation["custom"][kind] = [c for c in lst if c["vid"] != vid]
                curation.get(kind, {}).pop(vid, None)
                for st in curation.get("channels", {}).values():  # Sender gehen zurück in ihre Kategorie
                    if st.get("cat") == vid:
                        st["cat"] = ""
            build_view()
            return self.send(200, {"ok": True})
        if u.path == "/api/users":
            base = None
            if isinstance(data, dict) and isinstance(data.get("users"), list):
                base, data = data.get("base") or {}, data["users"]
            if not isinstance(data, list):
                return self.send(400, {"error": "Liste erwartet"})
            seen, clean, owner = set(), [], {}
            for x in data:
                pdoms = {}
                for pk in ("A", "B"):
                    raw = (x.get(pk) or {}).get("domains")
                    if raw is None and pk == "A":
                        raw = x.get("domains")  # ältere Einträge: eine Domain-Spalte für alles
                    pdoms[pk] = []
                    for d in raw if isinstance(raw, list) else re.split(r"[\s,;]+", str(raw or "")):
                        d = norm_domain(d)
                        if not d:
                            continue
                        if not DOMAIN_RE.match(d):
                            return self.send(400, {"error": f"Keine gültige Domain bei {x.get('username') or 'Benutzer'}: {d}"})
                        if d not in pdoms[pk]:
                            pdoms[pk].append(d)
                x["_pdoms"] = pdoms
                x["_domains"] = pdoms["A"] + [d for d in pdoms["B"] if d not in pdoms["A"]]
                name = str(x.get("username", "")).strip()
                if not name or not x.get("password"):
                    return self.send(400, {"error": "Jeder Benutzer braucht Name und Passwort"})
                if name in seen:
                    return self.send(400, {"error": f"Benutzername doppelt: {name}"})
                seen.add(name)
                x["_clean_idx"] = len(clean)
                clean.append({
                    "username": name, "password": str(x["password"]),
                    "enabled": bool(x.get("enabled", True)), "exp": str(x.get("exp") or ""),
                    "max_connections": int(x.get("max_connections") or 1), "note": str(x.get("note") or ""),
                    "phone": re.sub(r"[^0-9+]", "", str(x.get("phone") or ""))[:20],
                    "created": int(x.get("created") or time.time()),
                    "packages": [str(p) for p in (x.get("packages") or [])],
                    "domains": x["_domains"],
                    "sources": "A" if x.get("sources") == "A" else "AB",
                    "A": {"user": str((x.get("A") or {}).get("user") or "").strip(), "domains": x["_pdoms"]["A"],
                          "pass": str((x.get("A") or {}).get("pass") or "")},
                    "B": {"user": str((x.get("B") or {}).get("user") or "").strip(), "domains": x["_pdoms"]["B"],
                          "pass": str((x.get("B") or {}).get("pass") or "")},
                })
            if base is not None:
                try:
                    clean = merge_users(data, clean, base)
                except UserConflict as e:
                    return self.send(409, {"error": str(e), "conflict": True})
                names = [c["username"] for c in clean]
                dup = next((n for n in names if names.count(n) > 1), None)
                if dup:
                    return self.send(400, {"error": f"Benutzername doppelt: {dup} (wurde inzwischen auf einem anderen Gerät angelegt)"})
            with lock:
                try:
                    user_diff(users, clean)
                except Exception as e:
                    log.warning("Benutzer-Verlauf: %s", e)
                gone = [u for u in users if u["username"] not in {c["username"] for c in clean}]
                if gone:
                    trash_add(gone)
                users = clean
                save_json("users.json", users)
                resp_cache.clear()
            write_domains_file()  # neue Benutzer-Domains landen automatisch in Nginx
            return self.send(200, {"ok": True})
        self.send(404, {"error": "?"})


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, server_address, RequestHandlerClass, max_workers: int = 64, **kwargs):
        super().__init__(server_address, RequestHandlerClass, **kwargs)
        self.max_workers = max_workers
        self.semaphore = threading.Semaphore(max_workers)
        self.active_requests = 0
        self._active_lock = threading.Lock()

    def process_request_thread(self, request, client_address):
        to = getattr(self.RequestHandlerClass, "timeout", None)
        if to:
            try:
                request.settimeout(to)
            except OSError:
                pass
        acquired = self.semaphore.acquire(timeout=min(to or 60, 30))
        if not acquired:
            try:
                request.sendall(b"HTTP/1.1 503 Service Unavailable\r\nContent-Length: 0\r\n\r\n")
            except OSError:
                pass
            self.shutdown_request(request)
            return
        with self._active_lock:
            self.active_requests += 1
        try:
            self.finish_request(request, client_address)
        except (BrokenPipeError, ConnectionResetError, TimeoutError, socket.timeout, ConnectionAbortedError):
            pass
        except Exception:
            self.handle_error(request, client_address)
        finally:
            with self._active_lock:
                self.active_requests -= 1
            self.semaphore.release()
            self.shutdown_request(request)

    def handle_error(self, request, client_address):
        t, v, tb = sys.exc_info()
        if t in (BrokenPipeError, ConnectionResetError, TimeoutError, socket.timeout, ConnectionAbortedError):
            return
        if isinstance(v, OSError) and getattr(v, "errno", None) in (32, 104, 110):
            return
        log.exception("SERVER FEHLER bei Anfrage von %s", client_address)
        super().handle_error(request, client_address)


def serve(addr: str, handler, max_workers: int = 64) -> BoundedThreadingHTTPServer:
    host, port = addr.rsplit(":", 1)
    srv = BoundedThreadingHTTPServer((host, int(port)), handler, max_workers=max_workers)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log.info("Läuft auf %s (Zeitgrenze %d s, max %d Threads)", addr, getattr(handler, "timeout", 60), max_workers)
    return srv


def default_livecats() -> None:
    """Beim allerersten Start Fußball und Kämpfe anlegen. Wurden sie einmal gelöscht, bleiben sie gelöscht."""
    if "livecats" in curation:
        return
    curation["livecats"] = [{"id": key, "num": n, "name": p["name"], "enabled": True, "words": list(p["words"]),
                             "exclude": list(p["exclude"]), "hours": 18, "desc": False, "max_per_event": 2}
                            for n, (key, p) in enumerate(LIVECAT_PRESETS.items(), 1)]
    save_json("curation.json", curation)
    log.info("Live-Kategorien Fußball und Kämpfe angelegt")


def main():
    gc.set_threshold(50_000, 20, 50)  # weniger häufige Speicherbereinigung – bei riesigen Katalogen spürbar schneller
    load_catalogs()
    default_livecats()
    snap = load_json("curation_pub.json", None)
    if isinstance(snap, dict) and config.get("draft_mode", True):
        draft = json.loads(json.dumps(curation))
        curation.clear()
        curation.update(snap)
        build_view()            # pub ist noch leer -> wird zum gespeicherten Stand
        curation.clear()
        curation.update(draft)
        build_view()            # Entwurf (falls ungespeicherte Änderungen da sind)
    else:
        build_view()
    serve(config["listen"], ClientHandler)
    serve(admin_bind(), AdminHandler)
    threading.Thread(target=scheduler, daemon=True).start()
    threading.Thread(target=backup_scheduler, daemon=True).start()
    threading.Thread(target=livecat_scheduler, daemon=True).start()
    threading.Thread(target=stats_scheduler, daemon=True).start()
    threading.Thread(target=diag_scheduler, daemon=True).start()
    threading.Thread(target=panel_scheduler, daemon=True).start()
    threading.Thread(target=bexp_scheduler, daemon=True).start()
    threading.Thread(target=route_scheduler, daemon=True).start()
    threading.Thread(target=watchdog, daemon=True).start()
    threading.Thread(target=health_scheduler, daemon=True).start()
    notify("start", f"🔄 Onyx Merge gestartet (Version {VERSION}).", cooldown=600)
    for m in load_problems:
        config_warnings.append(m)
        notify("start", "⚠️ " + m, key="corrupt-" + m[:40], cooldown=600)
    if not list_backups():
        try:
            make_backup("hand")  # erste Sicherung gleich beim ersten Start
        except Exception as e:
            log.error("Erste Sicherung: %s", e)
    import signal

    def stop(*_):  # beim Beenden (Neustart, Update) nichts verlieren
        try:
            stats_flush()
            save_json("activity.json", activity)
            save_json("isp_cache.json", _isp_cache)
            save_json("passthru.json", passthru)
        except Exception as e:
            log.error("Beim Beenden: %s", e)
        os._exit(0)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    while True:
        time.sleep(3600)


if __name__ == "__main__":
    main()
