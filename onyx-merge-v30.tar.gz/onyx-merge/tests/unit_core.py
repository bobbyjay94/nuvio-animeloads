#!/usr/bin/env python3
"""Bausteine von Onyx Merge einzeln prüfen (ohne Server, ohne Anbieter, eigener leerer Datenordner).

Prüft: Liste wird bei gleichzeitigen Abrufen nur einmal gebaut, veralteter Bau wird nach dem Speichern nicht abgelegt,
eine Liste für alle Domains (eigene Logos je Domain), sicheres Speichern bei vielen gleichzeitigen Schreibvorgängen,
kaputte Datei wird beiseitegelegt, Programm-Datenbank bleibt lesbar während des Einspielens, nur ein Abgleich gleichzeitig,
Live-Kategorien ohne Mehrfach-Sender.
Aufruf: python3 tests/unit_core.py [PAKET-ORDNER]   Ausgabe: eine Zeile je Prüfung, Exit 0 wenn alles stimmt.
"""
import json, os, shutil, sys, tempfile, threading, time
sys.dont_write_bytecode = True

PKG = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
tmp = tempfile.mkdtemp(prefix="onyx-unit-")
os.makedirs(os.path.join(tmp, "data"))
os.environ["ONYX_MERGE_HOME"] = tmp
sys.path.insert(0, PKG)
fails = []


def check(name, cond, detail=""):
    print(("  OK      " if cond else "  FEHLER  ") + name + ("" if cond else f" {detail}"))
    if not cond:
        fails.append(name)


try:
    import onyx_merge as m

    # 1) gleichzeitig dieselbe Liste -> nur ein Bau
    builds = []

    def slow():
        builds.append(1)
        time.sleep(0.3)
        return b"x" * 5000
    out = []
    ths = [threading.Thread(target=lambda: out.append(m.cache_once(("t", 1), slow))) for _ in range(8)]
    [t.start() for t in ths]; [t.join() for t in ths]
    check("8 gleichzeitige Abrufe: Liste wird nur einmal gebaut", len(builds) == 1 and len(out) == 8 and len(set(out)) == 1, len(builds))

    # 2) Speichern während des Baus -> alter Stand wird nicht abgelegt
    def stale():
        time.sleep(0.2)
        return b"alt"
    t = threading.Thread(target=lambda: m.cache_once(("t", 2), stale)); t.start()
    time.sleep(0.05); m.resp_cache.clear(); t.join()
    check("Speichern während des Baus: alter Stand wird verworfen", ("t", 2) not in m.resp_cache)

    # 3) eine Liste für alle Domains, eigene Logos je Domain
    m.config.setdefault("domains", {})["A"] = ["eins.example", "zwei.example"]
    m.config["public_host"] = "eins.example"
    body = b'[{"stream_icon":"' + m.BASE_MARK.encode() + b'/logos/a.png"}]'
    calls = []
    orig = m.list_items
    m.list_items = lambda *a, **k: calls.append(1) or json.loads(body)
    try:
        k1, b1 = m.list_for(("vod", "items", ("A",), (), None, "eins.example"))
        k2, b2 = m.list_for(("vod", "items", ("A",), (), None, "zwei.example"))
        k3, b3 = m.list_for(("vod", "items", ("A",), (), None, "zwei.example"))
    finally:
        m.list_items = orig
    check("Drei Abrufe über zwei Domains: einmal gebaut, Logo-Adresse je Domain", len(calls) == 1 and b"http://eins.example/logos" in b1
          and b"http://zwei.example/logos" in b2 and b2 == b3 and k2 == k3, (len(calls), b1[:80], b2[:80]))
    m.list_items = lambda *a, **k: [{"name": "x", "stream_icon": "http://cdn/x.png"}]
    try:
        ka, _ = m.list_for(("series", "items", ("A",), (), None, "eins.example"))
        kb, _ = m.list_for(("series", "items", ("A",), (), None, "zwei.example"))
    finally:
        m.list_items = orig
    check("Ohne eigene Logos teilen sich alle Domains denselben Eintrag", ka == kb and ka[5] == "", (ka, kb))

    # 4) 20 gleichzeitige Speichervorgänge
    shared = {"n": 0, "list": list(range(2000))}
    errs = []

    def writer(i):
        try:
            for _ in range(5):
                shared["n"] = i
                m.save_json("users.json", shared)
        except Exception as e:
            errs.append(repr(e))
    ths = [threading.Thread(target=writer, args=(i,)) for i in range(20)]
    [t.start() for t in ths]; [t.join() for t in ths]
    left = [f for f in os.listdir(m.DATA) if f.endswith(".tmp")]
    v = json.load(open(os.path.join(m.DATA, "users.json")))
    check("20 gleichzeitige Speichervorgänge: keine Fehler, keine Reste, Datei vollständig",
          not errs and not left and len(v["list"]) == 2000, (errs[:2], left))
    check("Sicherheitskopie (.bak) der wichtigen Dateien", os.path.exists(os.path.join(m.DATA, "users.json.bak")))

    # 5) Datei wird während des Speicherns geändert -> zweiter Versuch
    class Grow(dict):
        n = 0
    g = {"a": {str(i): i for i in range(50000)}}
    stop = [False]

    def mutate():
        i = 0
        while not stop[0]:
            g["a"][f"x{i % 50}"] = i; g["a"].pop(f"x{(i + 25) % 50}", None); i += 1
    mt = threading.Thread(target=mutate); mt.start()
    try:
        ok = True
        for _ in range(5):
            m.save_json("status.json", g)
    except Exception as e:
        ok = repr(e)
    stop[0] = True; mt.join()
    check("Änderung während des Speicherns führt nicht zum Abbruch", ok is True, ok)

    # 6) kaputte Datei
    p = os.path.join(m.DATA, "users.json")
    good = json.load(open(p))
    open(p, "w").write('{"kaputt": ')
    got = m.load_json("users.json", [])
    bad = [f for f in os.listdir(m.DATA) if f.startswith("users.json.corrupt-")]
    check("Kaputte Datei wird beiseitegelegt und die letzte gute Fassung genutzt", bad and got == good and m.load_problems, (bad, type(got)))
    open(os.path.join(m.DATA, "tests.json"), "w").write("nicht json")
    if os.path.exists(os.path.join(m.DATA, "tests.json.bak")):
        os.remove(os.path.join(m.DATA, "tests.json.bak"))
    got = m.load_json("tests.json", {"leer": 1})
    check("Kaputte Datei ohne Sicherheitskopie: Standard, Original bleibt erhalten",
          got == {"leer": 1} and any(f.startswith("tests.json.corrupt-") for f in os.listdir(m.DATA)))

    # 7) Programm-Datenbank lesbar während des Einspielens
    con = m.epg_conn()
    mode = con.execute("PRAGMA journal_mode").fetchone()[0]
    con.execute("BEGIN")
    con.executemany("INSERT OR REPLACE INTO prog VALUES(?,?,?,?,?)", [(f"c{i}", i, i + 1, "t", "d") for i in range(20000)])
    t0 = time.time()
    r = m.epg_conn()
    n = r.execute("SELECT COUNT(*) FROM prog").fetchone()[0]
    waited = time.time() - t0
    con.commit(); con.close(); r.close()
    check("Programm bleibt lesbar, während es eingespielt wird (WAL)", mode == "wal" and waited < 1 and n == 0, (mode, round(waited, 2), n))
    check("Statistik und Diagnose ebenfalls im WAL-Modus",
          m.stats_conn().execute("PRAGMA journal_mode").fetchone()[0] == "wal"
          and m.diag_conn().execute("PRAGMA journal_mode").fetchone()[0] == "wal")

    # 8) nur ein Abgleich gleichzeitig
    runs = []
    orig_sp = m.sync_provider
    m.config["providers"] = {"A": {"sync_user": "s", "epg": False}}
    m.sync_provider = lambda *a: (runs.append(1), time.sleep(0.3), {})[2]
    ob, op = m.build_view, m.publish
    m.build_view = lambda *a, **k: None
    m.publish = lambda *a, **k: None
    try:
        ths = [threading.Thread(target=m.run_sync) for _ in range(6)]
        [t.start() for t in ths]; [t.join() for t in ths]
    finally:
        m.sync_provider, m.build_view, m.publish = orig_sp, ob, op
    check("Sechs gleichzeitige Abgleich-Starts: nur einer läuft", len(runs) == 1, len(runs))

    # 9) Live-Kategorien: jeder Sender nur einmal je Spiel, auch bei vielen Sendern
    con = m.epg_conn()
    con.execute("DELETE FROM prog")
    now = int(time.time())
    con.executemany("INSERT INTO prog VALUES(?,?,?,?,?)", [(f"ch{i % 300}", now + 600 + (i // 300), now + 7000, "Bundesliga: A - B", "") for i in range(3000)])
    con.commit(); con.close()
    idx = {f"ch{i}": [{"vid": i % 150, "pos": i}, {"vid": 1000 + i, "pos": 1000 + i}] for i in range(300)}
    t0 = time.time()
    ev = m.match_events({"words": ["bundesliga"], "exclude": [], "hours": 6}, idx)
    dt = time.time() - t0
    vids = [s["vid"] for s in ev[0]["cands"]] if ev else []
    check("Live-Kategorien: jeder Sender nur einmal, schnell", ev and len(vids) == len(set(vids)) and dt < 1, (len(ev), dt))
    # 10) M7: Zeitgrenzen und Thread-Limits
    import socket
    check("Zeitgrenzen im Code: Apps 60 s, Admin 120 s",
          getattr(m.ClientHandler, "timeout", None) == 60 and getattr(m.AdminHandler, "timeout", None) == 120,
          (getattr(m.ClientHandler, "timeout", None), getattr(m.AdminHandler, "timeout", None)))

    class QuickHandler(m.BaseHTTPRequestHandler):
        timeout = 0.3
        def log_message(self, *a): pass
        def do_GET(self):
            time.sleep(0.5)
            self.send_response(200); self.end_headers()

    test_srv = m.BoundedThreadingHTTPServer(("127.0.0.1", 0), QuickHandler, max_workers=2)
    t_srv = threading.Thread(target=test_srv.serve_forever, daemon=True); t_srv.start()
    t_port = test_srv.server_address[1]
    s_silent = socket.socket(); s_silent.connect(("127.0.0.1", t_port))
    t_start = time.time()
    s_silent.recv(100)
    dur = time.time() - t_start
    s_silent.close()
    test_srv.shutdown()
    check("Stille Verbindung wird nach der Zeitgrenze getrennt (M7)", 0.2 <= dur <= 0.8, dur)

    # 11) M8: Zwischenspeicher mit Obergrenze (LRU)
    rc = m.RespCache(max_bytes=1000)
    rc.set("k1", b"x" * 400)
    rc.set("k2", b"y" * 400)
    check("RespCache speichert Elemente", rc.get("k1") == b"x" * 400 and rc.get("k2") == b"y" * 400, (len(rc), rc.total_bytes))
    # Zugriff auf k1 macht es zum meistgenutzten Element (LRU)
    rc.get("k1")
    # k3 hinzufügen (400 Bytes) -> Limit 1000 Bytes überschritten -> k2 (am längsten ungenutzt) muss rausfliegen
    rc.set("k3", b"z" * 400)
    check("RespCache verwirft älteste Einträge bei Überschreitung (LRU)", rc.get("k2") is None and rc.get("k1") is not None and rc.get("k3") is not None, list(rc.keys()))

    # 12) M9: Kataloge kompakt speichern
    m.save_json("catalog_test.json", {"a": [1, 2, 3], "b": "wert"})
    with open(m._path("catalog_test.json"), "r", encoding="utf-8") as f:
        c_raw = f.read()
    check("Katalog wird ohne Leerzeichen kompakt gespeichert (M9)", "\n" not in c_raw and ", " not in c_raw and ": " not in c_raw, c_raw)

    m.save_json("other_test.json", {"a": [1, 2, 3], "b": "wert"})
    with open(m._path("other_test.json"), "r", encoding="utf-8") as f:
        o_raw = f.read()
    check("Normale Konfigurationen bleiben formatiert lesbar", "\n" in o_raw, o_raw)

    # 13) M11: Fehler-Erfassung nach Bereich
    m.track_error("sync", "Test-Fehler Sync", exc=ValueError("Sync abgebrochen"))
    check("Fehlerzähler und Historie erfassen Fehler (M11)",
          m.err_counts["sync"] >= 1 and len(m.err_recent) >= 1 and m.err_recent[0]["area"] == "sync",
          (m.err_counts["sync"], len(m.err_recent)))

    # 14) M12: Antwortzeiten und Klassifizierung je Endpunkt
    check("Endpunkt-Klassifizierung erkennt Typen",
          m.classify_endpoint("/player_api.php?username=u&password=p") == "auth" and
          m.classify_endpoint("/player_api.php?username=u&password=p&action=get_live_streams") == "live" and
          m.classify_endpoint("/player_api.php?username=u&password=p&action=get_vod_streams") == "vod" and
          m.classify_endpoint("/xmltv.php?username=u&password=p") == "epg",
          "Klassifizierung korrekt")
    m.record_endpoint_latency("auth", 12.5)
    m.record_endpoint_latency("auth", 25.0)
    st = m.endpoint_stats()
    check("Endpunkt-Statistik berechnet Kennzahlen (M12)",
          "auth" in st and st["auth"]["count"] >= 2 and st["auth"]["avg"] > 0,
          st.get("auth"))

    # 15) M10: Dienst-Absicherung (systemd)
    svc_file = os.path.join(PKG, 'onyx-merge.service')
    with open(svc_file, 'r', encoding='utf-8') as f:
        s_txt = f.read()
    check("Dienst-Absicherung in systemd (Nice=5, WatchdogSec, MemoryMax) (M10)",
          "Nice=5" in s_txt and "WatchdogSec=120" in s_txt and "MemoryMax=" in s_txt and hasattr(m, "_start_watchdog_thread"),
          s_txt)

    # 16) M14: Nginx-Pufferung für Kataloge und Playlisten
    import importlib.util
    spec = importlib.util.spec_from_file_location("apply_domains", os.path.join(PKG, 'apply_domains.py'))
    ad_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ad_mod)
    s_conf = ad_mod.site_conf(["example.com"])
    check("Nginx-Pufferung für Listenabrufe aktiviert (M14)",
          "proxy_buffering on;" in s_conf and "proxy_buffer_size 128k;" in s_conf and "proxy_max_temp_file_size 128m;" in s_conf,
          s_conf)

finally:
    shutil.rmtree(tmp, ignore_errors=True)
print(f"{'FEHLER' if fails else 'ALLES OK'}: {len(fails)} fehlgeschlagen")
sys.exit(1 if fails else 0)
