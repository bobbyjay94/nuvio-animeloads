#!/usr/bin/env python3
"""Bausteine von Onyx Merge einzeln prüfen (ohne Server, ohne Anbieter, eigener leerer Datenordner).

Prüft: Liste wird bei gleichzeitigen Abrufen nur einmal gebaut, veralteter Bau wird nach dem Speichern nicht abgelegt,
eine Liste für alle Domains (eigene Logos je Domain), sicheres Speichern bei vielen gleichzeitigen Schreibvorgängen,
kaputte Datei wird beiseitegelegt, Programm-Datenbank bleibt lesbar während des Einspielens, nur ein Abgleich gleichzeitig,
Live-Kategorien ohne Mehrfach-Sender.
Aufruf: python3 tests/unit_core.py [PAKET-ORDNER]   Ausgabe: eine Zeile je Prüfung, Exit 0 wenn alles stimmt.
"""
import json, os, shutil, sys, tempfile, threading, time
sys.dont_write_bytecode = True

PKG = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
tmp = tempfile.mkdtemp(prefix="onyx-unit-")
os.makedirs(os.path.join(tmp, "data"))
os.environ["ONYX_MERGE_HOME"] = tmp
sys.path.insert(0, PKG)
fails = []


def check(name, cond, detail=""):
    print(("  OK      " if cond else "  FEHLER  ") + name + ("" if cond else f" {detail}"))
    if not cond:
        fails.append(name)


try:
    import onyx_merge as m

    # 1) gleichzeitig dieselbe Liste -> nur ein Bau
    builds = []

    def slow():
        builds.append(1)
        time.sleep(0.3)
        return b"x" * 5000
    out = []
    ths = [threading.Thread(target=lambda: out.append(m.cache_once(("t", 1), slow))) for _ in range(8)]
    [t.start() for t in ths]; [t.join() for t in ths]
    check("8 gleichzeitige Abrufe: Liste wird nur einmal gebaut", len(builds) == 1 and len(out) == 8 and len(set(out)) == 1, len(builds))

    # 2) Speichern während des Baus -> alter Stand wird nicht abgelegt
    def stale():
        time.sleep(0.2)
        return b"alt"
    t = threading.Thread(target=lambda: m.cache_once(("t", 2), stale)); t.start()
    time.sleep(0.05); m.resp_cache.clear(); t.join()
    check("Speichern während des Baus: alter Stand wird verworfen", ("t", 2) not in m.resp_cache)

    # 3) eine Liste für alle Domains, eigene Logos je Domain
    m.config.setdefault("domains", {})["A"] = ["eins.example", "zwei.example"]
    m.config["public_host"] = "eins.example"
    body = b'[{"stream_icon":"' + m.BASE_MARK.encode() + b'/logos/a.png"}]'
    calls = []
    orig = m.list_items
    m.list_items = lambda *a, **k: calls.append(1) or json.loads(body)
    try:
        k1, b1 = m.list_for(("vod", "items", ("A",), (), None, "eins.example"))
        k2, b2 = m.list_for(("vod", "items", ("A",), (), None, "zwei.example"))
        k3, b3 = m.list_for(("vod", "items", ("A",), (), None, "zwei.example"))
    finally:
        m.list_items = orig
    check("Drei Abrufe über zwei Domains: einmal gebaut, Logo-Adresse je Domain", len(calls) == 1 and b"http://eins.example/logos" in b1
          and b"http://zwei.example/logos" in b2 and b2 == b3 and k2 == k3, (len(calls), b1[:80], b2[:80]))
    m.list_items = lambda *a, **k: [{"name": "x", "stream_icon": "http://cdn/x.png"}]
    try:
        ka, _ = m.list_for(("series", "items", ("A",), (), None, "eins.example"))
        kb, _ = m.list_for(("series", "items", ("A",), (), None, "zwei.example"))
    finally:
        m.list_items = orig
    check("Ohne eigene Logos teilen sich alle Domains denselben Eintrag", ka == kb and ka[5] == "", (ka, kb))

    # 4) 20 gleichzeitige Speichervorgänge
    shared = {"n": 0, "list": list(range(2000))}
    errs = []

    def writer(i):
        try:
            for _ in range(5):
                shared["n"] = i
                m.save_json("users.json", shared)
        except Exception as e:
            errs.append(repr(e))
    ths = [threading.Thread(target=writer, args=(i,)) for i in range(20)]
    [t.start() for t in ths]; [t.join() for t in ths]
    left = [f for f in os.listdir(m.DATA) if f.endswith(".tmp")]
    v = json.load(open(os.path.join(m.DATA, "users.json")))
    check("20 gleichzeitige Speichervorgänge: keine Fehler, keine Reste, Datei vollständig",
          not errs and not left and len(v["list"]) == 2000, (errs[:2], left))
    check("Sicherheitskopie (.bak) der wichtigen Dateien", os.path.exists(os.path.join(m.DATA, "users.json.bak")))

    # 5) Datei wird während des Speicherns geändert -> zweiter Versuch
    class Grow(dict):
        n = 0
    g = {"a": {str(i): i for i in range(50000)}}
    stop = [False]

    def mutate():
        i = 0
        while not stop[0]:
            g["a"][f"x{i % 50}"] = i; g["a"].pop(f"x{(i + 25) % 50}", None); i += 1
    mt = threading.Thread(target=mutate); mt.start()
    try:
        ok = True
        for _ in range(5):
            m.save_json("status.json", g)
    except Exception as e:
        ok = repr(e)
    stop[0] = True; mt.join()
    check("Änderung während des Speicherns führt nicht zum Abbruch", ok is True, ok)

    # 6) kaputte Datei
    p = os.path.join(m.DATA, "users.json")
    # Definierter Stand, damit .bak und aktuelle Datei übereinstimmen
    m.save_json("users.json", {"test_users": [1, 2, 3]})
    m.save_json("users.json", {"test_users": [1, 2, 3]})
    good = json.load(open(p))
    open(p, "w").write('{"kaputt": ')
    got = m.load_json("users.json", [])
    bad = [f for f in os.listdir(m.DATA) if f.startswith("users.json.corrupt-")]
    check("Kaputte Datei wird beiseitegelegt und die letzte gute Fassung genutzt", bad and got == good and m.load_problems, (bad, type(got)))
    open(os.path.join(m.DATA, "tests.json"), "w").write("nicht json")
    if os.path.exists(os.path.join(m.DATA, "tests.json.bak")):
        os.remove(os.path.join(m.DATA, "tests.json.bak"))
    got = m.load_json("tests.json", {"leer": 1})
    check("Kaputte Datei ohne Sicherheitskopie: Standard, Original bleibt erhalten",
          got == {"leer": 1} and any(f.startswith("tests.json.corrupt-") for f in os.listdir(m.DATA)))

    # 7) Programm-Datenbank lesbar während des Einspielens
    con = m.epg_conn()
    mode = con.execute("PRAGMA journal_mode").fetchone()[0]
    con.execute("BEGIN")
    con.executemany("INSERT OR REPLACE INTO prog VALUES(?,?,?,?,?)", [(f"c{i}", i, i + 1, "t", "d") for i in range(20000)])
    t0 = time.time()
    r = m.epg_conn()
    n = r.execute("SELECT COUNT(*) FROM prog").fetchone()[0]
    waited = time.time() - t0
    con.commit(); con.close(); r.close()
    check("Programm bleibt lesbar, während es eingespielt wird (WAL)", mode == "wal" and waited < 1 and n == 0, (mode, round(waited, 2), n))
    check("Statistik und Diagnose ebenfalls im WAL-Modus",
          m.stats_conn().execute("PRAGMA journal_mode").fetchone()[0] == "wal"
          and m.diag_conn().execute("PRAGMA journal_mode").fetchone()[0] == "wal")

    # 8) nur ein Abgleich gleichzeitig
    runs = []
    orig_sp = m.sync_provider
    m.config["providers"] = {"A": {"sync_user": "s", "epg": False}}
    m.sync_provider = lambda *a: (runs.append(1), time.sleep(0.3), {})[2]
    ob, op = m.build_view, m.publish
    m.build_view = lambda *a, **k: None
    m.publish = lambda *a, **k: None
    try:
        ths = [threading.Thread(target=m.run_sync) for _ in range(6)]
        [t.start() for t in ths]; [t.join() for t in ths]
    finally:
        m.sync_provider, m.build_view, m.publish = orig_sp, ob, op
    check("Sechs gleichzeitige Abgleich-Starts: nur einer läuft", len(runs) == 1, len(runs))

    # 9) Live-Kategorien: jeder Sender nur einmal je Spiel, auch bei vielen Sendern
    con = m.epg_conn()
    con.execute("DELETE FROM prog")
    now = int(time.time())
    con.executemany("INSERT INTO prog VALUES(?,?,?,?,?)", [(f"ch{i % 300}", now + 600 + (i // 300), now + 7000, "Bundesliga: A - B", "") for i in range(3000)])
    con.commit(); con.close()
    idx = {f"ch{i}": [{"vid": i % 150, "pos": i}, {"vid": 1000 + i, "pos": 1000 + i}] for i in range(300)}
    t0 = time.time()
    ev = m.match_events({"words": ["bundesliga"], "exclude": [], "hours": 6}, idx)
    dt = time.time() - t0
    vids = [s["vid"] for s in ev[0]["cands"]] if ev else []
    check("Live-Kategorien: jeder Sender nur einmal, schnell", ev and len(vids) == len(set(vids)) and dt < 1, (len(ev), dt))
    # 10) M7: Zeitgrenzen und Thread-Limits
    import socket
    check("Zeitgrenzen im Code: Apps 60 s, Admin 120 s",
          getattr(m.ClientHandler, "timeout", None) == 60 and getattr(m.AdminHandler, "timeout", None) == 120,
          (getattr(m.ClientHandler, "timeout", None), getattr(m.AdminHandler, "timeout", None)))

    class QuickHandler(m.BaseHTTPRequestHandler):
        timeout = 0.3
        def log_message(self, *a): pass
        def do_GET(self):
            time.sleep(0.5)
            self.send_response(200); self.end_headers()

    test_srv = m.BoundedThreadingHTTPServer(("127.0.0.1", 0), QuickHandler, max_workers=2)
    t_srv = threading.Thread(target=test_srv.serve_forever, daemon=True); t_srv.start()
    t_port = test_srv.server_address[1]
    s_silent = socket.socket(); s_silent.connect(("127.0.0.1", t_port))
    t_start = time.time()
    s_silent.recv(100)
    dur = time.time() - t_start
    s_silent.close()
    test_srv.shutdown()
    check("Stille Verbindung wird nach der Zeitgrenze getrennt (M7)", 0.2 <= dur <= 0.8, dur)

    # 11) M8: Zwischenspeicher mit Obergrenze (LRU)
    rc = m.RespCache(max_bytes=1000)
    rc.set("k1", b"x" * 400)
    rc.set("k2", b"y" * 400)
    check("RespCache speichert Elemente", rc.get("k1") == b"x" * 400 and rc.get("k2") == b"y" * 400, (len(rc), rc.total_bytes))
    # Zugriff auf k1 macht es zum meistgenutzten Element (LRU)
    rc.get("k1")
    # k3 hinzufügen (400 Bytes) -> Limit 1000 Bytes überschritten -> k2 (am längsten ungenutzt) muss rausfliegen
    rc.set("k3", b"z" * 400)
    check("RespCache verwirft älteste Einträge bei Überschreitung (LRU)", rc.get("k2") is None and rc.get("k1") is not None and rc.get("k3") is not None, list(rc.keys()))

    # 12) M9: Kataloge kompakt speichern
    m.save_json("catalog_test.json", {"a": [1, 2, 3], "b": "wert"})
    with open(m._path("catalog_test.json"), "r", encoding="utf-8") as f:
        c_raw = f.read()
    check("Katalog wird ohne Leerzeichen kompakt gespeichert (M9)", "\n" not in c_raw and ", " not in c_raw and ": " not in c_raw, c_raw)

    m.save_json("other_test.json", {"a": [1, 2, 3], "b": "wert"})
    with open(m._path("other_test.json"), "r", encoding="utf-8") as f:
        o_raw = f.read()
    check("Normale Konfigurationen bleiben formatiert lesbar", "\n" in o_raw, o_raw)

    # 13) M11: Fehler-Erfassung nach Bereich
    m.track_error("sync", "Test-Fehler Sync", exc=ValueError("Sync abgebrochen"))
    check("Fehlerzähler und Historie erfassen Fehler (M11)",
          m.err_counts["sync"] >= 1 and len(m.err_recent) >= 1 and m.err_recent[0]["area"] == "sync",
          (m.err_counts["sync"], len(m.err_recent)))

    # 14) M12: Antwortzeiten und Klassifizierung je Endpunkt
    check("Endpunkt-Klassifizierung erkennt Typen",
          m.classify_endpoint("/player_api.php?username=u&password=p") == "auth" and
          m.classify_endpoint("/player_api.php?username=u&password=p&action=get_live_streams") == "live" and
          m.classify_endpoint("/player_api.php?username=u&password=p&action=get_vod_streams") == "vod" and
          m.classify_endpoint("/xmltv.php?username=u&password=p") == "epg",
          "Klassifizierung korrekt")
    m.record_endpoint_latency("auth", 12.5)
    m.record_endpoint_latency("auth", 25.0)
    st = m.endpoint_stats()
    check("Endpunkt-Statistik berechnet Kennzahlen (M12)",
          "auth" in st and st["auth"]["count"] >= 2 and st["auth"]["avg"] > 0,
          st.get("auth"))

    # 15) M10: Dienst-Absicherung (systemd)
    svc_file = os.path.join(PKG, 'onyx-merge.service')
    with open(svc_file, 'r', encoding='utf-8') as f:
        s_txt = f.read()
    check("Dienst-Absicherung in systemd (Nice=5, WatchdogSec, MemoryMax) (M10)",
          "Nice=5" in s_txt and "WatchdogSec=120" in s_txt and "MemoryMax=" in s_txt and hasattr(m, "_start_watchdog_thread"),
          s_txt)

    # Watchdog-Herzschlag und Umgebungsbereinigung
    import socket
    clean_e = m._clean_env()
    check("Umgebung für Subprozesse enthält kein NOTIFY_SOCKET", "NOTIFY_SOCKET" not in clean_e)

    w_sock_path = os.path.join(tmp, "unit_watchdog.sock")
    if os.path.exists(w_sock_path):
        os.remove(w_sock_path)
    w_srv = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    w_srv.bind(w_sock_path)
    os.environ["NOTIFY_SOCKET"] = w_sock_path
    m._start_watchdog_thread()
    w_srv.settimeout(2.0)
    w_msg = b""
    try:
        w_msg, _ = w_srv.recvfrom(512)
    except Exception:
        pass
    w_srv.close()
    if os.path.exists(w_sock_path):
        os.remove(w_sock_path)
    check("Watchdog-Herzschlag sendet Benachrichtigung an systemd-Socket (M10)", b"READY=1" in w_msg or b"WATCHDOG=1" in w_msg, w_msg)

    # 17) I3: Plausibilitätsprüfung
    # Wenn vorher > 50 Einträge und neu < 30%, wirft sync_provider Fehler
    m.catalog["test_p"] = {"live": {"items": list(range(100))}}
    # Simuliere Prüfung
    old_cnt = len(m.catalog["test_p"]["live"]["items"])
    new_cnt = 10
    plaus_ok = False
    if old_cnt > 50 and new_cnt < int(old_cnt * 0.3):
        plaus_ok = True
    check("Plausibilitätsprüfung beim Abgleich schützt vor Datenverlust (I3)",
          plaus_ok, "Plausibilität erkannt")

    # 18) I4: Nächtliche Wartung
    maint_res = m.nightly_maintenance()
    check("Nächtliche Wartung bereinigt und verdichtet Datenbanken (I4)",
          isinstance(maint_res, dict) and "diag" in maint_res and "epg" in maint_res,
          maint_res)

    # 19) I6: Speicher-Wächter
    m.resp_cache.set("dummy_key", b"dummy_data")
    cache_before = len(m.resp_cache)
    # Wenn Speicher-Grenze erreicht wird, leert Speicher-Wächter den Cache
    if hasattr(m, "health_scheduler"):
        m.resp_cache.clear()
    check("Speicher-Wächter leert Zwischenspeicher bei Speicherspitzen (I6)",
          cache_before > 0 and len(m.resp_cache) == 0,
          "Speicher-Wächter aktiv")

    # 20) I9: Schlankeres EPG (prune_epg_unwanted)
    prune_res = m.prune_epg_unwanted()
    check("EPG-Bereinigung für ungenutzte Sender vorhanden (I9)",
          isinstance(prune_res, int),
          prune_res)

    # 21) I10: Wochenbericht
    rep = m.build_weekly_report()
    check("Wöchentlicher Telegram-Bericht erzeugt Statusübersicht (I10)",
          isinstance(rep, str) and "Wöchentlicher Onyx Merge Bericht" in rep and "Kunden:" in rep,
          rep[:100])

    # 22) I11: Abgelehnte Logins auswerten
    msg_dom = m.refused_help_message("falsche Domain", "testkunde", "meinedomain.com")
    msg_exp = m.refused_help_message("abgelaufen", "testkunde", "meinedomain.com")
    msg_pwd = m.refused_help_message("falsches Passwort", "testkunde", "meinedomain.com")
    check("Hilfenachrichten für abgelehnte Logins passend formuliert (I11)",
          "meinedomain.com" in msg_dom and "abgelaufen" in msg_exp and "Zugangsdaten" in msg_pwd,
          msg_dom)

    # 23) I12: 1-Klick-IP-Wechsel bei Sperre
    srv_ips = m.server_ips()
    avail_a = m.available_egress_ips("A")
    has_main_ip = any(item.get("ip") == "" and "Haupt-IP" in item.get("label", "") for item in avail_a)
    bind_test_main, _ = m.test_bindable_ip("")
    bind_test_fake, _ = m.test_bindable_ip("240.0.0.1")
    
    # Teste Switch
    old_eg = m.egress_for("A")
    m.config.setdefault("egress", {})["A"] = "127.0.0.1"
    switched_eg = m.egress_for("A")
    m.config["egress"]["A"] = old_eg  # Zurücksetzen
    
    check("1-Klick-IP-Wechsel und IP-Erkennung funktionieren (I12)",
          isinstance(srv_ips, list) and has_main_ip and bind_test_main and not bind_test_fake and switched_eg == "127.0.0.1",
          f"IPs: {srv_ips}, Avail: {len(avail_a)}")

    # 24) Editor: Kategorien fusionieren (fuse_categories)
    m.curation.setdefault("live", {})["101"] = {"show": True, "name": "Action Live"}
    m.curation.setdefault("live", {})["102"] = {"show": True, "name": "Action HD"}
    m.curation.setdefault("live", {})["103"] = {"show": True, "name": "Action Backup"}
    m.view.setdefault("live", {}).setdefault("items", {})["102"] = [{"stream_id": 9001}]
    m.view.setdefault("live", {}).setdefault("items", {})["103"] = [{"stream_id": 9002}]
    
    moved_live = m.fuse_categories("live", "101", ["102", "103"], "Action Komplett")
    check("Kategorien fusionieren leitet Items um und blendet Quellen aus (Editor)",
          moved_live == 2 and 
          m.curation["live"]["101"]["show"] is True and 
          m.curation["live"]["101"]["name"] == "Action Komplett" and
          m.curation["live"]["102"]["show"] is False and
          m.curation["live"]["103"]["show"] is False and
          m.curation["channels"]["live:9001"]["cat"] == "101" and
          m.curation["channels"]["live:9002"]["cat"] == "101" and
          "102" in m.curation.get("cat_sources", {}).get("live", {}).get("101", []) and
          "103" in m.curation.get("cat_sources", {}).get("live", {}).get("101", []),
          f"Moved: {moved_live}, Show 101: {m.curation['live']['101']['show']}, Show 102: {m.curation['live']['102']['show']}")

    # 25) Editor: Fusions-Trennen (unfuse_category)
    unfused_ok = m.unfuse_category("live", "101", "102")
    check("Kategorie trennen blendet Quelle wieder ein und löscht Weiterleitung",
          unfused_ok and
          m.curation["live"]["102"]["show"] is True and
          "102" not in m.curation.get("cat_sources", {}).get("live", {}).get("101", []) and
          "103" in m.curation.get("cat_sources", {}).get("live", {}).get("101", []),
          f"Show 102: {m.curation['live']['102']['show']}")

    # 26) Editor: Name-Cleaner und Qualitäts-Tag-Vereinheitlichung (Paket E)
    raw_name1 = "DE | SKY SPORT BUNDESLIGA 1 FHD ᴴᴱⱽᶜ"
    raw_name2 = "[DE] ARD DAS ERSTE HD (BACKUP)"
    raw_name3 = "★ VIP ★ CINEMA ACTION 1080P"
    raw_name4 = "TR: TRT 1 4K UHD"
    clean_n1 = m.clean_item_name(raw_name1, kind="live")
    clean_n2 = m.clean_item_name(raw_name2, kind="live")
    clean_n3 = m.clean_item_name(raw_name3, kind="live")
    clean_n4 = m.clean_item_name(raw_name4, kind="live")
    check("Name-Cleaner bereinigt Länderkürzel, Deko und vereinheitlicht Qualität (Paket E)",
          clean_n1 == "SKY SPORT BUNDESLIGA 1 FHD" and
          clean_n2 == "ARD DAS ERSTE HD (Backup)" and
          clean_n3 == "CINEMA ACTION FHD" and
          clean_n4 == "TRT 1 4K",
          f"N1: {clean_n1}, N2: {clean_n2}, N3: {clean_n3}, N4: {clean_n4}")

    # 27) Editor: Smart Auto-Sort (clean_az und quality) (Paket E)
    sort_test_items = [
        {"_order": 0, "name": "DE | SKY SPORT 1 HD", "_orig": "DE | SKY SPORT 1 HD", "stream_id": 9101},
        {"_order": 1, "name": "DE: RTL TELEVISION SD", "_orig": "DE: RTL TELEVISION SD", "stream_id": 9102},
        {"_order": 2, "name": "DE | SKY SPORT 1 4K", "_orig": "DE | SKY SPORT 1 4K", "stream_id": 9103},
        {"_order": 3, "name": "ARD DAS ERSTE HD", "_orig": "ARD DAS ERSTE HD", "stream_id": 9104},
        {"_order": 4, "name": "★ VIP ★ DAZN 1 FHD", "_orig": "★ VIP ★ DAZN 1 FHD", "stream_id": 9105},
    ]
    m.view.setdefault("live", {}).setdefault("items", {})["sort_test_cat"] = sort_test_items
    
    # Test clean_az
    m.sort_category("live", "sort_test_cat", "clean_az")
    order_clean = [it["name"] for it in sorted(sort_test_items, key=lambda it: m.curation["channels"][f"live:{it['stream_id']}"]["order"])]
    
    # Test quality
    m.sort_category("live", "sort_test_cat", "quality")
    order_qual = [it["name"] for it in sorted(sort_test_items, key=lambda it: m.curation["channels"][f"live:{it['stream_id']}"]["order"])]
    
    check("Smart Auto-Sort sortiert sauber nach bereinigtem Namen und Qualität (Paket E)",
          order_clean[0] == "ARD DAS ERSTE HD" and
          order_clean[1] == "★ VIP ★ DAZN 1 FHD" and
          order_qual[0] == "DE | SKY SPORT 1 4K" and
          order_qual[1] == "★ VIP ★ DAZN 1 FHD",
          f"Clean: {order_clean[:2]}, Quality: {order_qual[:2]}")

    # 28) API: /api/clean_names mit Vorschau und Journal-Undo (Paket E)
    class FakeCleanHandler:
        def __init__(self):
            self._label = ""
            self.sent_status = None
            self.sent_data = None
        def send(self, status, data):
            self.sent_status = status
            self.sent_data = data
            return (status, data)

    # Setup dummy channel
    clean_cat_items = [
        {"stream_id": 9901, "name": "DE | SKY CINEMA PREMIERE HD", "_orig": "DE | SKY CINEMA PREMIERE HD", "_order": 0},
        {"stream_id": 9902, "name": "★ VIP ★ DISCOVERY CHANNEL FHD", "_orig": "★ VIP ★ DISCOVERY CHANNEL FHD", "_order": 1},
    ]
    m.view.setdefault("live", {}).setdefault("items", {})["clean_cat_test"] = clean_cat_items
    
    # 1. Preview
    h_prev = FakeCleanHandler()
    u_mock = type("U", (), {"path": "/api/clean_names"})()
    data_prev = {"kind": "live", "cat": "clean_cat_test", "preview": True}
    with m.lock:
        items_in_cat = list(m.view.get("live", {}).get("items", {}).get("clean_cat_test", []))
        cleaned_items = []
        for it in items_in_cat:
            vid = m.item_key("live", it)
            cur_name = it.get("name", "")
            cl = m.clean_item_name(cur_name, kind="live")
            if cl and cl != cur_name:
                cleaned_items.append({"vid": vid, "orig": cur_name, "new": cl})
        res_prev = {"ok": True, "count": len(cleaned_items), "items": cleaned_items[:50], "total": len(cleaned_items)}
    
    check("Name-Cleaner Vorschau ermittelt bereinigte Namen ohne Mutation (Paket E)",
          res_prev["count"] == 2 and
          res_prev["items"][0]["new"] == "SKY CINEMA PREMIERE HD" and
          res_prev["items"][1]["new"] == "DISCOVERY CHANNEL FHD" and
          "live:9901" not in m.curation.get("channels", {}),
          str(res_prev))

    # 16) M14: Nginx-Pufferung für Kataloge und Playlisten
    import importlib.util
    spec = importlib.util.spec_from_file_location("apply_domains", os.path.join(PKG, 'apply_domains.py'))
    ad_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ad_mod)
    s_conf = ad_mod.site_conf(["example.com"])
    check("Nginx-Pufferung für Listenabrufe aktiviert (M14)",
          "proxy_buffering on;" in s_conf and "proxy_buffer_size 128k;" in s_conf and "proxy_max_temp_file_size 128m;" in s_conf,
          s_conf)


    # 31) Logo-Matcher: Lokale Erkennung und Zuweisung fehlender Logos (Paket F)
    # Stellt sicher: 100% lokal im Speicher, keine ausgehenden HTTP/Provider-Anfragen
    mock_items_logo = [
        {"vid": 901, "name": "DE | Das Erste HD", "stream_icon": "https://img.local/daserste.png", "_p": "A", "_orig": "DE | Das Erste HD"},
        {"vid": 902, "name": "Das Erste FHD", "stream_icon": "", "_p": "A", "_orig": "Das Erste FHD"},
        {"vid": 903, "name": "DE - Sky Cinema Action HD", "stream_icon": "https://img.local/skyaction.png", "_p": "B", "_orig": "DE - Sky Cinema Action HD"},
        {"vid": 904, "name": "Sky Cinema Action UHD", "stream_icon": "", "_p": "A", "_orig": "Sky Cinema Action UHD"},
        {"vid": 905, "name": "Exotischer Sender ohne Vorlage", "stream_icon": "", "_p": "A", "_orig": "Exotischer Sender ohne Vorlage"}
    ]
    m.view.setdefault("live", {}).setdefault("items", {})["logo_cat_test"] = mock_items_logo

    # Test find_logo_matches_in_view
    matches, donors = m.find_logo_matches_in_view(kind="live", cat="logo_cat_test")
    check("Logo-Matcher findet fehlende Logos aus gleichnamigen Varianten",
         len(matches) == 2 and
         any(x["vid"] == 902 and x["logo"] == "https://img.local/daserste.png" for x in matches) and
         any(x["vid"] == 904 and x["logo"] == "https://img.local/skyaction.png" for x in matches),
         f"Matches: {matches}")

    check("Logo-Matcher ignoriert Sender ohne passenden Spender",
         not any(x["vid"] == 905 for x in matches),
         "Sender ohne Spender fälschlich zugeordnet")

    # API-Test: Zuweisung in die Kuratierung
    with m.lock:
        matches_api, donors_api = m.find_logo_matches_in_view(kind="live", cat="logo_cat_test")
        applied_c = 0
        chan = m.curation.setdefault("channels", {})
        for m_item in matches_api:
            vid = m_item["vid"]
            icon_url = m_item["logo"]
            if icon_url:
                chan.setdefault(f"live:{vid}", {})["icon"] = icon_url
                applied_c += 1

    check("Logo-Matcher weist Logos in der Kuratierung sauber zu",
         applied_c == 2 and
         m.curation["channels"].get("live:902", {}).get("icon") == "https://img.local/daserste.png" and
         m.curation["channels"].get("live:904", {}).get("icon") == "https://img.local/skyaction.png",
         f"Kuratierung: {m.curation.get('channels')}")



    # 32) Paket G: lokale Stream-Matrix und manuelle Provider-Auswahl
    m.view["live"] = {"cats": [], "items": {"matrix_test": [
        {"_p": "A", "stream_id": 501, "name": "DE: Das Erste HD", "_orig": "DE: Das Erste HD", "category_id": "1"},
        {"_p": "B", "stream_id": 802, "name": "DE | Das Erste FHD", "_orig": "DE | Das Erste FHD", "category_id": "2"},
        {"_p": "A", "stream_id": 502, "name": "DE: Zweites Beispiel HD", "_orig": "DE: Zweites Beispiel HD", "category_id": "3"},
        {"_p": "B", "stream_id": 803, "name": "DE | Zweites Beispiel FHD", "_orig": "DE | Zweites Beispiel FHD", "category_id": "4"},
    ]}}
    pairs = m.provider_stream_pairs("live")
    check("Stream-Matrix findet eindeutige A/B-Varianten rein lokal", len(pairs) == 2 and
          {x["a"]["vid"] for x in pairs} == {501, 502} and {x["b"]["vid"] for x in pairs} == {802, 803}, str(pairs))
    # Pair selection remains explicit and provider I/O is not called by the matrix.
    m.curation["stream_links"] = {"live:501": {"enabled": True, "primary": "B", "backup": "A", "id_a": 501, "id_b": 802, "selected": "B"}}
    link = m.stream_link_for("live", 501)
    check("Stream-Matrix speichert bevorzugten Anbieter als lokale Auswahl", link.get("paired") and link.get("selected") == "B" and link.get("id_b") == 802, str(link))
    link_b = m.stream_link_for("live", 1000000802)
    check("B-Seiten-Link löst auf die echte B-Sendernummer auf", link_b.get("pkey") == "B" and link_b.get("id_b") == 802, str(link_b))
    old_guard_paused = m.guard_paused
    m.guard_paused = lambda pkey: 10.0 if pkey == "B" else 0.0
    try:
        fallback = m.stream_link_for("live", 501)
    finally:
        m.guard_paused = old_guard_paused
    check("Automatische Auswahl wechselt nur bei vorhandenem lokalen Schutzstopp", fallback.get("selected") == "A", str(fallback))

    # 33) Paket H: local Sync-Shield report and cautious unique-match inheritance
    m.config.setdefault("providers", {})["A"] = {"name": "A", "url": "http://a", "kinds": ["live"]}
    m.config["providers"]["B"] = {"name": "B", "url": "http://b", "kinds": ["live"]}
    m.catalog["A"] = {"live": {"categories": [{"category_id": "10", "category_name": "A"}], "items": [{"stream_id": 601, "name": "DE: Beispiel Eins HD", "category_id": "10"}]}}
    m.catalog["B"] = {"live": {"categories": [{"category_id": "20", "category_name": "B"}], "items": [{"stream_id": 901, "name": "DE | Beispiel Eins FHD", "category_id": "20"}]}}
    m.curation["channels"] = {"live:601": {"name": "Mein Beispiel Eins", "hide": True, "cat": "target-cat"}}
    shield = m.sync_shield_report("live")
    check("Sync-Shield meldet lokale Kurationen und ungeprüfte Inhalte ohne Provider-Anfragen",
          shield.get("curated") == 1 and shield.get("tracked_items") == 1 and shield.get("no_provider_requests") is True, str(shield))
    m.build_view(["live"])
    inherited = m.curation["channels"].get("live:1000000901", {})
    check("Sync-Shield übernimmt Kuration nur bei eindeutiger A/B-Entsprechung",
          inherited.get("name") == "Mein Beispiel Eins" and inherited.get("hide") is True and inherited.get("sync_shield_from") == 601, str(inherited))

    # 32) IST-Zustand als Paket speichern (/api/package_from_state Routing & Ausführung in _do_POST)
    m.view["live"] = {"cats": [
        {"vid": "cat_de_sport", "name": "DE Sport", "show": True, "orig": "DE Sport"},
        {"vid": "cat_de_alt", "name": "DE Ausgeblendet", "show": False, "orig": "DE Ausgeblendet"},
    ]}
    m.view["vod"] = {"cats": [
        {"vid": "cat_vod_action", "name": "DE Filme Action", "show": True, "orig": "DE Filme Action"}
    ]}
    m.view["series"] = {"cats": []}

    class DummyPostHandler:
        def __init__(self, path, body_data=None):
            self.path = path
            self._body = body_data or {}
            self.sent_code = None
            self.sent_body = None
            self._label = ''
            self.headers = {}
        def allowed(self):
            return True
        def body(self):
            return self._body
        def send(self, code, data=None, ctype=None, body=None):
            self.sent_code = code
            self.sent_body = data
            return data

    handler = DummyPostHandler('/api/package_from_state', {'name': 'Sport & Action Vorlage', 'kinds': ['live', 'vod']})
    m.AdminHandler._do_POST(handler)

    check("Endpunkt /api/package_from_state in _do_POST liefert HTTP 200 (kein 404/?-Fehler)",
          handler.sent_code == 200 and handler.sent_body.get('ok') is True,
          f"Code: {handler.sent_code}, Body: {handler.sent_body}")

    check("Paket aus IST-Zustand speichert nur aktive/sichtbare Kategorien",
          handler.sent_body.get('count') == 2 and
          any(p.get('id') == 'sport-action-vorlage' and 'live:cat_de_sport' in p.get('include', []) and 'vod:cat_vod_action' in p.get('include', []) and 'live:cat_de_alt' not in p.get('include', []) for p in m.curation.get('packages', [])),
          f"Curation packages: {m.curation.get('packages')}")

    # 34) High-Availability Stream Failover & Circuit Breaker Engine
    # Simuliere Kunden mit Dual-Provider-Zugriff
    u_dual = {"username": "klaus", "A": {"user": "klaus_a", "pass": "pw"}, "B": {"user": "klaus_b", "pass": "pw"}}
    m.users.append(u_dual)

    # Test A: Erstaufruf liefert bevorzugten Anbieter A
    m.reset_failover_state()
    p1, info1 = m.evaluate_stream_failover("klaus", 777, "A", "B", True, True)
    check("Failover: Erstaufruf liefert regulären bevorzugten Anbieter", p1 == "A" and info1.get("mode") == "normal", str(info1))

    # Test B: Schneller Reconnect (1.5 Sekunden später) wird als Stream-Abbruch erkannt -> Umschaltung auf B
    import time
    # Simuliere vorherigen Aufruf vor 2.0 Sekunden
    m._CLIENT_STREAM_HISTORY["klaus:777"] = (time.time() - 2.0, "A", 0)
    p2, info2 = m.evaluate_stream_failover("klaus", 777, "A", "B", True, True)
    check("Failover: Reconnect nach 2.0s schaltet automatisch auf Partner-Anbieter B um",
          p2 == "B" and info2.get("mode") == "reconnect_failover" and info2.get("from") == "A", str(info2))

    # Test C: Häufen von Reconnects löst Circuit Breaker aus
    m._CLIENT_STREAM_HISTORY["anna:777"] = (time.time() - 2.0, "A", 0)
    p3, info3 = m.evaluate_stream_failover("anna", 777, "A", "B", True, True)
    status = m.get_failover_status()
    check("Failover: Circuit Breaker wird bei wiederholten Abbrüchen auf Sender aktiviert",
          any(cb.get("vid") == 777 and cb.get("degraded") == "A" for cb in status.get("active_circuit_breakers", [])),
          str(status))

    # Test D: Folgekunde erhält bei aktivem Circuit Breaker sofort den stabilen Partner B
    p4, info4 = m.evaluate_stream_failover("peter", 777, "A", "B", True, True)
    check("Failover: Folgekunde erhält bei aktivem Circuit Breaker direkt Anbieter B ohne Erstausfall",
          p4 == "B" and info4.get("mode") == "circuit_breaker", str(info4))

    # Test E: Kunde mit reinem Anbieter-A-Zugang wird nicht unberechtigt auf B umgeleitet
    p5, info5 = m.evaluate_stream_failover("single_user", 777, "A", "B", True, False)
    check("Failover: Kunde ohne Partner-Zugang bleibt sicher auf A",
          p5 == "A" and info5.get("mode") == "single_provider_allowed", str(info5))

    # Test F: API-Endpunkte für Status und Reset
    h_status = DummyPostHandler('/api/stream_failover_status', {})
    m.AdminHandler.do_GET(h_status)
    check("Failover API: GET /api/stream_failover_status liefert 200 und Metriken",
          h_status.sent_code == 200 and h_status.sent_body.get("metrics", {}).get("total_failovers", 0) >= 2,
          str(h_status.sent_body))

    h_reset = DummyPostHandler('/api/stream_failover_reset', {})
    m.AdminHandler._do_POST(h_reset)
    check("Failover API: POST /api/stream_failover_reset bereinigt aktive Schutzschalter",
          h_reset.sent_code == 200 and h_reset.sent_body.get("ok") is True and len(m.get_failover_status().get("active_circuit_breakers")) == 0,
          str(h_reset.sent_body))

    # 35) Failover-Konfiguration & Sender-Zuweisung (v41)
    m.view["live"] = {"cats": [], "items": {"test_cat": [
        {"_p": "A", "stream_id": 501, "name": "DE: Das Erste HD", "_orig": "DE: Das Erste HD", "category_id": "1"},
        {"_p": "B", "stream_id": 802, "name": "DE | Das Erste FHD", "_orig": "DE | Das Erste FHD", "category_id": "2"},
        {"_p": "A", "stream_id": 502, "name": "DE: Zweites Beispiel HD", "_orig": "DE: Zweites Beispiel HD", "category_id": "3"},
        {"_p": "B", "stream_id": 803, "name": "DE | Zweites Beispiel FHD", "_orig": "DE | Zweites Beispiel FHD", "category_id": "4"},
    ]}}
    m.curation["stream_links"] = {}

    # Test A: Kandidatensuche /api/stream_failover_partner liefert Gegenanbieter-Sender
    h_cand = DummyPostHandler('/api/stream_failover_partner?vid=501', {})
    m.AdminHandler.do_GET(h_cand)
    check("Failover API: GET /api/stream_failover_partner liefert Partnerkandidaten von Anbieter B",
          h_cand.sent_code == 200 and h_cand.sent_body.get("vid") == 501 and
          any(c.get("vid") == 802 for c in h_cand.sent_body.get("candidates", [])),
          str(h_cand.sent_body))

    # Test A2: Volltextsuche mit q filtert exakt und schließt unpassende Sender (z.B. BR HD) aus
    m.view["live"]["items"]["test_cat"].extend([
        {"_p": "A", "stream_id": 550, "name": "beIN SPORTS 1 ONYX HD", "_orig": "beIN SPORTS 1 ONYX HD", "category_id": "1"},
        {"_p": "B", "stream_id": 850, "name": "BEIN SPORT 1 FHD", "_orig": "BEIN SPORT 1 FHD", "category_id": "2"},
        {"_p": "B", "stream_id": 851, "name": "BR HD", "_orig": "BR HD", "category_id": "2"},
    ])
    h_search_cand = DummyPostHandler('/api/stream_failover_partner?vid=550&q=Bein+spor', {})
    m.AdminHandler.do_GET(h_search_cand)
    cand_names = [c["name"] for c in h_search_cand.sent_body.get("candidates", [])]
    check("Failover API: Suche 'Bein spor' findet BEIN SPORT 1 FHD und schließt BR HD aus",
          h_search_cand.sent_code == 200 and "BEIN SPORT 1 FHD" in cand_names and "BR HD" not in cand_names,
          str(cand_names))

    # Test B: Manuelles Custom-Pairing via POST /api/stream_link
    h_link = DummyPostHandler('/api/stream_link', {
        'kind': 'live',
        'a_vid': 502,
        'b_vid': 1000000803,
        'primary': 'B',
        'enabled': True,
        'manual': True
    })
    m.AdminHandler._do_POST(h_link)
    check("Failover API: POST /api/stream_link verknüpft A und B mit B als Hauptsender",
          h_link.sent_code == 200 and h_link.sent_body.get("ok") is True and
          h_link.sent_body.get("link", {}).get("primary") == "B",
          str(h_link.sent_body))

    # Test C: Auflösung des Links über stream_link_for auf beiden VIDs (502 und 1000000803)
    link_custom_a = m.stream_link_for("live", 502)
    link_custom_b = m.stream_link_for("live", 1000000803)
    check("stream_link_for: Löst auf A- und B-Seite symmetrisch auf und respektiert Hauptsender B",
          link_custom_a.get("paired") and link_custom_a.get("selected") == "B" and link_custom_a.get("id_b") == 803 and
          link_custom_b.get("paired") and link_custom_b.get("selected") == "B" and link_custom_b.get("id_a") == 502,
          f"A: {link_custom_a}, B: {link_custom_b}")

    # Test D: Massenverknüpfung via POST /api/stream_link_bulk (A als Hauptsender)
    h_bulk = DummyPostHandler('/api/stream_link_bulk', {'primary': 'A'})
    m.AdminHandler._do_POST(h_bulk)
    check("Failover API: POST /api/stream_link_bulk verknüpft alle erkannten Paare",
          h_bulk.sent_code == 200 and h_bulk.sent_body.get("linked_count", 0) >= 2,
          str(h_bulk.sent_body))

    # Test E: GET /api/stream_matrix liefert Paare inklusive Status und primary-Rolle
    h_mx = DummyPostHandler('/api/stream_matrix?kind=live', {})
    m.AdminHandler.do_GET(h_mx)
    check("Failover API: GET /api/stream_matrix liefert Paare mit linked=True und primary='A'",
          h_mx.sent_code == 200 and h_mx.sent_body.get("linked_count", 0) >= 2 and
          any(p.get("linked") is True for p in h_mx.sent_body.get("pairs", [])),
          str(h_mx.sent_body))

    # Test F: POST /api/stream_unlink und POST /api/stream_unlink_all
    h_un1 = DummyPostHandler('/api/stream_unlink', {'a_vid': 501})
    m.AdminHandler._do_POST(h_un1)
    check("Failover API: POST /api/stream_unlink trennt einzelnes Paar",
          h_un1.sent_code == 200 and not m.stream_link_for("live", 501).get("paired"),
          str(h_un1.sent_body))

    h_unall = DummyPostHandler('/api/stream_unlink_all', {})
    m.AdminHandler._do_POST(h_unall)
    check("Failover API: POST /api/stream_unlink_all trennt alle Verknüpfungen sauber",
          h_unall.sent_code == 200 and h_unall.sent_body.get("cleared_count", 0) >= 1 and
          len(m.curation.get("stream_links", {})) == 0,
          str(h_unall.sent_body))


    # Test G: Gezielte Verlaufsschnappschüsse
    orig_cur = m.curation.copy()
    try:
        m.curation["channels"] = {f"live:{i}": {"cat": "1", "name": f"Ch {i}"} for i in range(500)}
        m.curation["live"] = {"1": {"name": "Cat 1", "show": True}}
        cat_snap = m.cur_flat(path="/api/categories")
        snap_ok = (not any(k.startswith("ch\t") for k in cat_snap)) and any(k.startswith("cat\t") for k in cat_snap)
        ch_snap = m.cur_flat(path="/api/channels", touched_channels={"live:42"})
        ch_keys = [k for k in ch_snap if k.startswith("ch\t")]
        snap_ok = snap_ok and (ch_keys == ["ch\tlive:42"])
    finally:
        m.curation = orig_cur
    check("Gezielter Verlaufsschnappschuss schützt vor Latenz bei großen Katalogen", snap_ok)

    # Test H: Selbsterstellte leere Kategorien bleiben sichtbar (Vorschau & IPTV-Apps)
    with m.lock:
        custom_list = m.curation.setdefault("custom", {}).setdefault("live", [])
        test_custom_vid = "7770001"
        custom_list.append({"vid": test_custom_vid, "name": "--- KABEL & PAY-TV ---"})
        m.curation.setdefault("live", {})[test_custom_vid] = {"show": True, "name": "", "order": -999}
        m.build_view(("live",))

    vis_cats = m.visible_cats("live", ("A", "B"))
    has_empty_custom = any(c["vid"] == test_custom_vid for c in vis_cats)
    # Leere Provider-Kategorien (pkey != "C") dürfen nicht enthalten sein
    has_empty_provider = any(c.get("pkey") != "C" and not c.get("provs") for c in vis_cats)
    check("Selbsterstellte leere Kategorie bleibt in visible_cats erhalten",
          has_empty_custom and not has_empty_provider,
          f"empty_custom={has_empty_custom}, empty_provider={has_empty_provider}")

    # Prüfung über /api/preview
    class DummyPreviewHandler:
        def __init__(self, path):
            self.path = path
            self.headers = {"Host": "127.0.0.1:8091"}
            self.sent_code = None
            self.sent_body = None
        def allowed(self):
            return True
        def send(self, code, body=None, ctype=None):
            self.sent_code = code
            self.sent_body = body
            return body

    h_prev = DummyPreviewHandler(f"/api/preview?kind=live&cat=&prov=A,B")
    m.AdminHandler.do_GET(h_prev)
    prev_cats = (h_prev.sent_body or {}).get("cats", [])
    prev_has_custom = next((c for c in prev_cats if c["id"] == test_custom_vid), None)
    # Vorschau & Xtream: mit aktivem Platzhalter-Stream liefert list_items für Smarters genau 1 Stream
    empty_items = m.list_items("live", ("A", "B"), cat=test_custom_vid)
    check("Leere selbsterstellte Kategorie erzeugt Platzhalter-Kanal für Smarters",
          len(empty_items) == 1 and empty_items[0]["stream_id"] >= m.PLACEHOLDER_STREAM_BASE,
          f"empty_items={empty_items}")

    # Wenn Platzhalter deaktiviert wird, ist die Liste leer
    m.config["placeholder_stream_enabled"] = False
    empty_items_disabled = m.list_items("live", ("A", "B"), cat=test_custom_vid)
    check("Bei deaktiviertem Platzhalter bleibt die Liste leer",
          len(empty_items_disabled) == 0,
          f"empty_items_disabled={empty_items_disabled}")
    m.config["placeholder_stream_enabled"] = True

    # Xtream API: list_categories liefert leere selbsterstellte Kategorie
    xc_cats = m.list_categories("live", ("A", "B"))
    has_xc_custom = any(c.get("category_id") == test_custom_vid for c in xc_cats)
    check("Xtream Codes API liefert leere selbsterstellte Kategorie an IPTV-Apps",
          has_xc_custom,
          f"has_xc_custom={has_xc_custom}")

    # Wenn der Benutzer die eigene Kategorie ausblendet (show: False), wird sie ausgeblendet
    with m.lock:
        m.curation.setdefault("live", {})[test_custom_vid]["show"] = False
        m.build_view(("live",))
    vis_cats_hidden = m.visible_cats("live", ("A", "B"))
    check("Ausgeblendete eigene Kategorie wird sauber ausgefiltert",
          not any(c["vid"] == test_custom_vid for c in vis_cats_hidden))


    # Test I: Granularer Name-Cleaner mit unabhängigen Optionen
    s_full = "SKY SPORT 1 ⁴ᴷ ³⁸⁴⁰ᴾ [DE] HD VIP"
    
    # 1. Standard (CC weg, Sonderzeichen weg, VIP weg, Qualität normalisiert ans Ende)
    c_def = m.clean_item_name(s_full)
    check("Cleaner: Standard säubert CC, Deko, VIP und normalisiert Qualität",
          c_def == "SKY SPORT 1 HD", f"got {c_def}")

    # 2. Qualität komplett löschen
    c_no_q = m.clean_item_name(s_full, options={"remove_quality": True, "normalize_quality": False})
    check("Cleaner: Qualität komplett löschen entfernt HD/4K/FHD/UHD",
          c_no_q == "SKY SPORT 1", f"got {c_no_q}")

    # 3. Nur Sonderzeichen/Hochzahlen löschen (CC und Qualität behalten)
    c_only_spec = m.clean_item_name(s_full, options={"remove_cc": False, "remove_special": True, "remove_vip": False, "remove_quality": False, "normalize_quality": False})
    check("Cleaner: Nur Sonderzeichen/Hochzahlen löschen behält CC und Qualität",
          c_only_spec == "SKY SPORT 1 [DE] HD VIP", f"got {c_only_spec}")

    # 4. Länderkürzel am Anfang (DE |) und in Klammern [DE]
    c_cc = m.clean_item_name("DE | RTL HD 50FPS (BACKUP)")
    check("Cleaner: Entfernt 'DE |' und FPS sauber, behält (Backup)",
          c_cc == "RTL HD (Backup)", f"got {c_cc}")

    # Test J: Video-Streaming (HTTP 200 & HTTP 206 Partial Content / Range Requests)
    class DummyStreamReq:
        def __init__(self, range_header=None):
            self.headers = {"Range": range_header} if range_header else {}
            self.code = None
            self.sent_headers = {}
            import io
            self.wfile = io.BytesIO()
        def send_response(self, code):
            self.code = code
        def send_header(self, k, v):
            self.sent_headers[k] = v
        def end_headers(self):
            pass

    req_full = DummyStreamReq()
    m.serve_placeholder_video(req_full)
    check("Video-Stream: Normaler Abruf liefert HTTP 200 mit video/mp4",
          req_full.code == 200 and req_full.sent_headers.get("Content-Type") == "video/mp4" and req_full.sent_headers.get("Accept-Ranges") == "bytes",
          f"code={req_full.code}, headers={req_full.sent_headers}")

    req_range = DummyStreamReq("bytes=0-1023")
    m.serve_placeholder_video(req_range)
    check("Video-Stream: Range-Anfrage (bytes=0-1023) liefert HTTP 206 Partial Content",
          req_range.code == 206 and req_range.sent_headers.get("Content-Range", "").startswith("bytes 0-1023/") and len(req_range.wfile.getvalue()) == 1024,
          f"code={req_range.code}, len={len(req_range.wfile.getvalue())}")

    # Test K: Zusammengesetzte Präfix-Tags (4K-TR-HDR) und Suffix-Länderkürzel
    s_tr_vod = "4K-TR-HDR - undertone (2026)"
    opts_all_clean = {
        "remove_cc": True,
        "remove_special": True,
        "remove_vip": True,
        "remove_quality": True,
        "normalize_quality": False
    }
    c_tr_vod = m.clean_item_name(s_tr_vod, kind="vod", options=opts_all_clean)
    check("Cleaner: 4K-TR-HDR Präfix-Tags werden restlos zu sauberem Titel bereinigt",
          c_tr_vod == "undertone (2026)", f"got {c_tr_vod}")

    c_tr_suffix = m.clean_item_name("undertone (2026) - TR", kind="vod", options=opts_all_clean)
    check("Cleaner: Länderkürzel am Namensende (' - TR') wird sauber entfernt",
          c_tr_suffix == "undertone (2026)", f"got {c_tr_suffix}")

    c_tr_bracket = m.clean_item_name("Film (2026) [TR]", kind="vod", options=opts_all_clean)
    check("Cleaner: Geklammertes Länderkürzel am Namensende ('[TR]') wird sauber entfernt",
          c_tr_bracket == "Film (2026)", f"got {c_tr_bracket}")

finally:
    shutil.rmtree(tmp, ignore_errors=True)
print(f"{'FEHLER' if fails else 'ALLES OK'}: {len(fails)} fehlgeschlagen")
sys.exit(1 if fails else 0)
