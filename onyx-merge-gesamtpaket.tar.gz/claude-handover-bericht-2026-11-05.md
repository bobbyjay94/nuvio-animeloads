# Onyx Merge – Vollständige Übergabe- und Entwicklungsdokumentation für Claude
**Datum:** 5. November 2026  
**Projekt:** Onyx Merge (OVH-VPS `ubuntu@51.38.64.30:48221`)  
**Benutzer:** Emre (@Emre)  
**Dokumenttyp:** Vollständiges Handover / Session-Protokoll & Architektur-Dokumentation

---

## 1. Ausgangslage & Kontext der Sitzung

Emre wechselte in dieser Sitzung zu Lovable, um die mit Claude begonnene Entwicklung an **Onyx Merge** lückenlos und nach den etablierten Qualitätsstandards fortzuführen.

### Bereitgestellte Ausgangsdateien:
1. `Onyx_Merge_-_Backend-Analyse.pdf` – Detaillierte Backend-Analyse vom 5. November 2026 (Maßnahmen M1–M14 sowie Erweiterungsideen I1–I12).
2. `onyx-merge-v28.tar.gz` – Version `2026.11.05.16` mit Paket A (M1–M6, M13).
3. `IPTV_Player_UI_und_Funktionen_-_Claude.pdf` – Vorheriger Chatverlauf zu UI- und Funktionsanpassungen.
4. `claude-memory-2026-11-05.zip` – Claudes Memory-Archiv zu Emres Infrastruktur, Arbeitsweise und Projekten.
5. Bildschirmfotos (`image.png`, `image-2.png`, `WhatsApp Image 2026-11-05 at 22.57.23.jpeg`) – Bestätigung der erfolgreichen Updates auf dem VPS und Nachweis der Versionsanzeige („Was ist neu“).

### Etablierte Arbeitsweise:
* Schritt-für-Schritt-Anleitungen mit separaten Befehlen für Windows CMD und den VPS.
* Vollständige lokale Validierung via `unit_core.py` und `selftest.py` (mind. 42 Selbsttests) vor jedem Release.
* Klare Trennung von Paketen mit sicherem Rollback-Pfad (`sudo onyx-merge rollback`).
* Verständliche, nutzerfreundliche Changelog-Texte im Admin-Interface unter `CHANGES`.

---

## 2. Chronologie der umgesetzten Pakete

### 2.1 Paket A (v28 – `2026.11.05.16`)
* **Status:** Vor Beginn dieser Sitzung von Emre auf dem VPS eingespielt und aktiv.
* **Umfang:**
  * **M1:** Kataloge und Listen werden nur noch einmal gebaut, auch bei parallelen Anfragen.
  * **M2:** Domain-unabhängiger Zwischenspeicher (eigene Logos per Textersetzung).
  * **M3:** XMLTV/EPG zwischengespeichert und komprimiert ausgeliefert.
  * **M4:** Beschleunigte Live-Kategorien („Heute live“) mit Mengenschnittmengen (<0,3 s).
  * **M5:** Sicheres Speichern (`.bak`, atomares Schreiben, `.corrupt`-Schutz).
  * **M6:** EPG-SQLite auf WAL-Modus (`PRAGMA journal_mode=WAL`) umgestellt.
  * **M13:** Verriegelung gegen gleichzeitige Abgleiche.

---

### 2.2 Paket B (v29 – `2026.11.05.17`)
* **Ziel:** Stabilität, Speicher-Obergrenze und Diagnose-Metriken.
* **Umfang:**
  * **M7:** Feste Zeitgrenzen für Verbindungen (Apps: 60 s, Admin: 120 s) und Begrenzung auf maximal 64 parallele Worker-Threads in `BoundedThreadingHTTPServer`.
  * **M8:** `RespCache` mit strikter LRU-Obergrenze (300 MB), autom. Verwerfen ältester Einträge.
  * **M9:** Kompakte Speicherung großer Katalog-JSONs (`separators=(",", ":")`), halbiert Schreibzeiten.
  * **M11:** Fehlerübersicht nach 6 Fachbereichen (`ERR_AREAS`) mit den letzten 50 Fehlermeldungen (`err_recent`) und Alarmierungslogik.
  * **M12:** Latenz- und Durchsatzmessung nach Endpunkt-Typen (`auth`, `live`, `vod`, `series`, `epg`) mit p50, p95 und Durchschnittswerten im Admin unter `/api/ops`.
* **Tests:** 22 Unit-Tests und 42 Selbsttests bestanden.
* **Paket:** `onyx-merge-v29.tar.gz` (bereitgestellt & auf GitHub gesichert).

---

### 2.3 Paket C (v30 – `2026.11.05.18`)
* **Ziel:** System- und Webserver-Absicherung (`systemd` + `Nginx`).
* **Umfang:**
  * **M10:** Absicherung der Dienst-Unit `onyx-merge.service`:
    * `Nice=5` (Priorität für Nginx und Jellyfin bei Volllast).
    * `MemoryHigh=2500M` und `MemoryMax=3000M` (Schutz vor RAM-Überbelegung).
    * `WatchdogSec=120` mit periodischem Herzschlag-Thread (`_start_watchdog_thread`).
  * **M14:** Nginx-Pufferung für Kataloge, Playlisten und EPG in `apply_domains.py`:
    * `proxy_buffering on;` mit 128k Puffer, 16×128k Buffers, 128M Tempfile, 120s Read-Timeout.
    * Nginx-Prüfung vor dem Neuladen (`nginx -t`) mit automatischem Rollback bei Fehlern.
* **Feedback von Emre:** Emre hat v30 erfolgreich eingespielt. Anhand eines Screenshots wies er darauf hin, dass bei Updates die Liste der Neuerungen im Admin-Fenster („Was ist neu“) immer lückenlos gepflegt sein muss. Daraufhin wurden die Einträge für v29 und v30 in `CHANGES` nachgezogen.
* **Tests:** 24 Unit-Tests und 42 Selbsttests bestanden.
* **Paket:** `onyx-merge-v30.tar.gz` (auf GitHub bereitgestellt).

---

### 2.4 Paket D (v31 – `2026.11.05.19`)
* **Ziel:** Umsetzung aller Erweiterungen nach Wahl (I3, I4, I6, I9, I10, I11).
* **Umfang:**
  1. **I3 – Plausibilitätsprüfung beim Abgleich (`sync_provider`):**
     * Vor dem Speichern wird geprüft, ob die neue Objektanzahl drastisch eingebrochen ist (>50 vorhandene Einträge, aber neu <30%).
     * Bei Einbruch bricht der Abgleich mit Fehlermeldung ab, schickt eine Telegram-Warnung und lässt den intakten Katalog unangetastet.
  2. **I4 – Nächtliche Wartung (`nightly_maintenance`):**
     * Läuft jede Nacht um 03:45 Uhr automatisch nach der Sicherung.
     * Bereinigt Diagnose-Starts/Fehlversuche älter als 14 Tage.
     * Bereinigt Play-Statistiken älter als 90 Tage.
     * Löscht abgelaufene EPG-Einträge älter als 24 Stunden.
     * Führt `PRAGMA wal_checkpoint(TRUNCATE)` auf allen drei SQLite-Datenbanken aus.
     * Begrenzt `journal.json` auf maximal 300 Einträge.
  3. **I6 – Speicher-Wächter (`health_scheduler`):**
     * Prüft alle 30 Sekunden RSS-Speicher und verfügbaren RAM.
     * Übersteigt der RSS 2,0 GB oder sinkt der freie RAM unter 400 MB, leert der Wächter proaktiv den `resp_cache`, löscht Regex-Memos und ruft `gc.collect()` auf.
  4. **I9 – Schlankeres EPG (`import_xmltv` & `prune_epg_unwanted`):**
     * EPG-Einträge werden beim Import nur noch für Sender gespeichert, die in sichtbaren/kuratierten Kategorien vorhanden sind (`view["epg_index"]`).
     * `prune_epg_unwanted()` entfernt bei der nächtlichen Wartung verwaiste EPG-Daten.
  5. **I10 – Wöchentlicher Telegram-Bericht (`build_weekly_report`):**
     * Sonntags um 10:00 Uhr wird automatisch ein Statusbericht verschickt:
       * Aktive Kunden, in 7 Tagen ablaufende Abos.
       * Letzter Abgleich-Status je Anbieter.
       * CPU- und RAM-Nutzung sowie protokollierte Fehler.
     * Zusätzliche Admin-Routen: `/api/weekly_report` (GET) und `/api/send_weekly_report` (POST).
  6. **I11 – Abgelehnte Logins auswerten (`refused_help_message`):**
     * Automatische Formulierung passender Hilfetexte für WhatsApp/Support je nach Ursache:
       * Falsche Domain (mit Angabe der korrekten Server-Adresse).
       * Abgelaufen (mit genauem Ablaufdatum und Verlängerungsangebot).
       * Falsches Passwort (mit Benutzernamen und Passwort-Erinnerung).
     * Direkt über `/api/user_detail` unter `refused[].help` abrufbar.
* **Tests:** **30 Unit-Tests** und **42 Selbsttests** vollständig bestanden.
* **Paket:** `onyx-merge-v31.tar.gz` (bereitgestellt & auf GitHub gesichert).

---

## 3. Übersicht der erstellten Release-Dateien

Alle Archive wurden gebaut, lokal verifiziert und zusätzlich im GitHub-Repository `bobbyjay94/nuvio-animeloads` im Branch `template` abgelegt:

| Datei | Version | Inhalt | Download-Link (Raw GitHub) |
|---|---|---|---|
| `onyx-merge-v29.tar.gz` | `2026.11.05.17` | Paket B (M7, M8, M9, M11, M12) | [Download v29](https://raw.githubusercontent.com/bobbyjay94/nuvio-animeloads/template/onyx-merge-v29.tar.gz) |
| `onyx-merge-v30.tar.gz` | `2026.11.05.18` | Paket C (M10, M14) + CHANGES | [Download v30](https://raw.githubusercontent.com/bobbyjay94/nuvio-animeloads/template/onyx-merge-v30.tar.gz) |
| `onyx-merge-v31.tar.gz` | `2026.11.05.19` | Paket D (I3, I4, I6, I9, I10, I11) | [Download v31](https://raw.githubusercontent.com/bobbyjay94/nuvio-animeloads/template/onyx-merge-v31.tar.gz) |
| `onyx-merge-gesamtpaket.tar.gz` | Alle | v29, v30, v31 + Handover-Bericht | [Im Workspace veröffentlicht / Download] |

---

## 4. Server-Befehle für Emre (Update auf v31)

### Schritt 1: Übertragung auf den Server (Windows CMD)
```cmd
scp -P 48221 %USERPROFILE%\Downloads\onyx-merge-v31.tar.gz ubuntu@51.38.64.30:~/
```

### Schritt 2: Per SSH anmelden (Windows CMD)
```cmd
ssh -p 48221 ubuntu@51.38.64.30
```

### Schritt 3: Update auf dem VPS ausführen
```bash
sudo onyx-merge update ~/onyx-merge-v31.tar.gz
```

---

## 5. Hinweise für Claude bei der Weiterarbeit

1. **Versions-Changelog (`CHANGES` in `onyx_merge.py`):**
   * Bei jeder neuen Version MUSS oben in `CHANGES = [...]` ein Eintrag mit der exakten Versionsnummer ergänzt werden. Die Admin-Oberfläche liest diese Liste aus und zeigt sie im Dialog „Was ist neu“ an.
2. **Datenbanken & WAL:**
   * SQLite-Datenbanken (`epg.sqlite`, `diag.sqlite`, `stats.sqlite`) laufen im WAL-Modus. Wartungsbefehle nutzen `PRAGMA wal_checkpoint(TRUNCATE)`.
3. **Rollback-Fähigkeit:**
   * Vor jedem Update sichert `/usr/local/bin/onyx-merge` die Vorversion unter `/opt/onyx-merge/prev`. Ein Rollback ist jederzeit mit `sudo onyx-merge rollback` möglich.
4. **Nächste offene Themen:**
   * Überprüfung der echten VPS-Latenzen nach 24 Stunden Betrieb mit `onyx-diagnose.sh`.
   * Weiterarbeit an der OnyxTV IPTV-Player-App (Repo: `bobbyjay94/onyx-iptv-home`, Android Studio / Fire TV).
