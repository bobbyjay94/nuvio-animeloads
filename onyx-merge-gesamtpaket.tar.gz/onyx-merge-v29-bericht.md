# Onyx Merge v29 – Paket B

## Übersicht der Änderungen

### 1. M7 – Zeitgrenzen und Thread-Limits (onyx_merge.py)
- **App-Verbindungen:** `timeout = 60` Sekunden (`ClientHandler`).
- **Verwaltung:** `timeout = 120` Sekunden (`AdminHandler`).
- **Server-Klasse:** Neuer `BoundedThreadingHTTPServer` mit Semaphore auf maximal 64 gleichzeitige Anfragen begrenzt.
- **Fehlerbehandlung:** `BrokenPipeError`, `ConnectionResetError`, `TimeoutError`, `socket.timeout` und `ConnectionAbortedError` werden abgefangen, Verbindungen sauber geschlossen ohne Fehlermeldungen im Protokoll.

### 2. M8 – Zwischenspeicher mit Obergrenze (LRU)
- `RespCache` basiert auf `collections.OrderedDict`.
- **Obergrenze:** 300 MB (`max_bytes = 300 * 1024 * 1024`).
- **LRU-Verdrängung:** Selten genutzte Listen fallen automatisch zuerst heraus, wenn 300 MB überschritten werden.
- **Thread-sicher:** Alle Zugriffe sind mit Locks abgesichert; `gen` schützt vor veralteten Antworten nach Änderungen.

### 3. M9 – Kompaktes Katalogspeichern
- In `save_json()` werden Kataloge (`catalog_A.json`, `catalog_B.json` etc.) ohne überflüssige Einrückungen und Leerzeichen (`separators=(',', ':')`) gespeichert.
- **Ergebnis:** Ca. 30 % kleinere Dateigröße und mehr als doppelt so schnelles Schreiben auf die SSD.
- Konfigurationsdateien (`curation.json`, `users.json` etc.) bleiben zur einfachen Lesbarkeit formatiert (`indent=1`).

### 4. M11 – Fehlerübersicht und Häufungserkennung
- Fehlerzählung nach Bereichen: `client`, `sync`, `epg`, `save`, `livecat`, `admin`, `other`.
- Ringspeicher für die letzten 50 Fehler mit Zeitstempel, Bereich, Fehlermeldung und Stack-Trace.
- Automatische Benachrichtigung (Telegram), wenn mehr als 5 Fehler innerhalb von 5 Minuten in einem Bereich auftreten.
- Bereitstellung über `/api/ops` und interaktive Fehlerkarte in der Admin-Oberfläche (`admin.html`).

### 5. M12 – Antwortzeiten je Endpunkt
- Automatische Klassifizierung der Anfragen: `auth`, `live`, `vod`, `series`, `epg`, `m3u`, `stream`, `other`.
- Erfassung der Antwortzeiten (Mittelwert, Median / p50, 95-%-Perzentil / p95) je Endpunkt.
- Protokollierung langsamer Anfragen (> 1,0 s) im Server-Log.
- Anzeige als Tabelle in der Admin-Oberfläche unter „Betrieb“.

---

## Testergebnisse

- **Unit-Tests (`tests/unit_core.py`):** 22/22 bestanden (0 Fehler)
  - Inklusive Tests für M7 (Zeitgrenzen & Verbindungsabbruch), M8 (LRU-Verhalten), M9 (kompakte JSON-Kataloge), M11 (Fehlerzähler) und M12 (Latenzmessung).
- **Selbsttests (`tests/selftest.py`):** 42/42 bestanden (0 Fehler).
