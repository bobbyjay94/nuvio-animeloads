"""Focused model tests for contiguous category multi-selection ordering."""

def grouped(items, selected):
    selected_indexes = [i for i, item in enumerate(items) if item in selected]
    if len(selected_indexes) < 2:
        return list(items)
    selected_items = [item for item in items if item in selected]
    remaining = [item for item in items if item not in selected]
    first_index = selected_indexes[0]
    return remaining[:first_index] + selected_items + remaining[first_index:]


def shifted(items, selected, direction):
    indexes = [i for i, item in enumerate(items) if item in selected]
    contiguous = len(indexes) <= 1 or all(indexes[i] == indexes[i - 1] + 1 for i in range(1, len(indexes)))
    if not contiguous:
        return None
    if direction == "top":
        return [x for x in items if x in selected] + [x for x in items if x not in selected]
    if direction == "bottom":
        return [x for x in items if x not in selected] + [x for x in items if x in selected]
    result = list(items)
    delta = -1 if direction == "up" else 1
    if delta > 0:
        indexes.reverse()
    for index in indexes:
        target = index + delta
        if 0 <= target < len(result) and result[target] not in selected:
            result[index], result[target] = result[target], result[index]
    return result


def test_group_preserves_order_and_anchors_at_first_selection():
    items = ["A", "B", "C", "D", "E", "F"]
    selected = {"B", "E"}
    assert grouped(items, selected) == ["A", "B", "E", "C", "D", "F"]


def test_disjoint_selection_must_group_before_shifting():
    items = ["A", "B", "C", "D", "E", "F"]
    assert shifted(items, {"B", "E"}, "down") is None


def test_group_moves_as_block_one_step_up_and_down():
    items = grouped(["A", "B", "C", "D", "E", "F"], {"B", "E"})
    selected = {"B", "E"}
    assert shifted(items, selected, "down") == ["A", "C", "B", "E", "D", "F"]
    assert shifted(items, selected, "up") == ["B", "E", "A", "C", "D", "F"]


def test_group_moves_to_top_and_bottom_as_block():
    items = grouped(["A", "B", "C", "D", "E", "F"], {"B", "E"})
    selected = {"B", "E"}
    assert shifted(items, selected, "top") == ["B", "E", "A", "C", "D", "F"]
    assert shifted(items, selected, "bottom") == ["A", "C", "D", "F", "B", "E"]


def test_contiguous_selection_can_be_shifted():
    items = ["A", "B", "C", "D"]
    assert shifted(items, {"B", "C"}, "down") == ["A", "D", "B", "C"]


if __name__ == "__main__":
    tests = [
        test_group_preserves_order_and_anchors_at_first_selection,
        test_disjoint_selection_must_group_before_shifting,
        test_group_moves_as_block_one_step_up_and_down,
        test_group_moves_to_top_and_bottom_as_block,
        test_contiguous_selection_can_be_shifted,
    ]
    for test in tests:
        test()
        print("OK", test.__name__)
    print(f"{len(tests)} category-grouping checks passed")
